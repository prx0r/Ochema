# EssayViz 0.3.0 Test Report

Date: 2026-07-29

## Automated suite

```text
35 unit/package tests passed
2 renderer-adapter integration tests passed
8 genre source examples compiled
3 gold planning bundles generated
1 advanced visual-engine report generated
1 framework-comparison report generated
Essay 3 legacy project validated and compiled
```

## Tested systems

- Markdown parsing;
- genre classification;
- rhetorical move analysis;
- raw essay compilation;
- source-lock generation;
- visual candidate routing;
- object grounding;
- anti-monotony mode routing;
- continuity planning;
- typography planning;
- music, SFX and cue sheets;
- word-level semantic cues;
- stable attractor convergence;
- deterministic particles;
- diagram layout;
- shader graph ordering;
- LYGIA include validation;
- pack loading and scaffolding;
- renderer adapter contract;
- deterministic IDs and RNG.

## Genre results

The examples classified and routed as follows:

```text
logical proof        → notation
poem                → symbolic transformation
explanatory essay   → exact object + diagram
science             → field + diagram
comparative         → diagram
textual scholarship → typographic + object
tutorial            → diagram
investigation       → hybrid, primary investigative
```

## Unexecuted boundary

The package has not rendered a production Skia/GLSL film inside this container
because the live repository and its native rendering dependencies were not
available together. The renderer adapter contract passed against a complete mock
framework. Final visual quality still requires the production render → inspect →
patch loop.
