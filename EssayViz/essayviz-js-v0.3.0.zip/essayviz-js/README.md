# EssayViz

**EssayViz is an essay-to-visual compiler.**

It converts source text into genre-aware rhetorical structure, visual candidate
systems, continuity, storyboard, typography, word-level audio cues, music/SFX,
renderer-neutral IR, render plans and review gates.

```text
essay.md
→ parse
→ classify genre
→ identify rhetorical moves
→ lock claims and non-claims
→ generate 8 visual modes per move
→ ground exact objects
→ select through semantic tournament
→ plan continuity and audio
→ compile renderer-neutral artifacts
→ realize in Skia / GLSL / SVG / WebGPU / other backend
→ review rendered perception
```

## Install

```bash
npm install ./prx0r-essayviz-0.3.0.tgz
```

## Plan directly from an essay

```bash
essayviz plan-essay essay.md --out build/my-film
```

## Supported source genres

- logical proof;
- poetry;
- explanatory essay;
- science;
- comparison;
- investigation;
- tutorial;
- textual scholarship;
- narrative;
- hybrid.

## Visual modes

- notation;
- diagram;
- exact object;
- continuous field;
- particles;
- symbolic geometry;
- typographic transformation;
- cinematic/material scene.

## Advanced engines

- stable and chaotic attractors;
- deterministic particle fields;
- diagram layouts;
- semantic transitions;
- timeline and animation engines;
- word-level audio cue planning;
- shader graphs;
- LYGIA include manifests;
- music and SFX planning;
- backend recommendation and manifests.

## Key documentation

- `ESSAYVIZ-MASTER-SPEC.md`
- `research/FRAMEWORK-COMPARISON.md`
- `docs/15-ESSAYVIZ-ARCHITECTURE.md`
- `docs/16-GENRE-ROUTING.md`
- `docs/17-VISUAL-MODES.md`
- `docs/18-SHADER-AND-GPU-ROADMAP.md`
- `docs/21-END-TO-END-AGENT-PROTOCOL.md`
- `docs/23-MULTI-AGENT-WORKFLOW.md`
- `skills/`

## Renderer policy

EssayViz does not replace the existing deterministic Skia kernel. It formalizes
the authoring layer and can target multiple backends through adapters.
