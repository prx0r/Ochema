export function buildWordTimeline(text,{duration,start=0}={}){
  const words=String(text).trim().split(/\s+/).filter(Boolean);const weights=words.map(w=>Math.max(1,w.replace(/[^\p{L}\p{N}]/gu,"").length));const total=weights.reduce((a,b)=>a+b,0);let cursor=start;
  return words.map((word,i)=>{const d=duration*weights[i]/total;const cue={index:i,word,start:cursor,end:cursor+d,center:cursor+d/2};cursor+=d;return cue;});
}
export function alignSemanticCues(wordTimeline,cues){return cues.map(cue=>{const matches=wordTimeline.filter(w=>new RegExp(cue.pattern,"i").test(w.word));const chosen=matches[cue.occurrence??0];return{...cue,time:chosen?.center??null,matchedWord:chosen?.word??null};});}
export function planTightCoupling({narration,duration,semanticCues=[]}){const words=buildWordTimeline(narration,{duration});return{version:"1.0",duration,words,semanticCues:alignSemanticCues(words,semanticCues),policies:{logicalProof:"trigger edge mutations on semantic cue words, not amplitude",poem:"cue transformations at line endings and refrains",explanatory:"reveal exact objects just before naming",science:"trigger simulation interventions at causal verbs"}};}
