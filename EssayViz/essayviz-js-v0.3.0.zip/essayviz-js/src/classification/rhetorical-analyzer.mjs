const RULES=[
  ["contention",/exact contention|question is|central claim|we ask|problem is/i],
  ["definition",/means|defined as|by .* we mean|is the term/i],
  ["premise",/^\s*\d+[.)]|because|given that|first,|second,/i],
  ["mechanism",/mechanism|causes|produces|drives|through which|process/i],
  ["identity",/identical|is nothing but|same event|token identity/i],
  ["analogy",/like|as if|analogous|compared to/i],
  ["objection",/objection|however|yet|but|cannot|problem/i],
  ["rival",/rival|physicalist|illusionism|alternative|reply/i],
  ["discriminator",/test|predict|measure|discriminator|intervention/i],
  ["framework-update",/therefore add|framework|updates|we now define/i],
  ["recognition",/recognize|directly see|becomes clear|realize/i],
  ["frontier",/remains unproved|open question|unresolved|next problem/i],
  ["conclusion",/conclusion|therefore|thus|it proves/i]
];
export function analyzeRhetoric(parsed){
  const moves=[];
  for(const [index,sentence] of parsed.sentences.entries()){
    let role="exposition";let confidence=.45;const matched=[];
    for(const [candidate,pattern] of RULES){if(pattern.test(sentence.text)){role=candidate;confidence=.78;matched.push(pattern.source);break;}}
    const relation=inferRelation(sentence.text,role);
    moves.push({id:`r${String(index+1).padStart(3,"0")}`,section:sentence.section,text:sentence.text,role,relation,confidence,matched});
  }
  return {version:"1.0",moves,sections:summarizeSections(parsed.sections,moves)};
}
function inferRelation(text,role){
  if(/if .* then|⇒|therefore/i.test(text)) return "dependency";
  if(/inside|within|contained/i.test(text)) return "containment";
  if(/same|identical/i.test(text)) return "identity";
  if(/versus|whereas|rival|alternative/i.test(text)) return "competition";
  if(/split|divide|different/i.test(text)) return "differentiation";
  if(/feedback|loop|regulat/i.test(text)) return "feedback";
  if(/transform|becomes|change/i.test(text)) return "transformation";
  if(role==="frontier"||/unexplained|missing|gap/i.test(text)) return "bridge-failure";
  return "sequence";
}
function summarizeSections(sections,moves){return sections.map(section=>{const ms=moves.filter(m=>m.section===section.title);return {title:section.title,dominantRole:mode(ms.map(m=>m.role)),moveIds:ms.map(m=>m.id)};});}
function mode(values){const counts=new Map();for(const v of values)counts.set(v,(counts.get(v)??0)+1);return [...counts].sort((a,b)=>b[1]-a[1])[0]?.[0]??"exposition";}
