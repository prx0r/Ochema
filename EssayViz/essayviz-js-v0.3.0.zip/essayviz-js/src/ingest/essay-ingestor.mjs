import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { fileURLToPath } from "node:url";
import { parseMarkdownEssay } from "./markdown-parser.mjs";
import { classifyEssay } from "../classification/genre-classifier.mjs";
import { analyzeRhetoric } from "../classification/rhetorical-analyzer.mjs";
import { routeVisualStrategies } from "../strategy/visual-router.mjs";
export async function ingestEssay(path,options={}){
  const markdown=await readFile(path,"utf8");
  const parsed=parseMarkdownEssay(markdown);
  const classification=classifyEssay(parsed,{hint:options.genre??"auto"});
  const rhetoric=analyzeRhetoric(parsed);
  const strategy=routeVisualStrategies(rhetoric,classification,options);
  const displayPath = path instanceof URL ? fileURLToPath(path) : path;
  return {version:"1.0",source:{path:String(displayPath),name:basename(displayPath)},parsed,classification,rhetoric,strategy};
}
