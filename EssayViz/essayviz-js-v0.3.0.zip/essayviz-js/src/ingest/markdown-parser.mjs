function cleanInline(text){
  return text
    .replace(/\[\^([^\]]+)\]/g, "")
    .replace(/\*\*([^*]+)\*\*/g, "$1")
    .replace(/\*([^*]+)\*/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .trim();
}
export function parseMarkdownEssay(markdown){
  const lines=String(markdown).replace(/\r\n/g,"\n").split("\n");
  const title=(lines.find(line=>/^#\s+/.test(line))??"# Untitled").replace(/^#\s+/,"").trim();
  const sections=[]; let current={level:1,title:"Opening",body:[]};
  const equations=[]; let inEquation=false, equation=[];
  for(const line of lines){
    if(line.trim()==="$$" || line.trim()==="\\["){
      if(!inEquation){inEquation=true;equation=[];} else {inEquation=false;equations.push(equation.join("\n").trim());}
      continue;
    }
    if(inEquation){equation.push(line);continue;}
    const h=line.match(/^(#{1,6})\s+(.+)$/);
    if(h){
      if(current.body.join("\n").trim()) sections.push({...current,text:current.body.join("\n").trim()});
      current={level:h[1].length,title:cleanInline(h[2]),body:[]};
    }else current.body.push(line);
  }
  if(current.body.join("\n").trim()) sections.push({...current,text:current.body.join("\n").trim()});
  const paragraphs=sections.flatMap(section=>section.text.split(/\n\s*\n/).map(cleanInline).filter(Boolean).map(text=>({section:section.title,text})));
  const sentences=paragraphs.flatMap(p=>p.text.split(/(?<=[.!?])\s+(?=[A-Z0-9“\"'])/).map(cleanInline).filter(Boolean).map(text=>({...p,text})));
  const references=lines.filter(line=>/^\[\^/.test(line)||/^https?:\/\//.test(line.trim()));
  return {version:"1.0",title,sections:sections.map(({body,...s})=>s),paragraphs,sentences,equations,references,wordCount:(markdown.match(/\S+/g)??[]).length};
}
