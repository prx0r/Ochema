# Changelog

## 0.3.0 — EssayViz

- Renamed the package to `@prx0r/essayviz`.
- Added Markdown essay ingestion.
- Added genre classification and rhetorical analysis.
- Added eight visual candidate modes.
- Added genre-specific routing, audio and review policies.
- Added exact-object grounding.
- Added raw-essay compilation and CLI commands.
- Added stable attractor, particle field and diagram engines.
- Added shader graphs, LYGIA manifests and GPU prototypes.
- Added word-level semantic audio coupling.
- Added Skia, SVG, regl, Motion Canvas, Remotion, Three/WebGPU and Pixi backend profiles.
- Added specialist agent skills and genre skills.
- Added eight genre examples, advanced visual demos and framework research.
- Expanded the test suite to 35 tests before packaging.

## 0.2.0

- Added pack extension engines, music, SFX, typography and pack scaffolding.

## 0.1.0

- Initial typed authoring and orchestration framework.
