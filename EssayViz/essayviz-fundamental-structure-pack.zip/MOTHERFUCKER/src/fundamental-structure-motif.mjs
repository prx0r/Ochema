export { renderFundamentalStructure } from "./fundamental-structure-visuals.mjs";
