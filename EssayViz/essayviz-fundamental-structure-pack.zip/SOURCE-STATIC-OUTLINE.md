# I. Static Aspect — Source-Preserving Formal Outline

This outline preserves the exact argumentative sequence supplied in the prompt.

1. Introduce one thing as `o`.
2. Spatial repetition cannot distinguish non-spatial structure.
3. Introduce another thing as `x`.
4. Difference requires priority: this/that.
5. One and two cannot be secured merely by spatial grouping.
6. Two things define a higher-order thing: their transformation operation.
7. Use `oo` and `ox` to distinguish first and second.
8. The transformation `oo ↔ ox` is itself a thing.
9. Opposite precedence requires a higher-order construction.
10. Recursion has no upper limit.
11. Number the four positions without relying on spatial identity.
12. Derive three independent interchanges: rows, columns, both.
13. A thing of increasing complexity contains 4, 16, 64, 256… members.
14. The whole is invariant under transformation of its members.
15. Reflexion preserves the same structure as immediacy.
16. The hierarchy is infinite in generality and particularity.
17. Dynamic structure must next explain duration, past, present, future,
    intention, action and choice.
