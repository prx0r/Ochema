# SOURCE NOTES — Vikalpa, Mantra-vīrya, True Japa

## Primary structure
- Tantrāloka 4.2–12: purification and empowerment of conceptual thought.
- Tantrāloka 4.13–32cd: the nature of right reasoning.
- Tantrāloka 4.181cd–193: vitality of mantra.
- Tantrāloka 4.194–203: true repetition of mantra.

## Condensed witness
Abhinavagupta’s Tantrasāra Chapter 4 states that beings consider themselves bound through the force of vikalpa, and that an opposing vikalpa can break the thought that causes bondage. It identifies sattarka as a direct means and defines japa as inward reflective awareness of the supreme principle as one’s own nature.

## Critical cautions
- Scene 6’s “inert shell” is a derived contrast, not a quotation.
- Scene 9’s sound–meaning–awareness triangle is synthetic.
- Scene 13’s continuous luminous band is a pedagogical inference and is not labeled ajapa.
