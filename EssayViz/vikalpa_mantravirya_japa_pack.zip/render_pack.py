#!/usr/bin/env python3
from __future__ import annotations
import json, math, subprocess, zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT=Path(__file__).resolve().parent
FRAMES_ROOT=ROOT/'frames'; SCENES_ROOT=ROOT/'scenes'
W,H=1280,720; FPS=10; DURATION=4.8; NFRAMES=int(FPS*DURATION); SEED=40404

# Clean cognitive / living-mantra palette
IVORY=(247,244,236); PAPER=(239,234,223); INK=(21,24,31); SOFT_INK=(62,66,77)
ASH=(132,137,148); MIST=(205,207,205); WHITE=(255,254,249)
RUBY=(150,35,62); ROSE=(202,93,119); GOLD=(194,143,53); GOLD_LIGHT=(243,202,111)
LAPIS=(44,75,138); CYAN=(65,150,164); TEAL=(56,124,119); VIOLET=(99,66,142)
COPPER=(173,91,54); GREEN=(77,125,89); BLACK=(7,9,13)

FONT_SERIF='/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf'
FONT_SERIF_BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf'
FONT_SANS='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_DEVA='/usr/share/fonts/truetype/noto/NotoSerifDevanagari-Regular.ttf'
TITLE_FONT=ImageFont.truetype(FONT_SERIF_BOLD,30)
SUB_FONT=ImageFont.truetype(FONT_SERIF,17)
TERM_FONT=ImageFont.truetype(FONT_SERIF_BOLD,21)
SMALL_FONT=ImageFont.truetype(FONT_SERIF,14)
TINY_FONT=ImageFont.truetype(FONT_SERIF,11)
SANS_SMALL=ImageFont.truetype(FONT_SANS,12)
DEVA_BIG=ImageFont.truetype(FONT_DEVA,52)
DEVA_MED=ImageFont.truetype(FONT_DEVA,29)


def clamp(v,lo=0.0,hi=1.0): return max(lo,min(hi,v))
def lerp(a,b,t): return a+(b-a)*clamp(t)
def mix(a,b,t):
    t=clamp(t); return tuple(int(lerp(x,y,t)) for x,y in zip(a,b))
def rgba(c,a=255): return (*c[:3],int(a))
def ease(t):
    t=clamp(t); return .5-.5*math.cos(math.pi*t)
def smooth(a,b,x):
    if a==b: return 1.0 if x>=b else 0.0
    t=clamp((x-a)/(b-a)); return t*t*(3-2*t)
def layer(): return Image.new('RGBA',(W,H),(0,0,0,0))

def make_ground(seed:int):
    rng=np.random.default_rng(seed)
    arr=np.zeros((H,W,3),dtype=np.float32); arr[:]=np.array(IVORY,dtype=np.float32)
    coarse=rng.normal(0,1,(40,72)).astype(np.float32)
    ci=Image.fromarray(np.uint8(np.clip((coarse-coarse.min())/(np.ptp(coarse)+1e-8)*255,0,255)))
    ci=ci.resize((W,H),Image.Resampling.BICUBIC).filter(ImageFilter.GaussianBlur(24))
    ca=(np.asarray(ci).astype(np.float32)-128)/128
    arr += ca[...,None]*3.0
    yy,xx=np.mgrid[0:H,0:W]
    vign=np.clip(((xx-W/2)/(W/2))**2+((yy-H/2)/(H/2))**2,0,1)
    arr -= vign[...,None]*7
    glow=np.exp(-(((xx-W*.50)/(W*.30))**2+((yy-H*.34)/(H*.24))**2)*2.0)
    arr[...,0]+=glow*4; arr[...,1]+=glow*3; arr[...,2]+=glow*1
    return Image.fromarray(np.uint8(np.clip(arr,0,255)),'RGB').convert('RGBA')

def draw_glow(im,xy,r,col,alpha=100,blur=18):
    g=layer(); d=ImageDraw.Draw(g); x,y=xy
    d.ellipse((x-r,y-r,x+r,y+r),fill=rgba(col,alpha)); g=g.filter(ImageFilter.GaussianBlur(blur)); im.alpha_composite(g)

def draw_line_glow(im,pts,col,width=3,alpha=120,blur=7):
    if len(pts)<2:return
    g=layer(); dg=ImageDraw.Draw(g); dg.line(pts,fill=rgba(col,alpha),width=max(1,width*3),joint='curve'); g=g.filter(ImageFilter.GaussianBlur(blur)); im.alpha_composite(g)
    ImageDraw.Draw(im).line(pts,fill=rgba(col,min(255,alpha+80)),width=width,joint='curve')

def bezier(p0,p1,p2,p3,n=80):
    out=[]
    for i in range(n):
        t=i/(n-1); u=1-t
        out.append((u**3*p0[0]+3*u*u*t*p1[0]+3*u*t*t*p2[0]+t**3*p3[0],u**3*p0[1]+3*u*u*t*p1[1]+3*u*t*t*p2[1]+t**3*p3[1]))
    return out

def partial(points,a):
    a=clamp(a)
    if a<=0:return []
    if a>=1:return points
    f=a*(len(points)-1); i=int(f); q=f-i; out=list(points[:i+1])
    if i+1<len(points):
        x=lerp(points[i][0],points[i+1][0],q); y=lerp(points[i][1],points[i+1][1],q); out.append((x,y))
    return out

def arrow(draw,p0,p1,col,s=1.0):
    a=math.atan2(p1[1]-p0[1],p1[0]-p0[0]); z=11*s
    draw.polygon([p1,(p1[0]-math.cos(a-.48)*z,p1[1]-math.sin(a-.48)*z),(p1[0]-math.cos(a+.48)*z,p1[1]-math.sin(a+.48)*z)],fill=rgba(col,230))

def border(im):
    d=ImageDraw.Draw(im)
    d.rounded_rectangle((30,28,W-30,H-28),radius=18,outline=rgba(INK,75),width=2)
    d.rounded_rectangle((44,42,W-44,H-42),radius=14,outline=rgba(GOLD,75),width=1)
    for x,y in [(72,70),(W-72,70),(72,H-70),(W-72,H-70)]:
        d.ellipse((x-8,y-8,x+8,y+8),outline=rgba(RUBY,140),width=2); d.ellipse((x-2,y-2,x+2,y+2),fill=rgba(GOLD,190))

def footer(im,title,subtitle,term=None):
    d=ImageDraw.Draw(im); y0=H-112
    d.rounded_rectangle((88,y0,W-88,H-34),radius=14,fill=rgba(WHITE,232),outline=rgba(INK,45),width=1)
    d.text((120,y0+17),title,font=TITLE_FONT,fill=INK)
    d.text((122,y0+57),subtitle,font=SUB_FONT,fill=SOFT_INK)
    if term:
        tw=d.textbbox((0,0),term,font=TERM_FONT)[2]
        d.text((W-116-tw,y0+24),term,font=TERM_FONT,fill=RUBY)

def dust(im,seed,n=55):
    rng=np.random.default_rng(seed); o=layer(); d=ImageDraw.Draw(o)
    for _ in range(n):
        x=float(rng.uniform(105,W-105)); y=float(rng.uniform(90,H-165)); r=float(rng.uniform(.5,1.5)); c=mix(ASH,GOLD,rng.random())
        d.ellipse((x-r,y-r,x+r,y+r),fill=rgba(c,int(rng.uniform(12,38))))
    im.alpha_composite(o)

def node(draw,x,y,r,col,label=None,alpha=38,font=None,textcol=INK):
    draw.ellipse((x-r,y-r,x+r,y+r),fill=rgba(mix(WHITE,col,.10),alpha),outline=rgba(col,190),width=2)
    if label: draw.text((x,y),label,font=font or SMALL_FONT,fill=textcol,anchor='mm')

def glass_panel(draw,box,col,alpha=25,radius=18):
    draw.rounded_rectangle(box,radius=radius,fill=rgba(WHITE,alpha),outline=rgba(col,145),width=2)
    x0,y0,x1,y1=box; draw.line((x0+18,y0+14,x1-18,y0+14),fill=rgba(WHITE,120),width=2)

def eye(draw,cx,cy,s=1.0,col=RUBY):
    draw.arc((cx-70*s,cy-30*s,cx+70*s,cy+30*s),180,360,fill=rgba(col,210),width=max(1,int(3*s)))
    draw.arc((cx-70*s,cy-30*s,cx+70*s,cy+30*s),0,180,fill=rgba(col,210),width=max(1,int(3*s)))
    draw.ellipse((cx-12*s,cy-12*s,cx+12*s,cy+12*s),fill=rgba(GOLD_LIGHT,235),outline=rgba(col,200),width=2)

def spiral_points(cx,cy,r0,r1,turns,n=160,phase=0):
    pts=[]
    for i in range(n):
        u=i/(n-1); a=phase+turns*2*math.pi*u; r=lerp(r0,r1,u); pts.append((cx+math.cos(a)*r,cy+math.sin(a)*r*.72))
    return pts

@dataclass
class Scene:
    id:str; title:str; subtitle:str; term:str; summary:str; mode:str; tags:list[str]; group:str; technique:str; source_status:str; textual_anchor:str; draw_fn:Callable

# 01 cognitive engine
def sc01(im,t):
    d=ImageDraw.Draw(im); y=280
    # tangled thought cloud
    for j in range(7):
        pts=[]
        for i in range(70):
            u=i/69; x=155+u*225; yy=y+math.sin(u*math.pi*(3+j*.23)+j)*38+math.sin(u*17+j)*10
            pts.append((x,yy))
        d.line(pts,fill=rgba(mix(INK,ASH,j/7),120),width=2)
    glass_panel(d,(450,170,790,390),LAPIS,28)
    for k in range(5):
        x=500+k*60; d.line((x,340,x+45,220),fill=rgba(mix(LAPIS,RUBY,k/4),155),width=3)
    draw_glow(im,(950,y),82,GOLD_LIGHT,90,22)
    for r in [26,50,78]: d.ellipse((950-r,y-r,950+r,y+r),outline=rgba(mix(RUBY,GOLD,r/80),170),width=2)
    for a0,b0 in [((385,y),(450,y)),((790,y),(860,y))]:
        pts=partial(bezier(a0,(lerp(a0[0],b0[0],.4),y-30),(lerp(a0[0],b0[0],.6),y+30),b0),smooth(.05,.75,t)); draw_line_glow(im,pts,RUBY,3,105,6)
        if len(pts)>1: arrow(d,pts[-2],pts[-1],RUBY,.9)
    d.text((270,125),'VIKALPA',font=TERM_FONT,fill=INK,anchor='mm'); d.text((620,125),'MANTRA',font=TERM_FONT,fill=LAPIS,anchor='mm'); d.text((950,125),'JAPA',font=TERM_FONT,fill=RUBY,anchor='mm')
    d.text((640,495),'thought is refined, mantra becomes alive, and repetition turns into recognition',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 02 binding vikalpa
def sc02(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,285
    # contracted person-symbol
    d.ellipse((cx-22,cy-100,cx+22,cy-56),outline=rgba(INK,190),width=3); d.line((cx,cy-55,cx,cy+35),fill=rgba(INK,190),width=4); d.line((cx,cy-20,cx-48,cy+20),fill=rgba(INK,190),width=4); d.line((cx,cy-20,cx+48,cy+20),fill=rgba(INK,190),width=4)
    labels=['small','separate','powerless','fixed','other','limited']
    for j,lab in enumerate(labels):
        a=-math.pi/2+j*2*math.pi/len(labels)+t*.03; r=160+12*math.sin(j)
        x=cx+math.cos(a)*r; y=cy+math.sin(a)*r*.67
        node(d,x,y,34,ASH,lab,32,TINY_FONT,SOFT_INK)
        pts=bezier((x,y),(lerp(x,cx,.35),y+20*math.sin(a)),(lerp(x,cx,.75),cy-25*math.cos(a)),(cx,cy),65)
        draw_line_glow(im,pts,INK,2,55,4)
    for r in [74,104,134]: d.ellipse((cx-r,cy-r*.68,cx+r,cy+r*.68),outline=rgba(INK,int(135*(1-.25*t))),width=2)
    d.text((640,495),'binding thought repeatedly presents the universal subject as a contracted individual',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 03 counter-vikalpa
def sc03(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,282
    # black knot
    for j in range(9):
        pts=[]
        for i in range(100):
            u=i/99; a=u*2*math.pi*2+j*.55; r=65+32*math.sin(3*a+j)
            pts.append((cx+math.cos(a)*r,cy+math.sin(a)*r*.72))
        d.line(pts,fill=rgba(INK,100),width=2)
    # counter thought filament crosses and opens knot
    p=partial(bezier((220,360),(400,175),(780,395),(1055,190),150),smooth(.03,.78,t)); draw_line_glow(im,p,RUBY,5,125,9)
    if len(p)>1: arrow(d,p[-2],p[-1],RUBY,1.1)
    open_amt=smooth(.28,.90,t)
    for j in range(10):
        a=j*2*math.pi/10; r=90+100*open_amt
        x=cx+math.cos(a)*r; y=cy+math.sin(a)*r*.55
        d.ellipse((x-5,y-5,x+5,y+5),fill=rgba(GOLD,int(60+150*open_amt)))
    d.text((640,495),'a liberating vikalpa opposes and dissolves the vikalpa that sustains bondage',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 04 sattarka
def sc04(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,280
    draw_glow(im,(cx,cy),70,GOLD_LIGHT,70,18); eye(d,cx,cy,.65,RUBY)
    propositions=[('source',LAPIS),('self',RUBY),('world',TEAL),('reason',VIOLET),('scripture',COPPER),('teacher',GREEN)]
    for i,(lab,col) in enumerate(propositions):
        a=-math.pi/2+i*2*math.pi/6; x=cx+math.cos(a)*230; y=cy+math.sin(a)*145
        node(d,x,y,42,col,lab,30,SMALL_FONT)
        pts=partial(bezier((x,y),(lerp(x,cx,.35),y),(lerp(x,cx,.68),cy),(cx,cy),80),smooth(.04+i*.04,.78,t)); draw_line_glow(im,pts,col,3,85,5)
    # compass needle
    a=-2.2+ease(t)*1.8
    d.line((cx,cy,cx+math.cos(a)*115,cy+math.sin(a)*115),fill=rgba(RUBY,210),width=4)
    d.ellipse((cx-10,cy-10,cx+10,cy+10),fill=rgba(GOLD_LIGHT,240))
    d.text((640,495),'right reasoning aligns thought with the already-luminous structure of awareness',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 05 vikalpa samskara
def sc05(im,t):
    d=ImageDraw.Draw(im)
    xs=[220,430,640,850,1060]; cols=[INK,ASH,LAPIS,VIOLET,RUBY]
    for k,x in enumerate(xs):
        glass_panel(d,(x-72,165,x+72,390),cols[k],20+5*k)
        pts=[]
        amp=55*(1-k/5)+8
        for i in range(80):
            u=i/79; yy=278+math.sin(u*math.pi*(5-k*.7)+k)*amp+math.sin(u*23+k)*amp*.22
            pts.append((x-55+u*110,yy))
        d.line(pts,fill=rgba(cols[k],160),width=2)
        if k<4:
            p=partial(bezier((x+72,278),(x+110,235),(xs[k+1]-110,320),(xs[k+1]-72,278),60),smooth(.05+k*.12,.78,t)); draw_line_glow(im,p,mix(cols[k],cols[k+1],.5),2,75,5)
    d.text((640,495),'successive refinements make conceptual thought clear, stable, and transparent',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 06 inert mantra
def sc06(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,280
    syll=['अ','ह','ं','शि','व','म्']
    for i,ch in enumerate(syll):
        a=-math.pi/2+i*2*math.pi/len(syll); x=cx+math.cos(a)*170; y=cy+math.sin(a)*118
        node(d,x,y,33,ASH,None,22); d.text((x,y),ch,font=DEVA_MED,fill=ASH,anchor='mm')
    d.ellipse((cx-58,cy-58,cx+58,cy+58),outline=rgba(ASH,135),width=2)
    d.ellipse((cx-8,cy-8,cx+8,cy+8),fill=rgba(ASH,75))
    for i in range(len(syll)):
        a=-math.pi/2+i*2*math.pi/len(syll); b=-math.pi/2+(i+1)*2*math.pi/len(syll)
        d.arc((cx-170,cy-118,cx+170,cy+118),math.degrees(a),math.degrees(b),fill=rgba(ASH,60),width=1)
    d.text((640,495),'a formula may remain an external phonemic shell when its conscious vitality is absent',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 07 mantra virya
def sc07(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,280; syll=['अ','ह','ं','शि','व','म्']
    pulse=.55+.45*math.sin(t*math.pi*4)**2
    draw_glow(im,(cx,cy),70+18*pulse,GOLD_LIGHT,90+60*pulse,18)
    d.ellipse((cx-24,cy-24,cx+24,cy+24),fill=rgba(RUBY,220),outline=rgba(GOLD_LIGHT,240),width=3)
    for i,ch in enumerate(syll):
        a=-math.pi/2+i*2*math.pi/len(syll)+t*.08; x=cx+math.cos(a)*178; y=cy+math.sin(a)*121
        col=mix(LAPIS,RUBY,i/(len(syll)-1)); node(d,x,y,35,col,None,34); d.text((x,y),ch,font=DEVA_MED,fill=col,anchor='mm')
        pts=partial(bezier((cx,cy),(cx+math.cos(a+.35)*65,cy+math.sin(a+.35)*45),(x-math.cos(a)*65,y-math.sin(a)*45),(x,y),70),smooth(.03+i*.04,.72,t)); draw_line_glow(im,pts,col,3,95,6)
    d.text((640,495),'mantra-vīrya is the formula’s power when phoneme and awareness awaken as one act',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 08 names of shakti / heart wave
def sc08(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,280
    names=[('Heart',RUBY),('Wave',CYAN),('Spanda',VIOLET),('Speech',LAPIS),('Power',GOLD),('Vision',GREEN)]
    for ring in [62,95]: d.ellipse((cx-ring,cy-ring,cx+ring,cy+ring),outline=rgba(RUBY if ring==62 else GOLD,145),width=2)
    d.text((cx,cy),'हृदय',font=DEVA_BIG,fill=RUBY,anchor='mm')
    for i,(lab,col) in enumerate(names):
        a=-math.pi/2+i*2*math.pi/6+t*.05; x=cx+math.cos(a)*235; y=cy+math.sin(a)*145
        node(d,x,y,39,col,lab,28,SMALL_FONT)
        wave=[]
        for j in range(65):
            u=j/64; xx=lerp(x,cx,u); yy=lerp(y,cy,u)+math.sin(u*math.pi*5+i)*10*(1-u)
            wave.append((xx,yy))
        draw_line_glow(im,partial(wave,smooth(.04+i*.04,.82,t)),col,2,75,5)
    d.text((640,495),'heart, wave, vibration, speech, power, and vision name one fullness of Śakti',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 09 sound meaning awareness triangle
def sc09(im,t):
    d=ImageDraw.Draw(im); pts0=[(640,125),(330,385),(950,385)]; labs=[('Awareness',RUBY),('Sound',LAPIS),('Meaning',GOLD)]
    for (x,y),(lab,col) in zip(pts0,labs): node(d,x,y,55,col,lab,34,SMALL_FONT)
    for i in range(3):
        p0=pts0[i]; p1=pts0[(i+1)%3]
        curve=partial(bezier(p0,(lerp(p0[0],p1[0],.35),lerp(p0[1],p1[1],.35)-35),(lerp(p0[0],p1[0],.7),lerp(p0[1],p1[1],.7)+35),p1,85),smooth(.04+i*.12,.86,t)); draw_line_glow(im,curve,mix(labs[i][1],labs[(i+1)%3][1],.5),3,90,6)
        if len(curve)>1: arrow(d,curve[-2],curve[-1],mix(labs[i][1],labs[(i+1)%3][1],.5),.8)
    eye(d,640,285,.55,RUBY)
    d.text((640,495),'living mantra circulates inseparably through sound, meaning, and self-recognition',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 10 mechanical repetition
def sc10(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,280
    # mala beads moving around, dim center
    for i in range(27):
        a=-math.pi/2+i*2*math.pi/27+t*.14; x=cx+math.cos(a)*225; y=cy+math.sin(a)*145
        d.ellipse((x-8,y-8,x+8,y+8),fill=rgba(PAPER,240),outline=rgba(INK,120),width=2)
    glass_panel(d,(540,205,740,355),ASH,20)
    d.text((640,257),'1  2  3  4  5',font=TERM_FONT,fill=ASH,anchor='mm')
    d.text((640,304),'sound repeated',font=SMALL_FONT,fill=SOFT_INK,anchor='mm')
    d.ellipse((cx-8,cy+82,cx+8,cy+98),fill=rgba(ASH,65))
    d.text((640,495),'counted repetition can remain external when awareness does not turn toward its own nature',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 11 true japa
def sc11(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,282
    # outer phoneme spiral folds inward to heart
    sp=spiral_points(cx,cy,235,25,2.25,180,-math.pi/2)
    p=partial(sp,smooth(.02,.83,t)); draw_line_glow(im,p,RUBY,4,110,8)
    for i,ch in enumerate(['अ','ह','ं','शि','व']):
        idx=min(len(sp)-1,int(i*(len(sp)-1)/4)); x,y=sp[idx]; d.text((x,y),ch,font=DEVA_MED,fill=mix(LAPIS,RUBY,i/4),anchor='mm')
    draw_glow(im,(cx,cy),72,GOLD_LIGHT,100,20); eye(d,cx,cy,.62,RUBY)
    d.text((640,495),'true japa is inward parāmarśa: awareness recognizing the supreme principle as its own nature',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 12 inner outer both
def sc12(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,280
    # outer field symbols and inner field symbols merge
    for i in range(12):
        a=i*2*math.pi/12; x=cx+math.cos(a)*235; y=cy+math.sin(a)*145
        node(d,x,y,11,mix(TEAL,GOLD,i/11),None,26)
        pts=partial(bezier((x,y),(cx+math.cos(a+.25)*170,cy+math.sin(a+.25)*100),(cx+math.cos(a-.25)*95,cy+math.sin(a-.25)*58),(cx,cy),70),smooth(.03+i*.025,.82,t)); draw_line_glow(im,pts,mix(TEAL,RUBY,i/11),2,65,5)
    for i in range(8):
        a=i*2*math.pi/8+t*.04; x=cx+math.cos(a)*92; y=cy+math.sin(a)*58
        d.ellipse((x-7,y-7,x+7,y+7),fill=rgba(RUBY,130),outline=rgba(GOLD,180),width=1)
    draw_glow(im,(cx,cy),50,GOLD_LIGHT,95,15); eye(d,cx,cy,.45,RUBY)
    d.text((390,145),'outer knowables',font=TERM_FONT,fill=TEAL,anchor='mm'); d.text((890,145),'inner knowables',font=TERM_FONT,fill=VIOLET,anchor='mm')
    d.text((640,495),'inner and outer knowables are gathered into a single twofold act of awareness',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 13 continuity
def sc13(im,t):
    d=ImageDraw.Draw(im)
    # discrete pulses to continuous band
    y=270
    for i in range(10):
        x=150+i*55; a=smooth(.03+i*.025,.62,t)
        d.ellipse((x-10,y-10,x+10,y+10),fill=rgba(RUBY,int(70+150*a)),outline=rgba(GOLD,160),width=1)
    p=partial(bezier((650,y),(760,160),(920,380),(1110,y),120),smooth(.35,.92,t)); draw_line_glow(im,p,GOLD,8,110,12)
    for r in [26,52,78]: d.arc((1020-r,y-r,1020+r,y+r),210,510,fill=rgba(RUBY,120),width=2)
    d.text((385,145),'discrete practice',font=TERM_FONT,fill=SOFT_INK,anchor='mm'); d.text((915,145),'continuous recognition',font=TERM_FONT,fill=RUBY,anchor='mm')
    d.text((640,495),'repeated recollection gradually stabilizes as an uninterrupted luminous orientation',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

# 14 seal
def sc14(im,t):
    d=ImageDraw.Draw(im); cx,cy=640,280
    # three interlocking rings: thought, vitality, recognition
    rings=[(205,INK,'VIKALPA'),(145,LAPIS,'VĪRYA'),(88,RUBY,'JAPA')]
    for idx,(r,col,lab) in enumerate(rings):
        d.ellipse((cx-r,cy-r*.72,cx+r,cy+r*.72),outline=rgba(col,165),width=3)
        n=12-idx*2
        for i in range(n):
            a=-math.pi/2+i*2*math.pi/n+t*.035*(1 if idx%2==0 else -1); x=cx+math.cos(a)*r; y=cy+math.sin(a)*r*.72
            d.ellipse((x-4,y-4,x+4,y+4),fill=rgba(mix(col,GOLD_LIGHT,i/max(1,n-1)),170))
        d.text((cx+r+18,cy),lab,font=TINY_FONT,fill=col,anchor='lm')
    # inward folding paths
    for i,col in enumerate([INK,LAPIS,RUBY]):
        a=-math.pi/2+i*2*math.pi/3
        p0=(cx+math.cos(a)*200,cy+math.sin(a)*145)
        p=partial(bezier(p0,(cx+math.cos(a+.4)*150,cy+math.sin(a+.4)*100),(cx+math.cos(a-.4)*95,cy+math.sin(a-.4)*60),(cx,cy),85),smooth(.04+i*.09,.83,t)); draw_line_glow(im,p,col,3,85,6)
    draw_glow(im,(cx,cy),70,GOLD_LIGHT,110,19); eye(d,cx,cy,.72,RUBY)
    d.text((640,495),'thought, mantra vitality, and inward repetition resolve into one act of self-recognition',font=SUB_FONT,fill=SOFT_INK,anchor='mm')

SCENES=[
Scene('vm01','The Living-Mantra Engine','Thought is refined, mantra is awakened, and repetition becomes recognition.','Vikalpa → Vīrya → Japa','Overview of Chapter 4 cognitive and mantric process.','overview',['vikalpa','mantra','japa'],'overview','three-stage cognitive engine','derived','Tantrāloka 4.2–12, 4.181cd–203',sc01),
Scene('vm02','Binding Vikalpa','The universal subject repeatedly imagines itself contracted.','Bandhaka-vikalpa','Thought sustains the conviction of limitation.','binding',['bondage','thought','contraction'],'vikalpa','ink loops around contracted subject','direct','Tantrasāra Chapter 4 opening; Tantrāloka 4.2–12',sc02),
Scene('vm03','Counter-Vikalpa','A liberating thought dissolves the thought that maintains bondage.','Pratidvandvi-vikalpa','One conceptual formation opposes another until the binding formation collapses.','counter_thought',['counter-thought','liberation','refinement'],'vikalpa','ruby filament opening an ink knot','direct','Tantrasāra Chapter 4 opening; Tantrāloka 4.2–12',sc03),
Scene('vm04','Sattarka — Right Reasoning','Reason aligns thought with the luminous structure of awareness.','Sattarka','Right reasoning functions as a direct means in Śāktopāya.','reasoning',['reasoning','sattarka','knowledge'],'vikalpa','six-point reasoning compass','direct','Tantrāloka 4.13–32cd; Tantrasāra Chapter 4',sc04),
Scene('vm05','Vikalpa-saṃskāra','Conceptual thought becomes progressively clear and transparent.','Vikalpasaṃskāra','Successive refinement transforms the cognitive field.','refinement',['thought','purification','clarity'],'vikalpa','five glass waveform filters','direct','Tantrāloka 4.2–12',sc05),
Scene('vm06','The Inert Mantra Shell','Phonemes may remain externally arranged without awakened vitality.','Avīrya-mantra','A formula is visually distinguished from its conscious power.','inert_mantra',['phoneme','formula','inert'],'mantra','dim phoneme orbit','derived','Tantrāloka 4.181cd–193',sc06),
Scene('vm07','Mantra-vīrya','The formula awakens as an act of conscious power.','Mantravīrya','Phoneme and awareness ignite as one living circuit.','mantra_vitality',['mantra','vitality','awareness'],'mantra','gold-ruby power core energizing phonemes','direct','Tantrāloka 4.181cd–193',sc07),
Scene('vm08','The Heart of Śakti','Heart, wave, vibration, speech, power, and vision name one fullness.','Śakti-hṛdaya','Several scriptural names converge on the fullness that gives mantra life.','shakti_names',['heart','spanda','speech'],'mantra','six radiating names around hṛdaya','derived','Tantrasāra Chapter 4, discussion of Śakti after japa',sc08),
Scene('vm09','Sound, Meaning, Awareness','Living mantra circulates through three inseparable poles.','Śabda–Artha–Parāmarśa','Sound and meaning become potent through reflective awareness.','triad',['sound','meaning','recognition'],'mantra','circulating triangular field','synthetic','Synthesis of Tantrāloka Chapter 4 mantra-vitality doctrine',sc09),
Scene('vm10','Mechanical Repetition','Counted sound may remain external to recognition.','Bāhya-japa','Repetition is contrasted with inward reflective awareness.','mechanical_japa',['counting','repetition','external'],'japa','mala orbit and dim counter','derived','Tantrāloka 4.194–203; Tantrasāra Chapter 4',sc10),
Scene('vm11','True Japa','Awareness recognizes the supreme principle as its own nature.','Vāstava-japa','True repetition is inward parāmarśa rather than sound-counting alone.','true_japa',['japa','paramarsha','self-recognition'],'japa','phoneme spiral returning to heart-eye','direct','Tantrāloka 4.194–203; Tantrasāra Chapter 4',sc11),
Scene('vm12','The Twofold Awareness','Inner and outer knowables are gathered into one act.','Ubhayātmaka-parāmarśa','Japa gives rise to awareness encompassing both inner and outer fields.','twofold_awareness',['inner','outer','awareness'],'japa','outer nodes recollected into inner eye','direct','Tantrasāra Chapter 4, japa passage',sc12),
Scene('vm13','From Repetition to Continuity','Discrete recollection stabilizes as an uninterrupted orientation.','Nairantarya','Practice becomes progressively continuous without being depicted as automatic magic.','continuity',['practice','continuity','stability'],'integration','pulse train becoming luminous band','synthetic','Interpretive synthesis from Chapter 4 true-japa section',sc13),
Scene('vm14','The Living-Mantra Seal','Thought, vitality, and japa resolve into self-recognition.','Japa-vīrya-cakra','Closing synthesis of the pack.','seal',['seal','mantra','recognition'],'seal','three interlocking ellipses and central eye','synthetic','Closing synthesis based on Tantrāloka Chapter 4',sc14),
]

def render_scene(sc:Scene):
    sdir=FRAMES_ROOT/sc.id; sdir.mkdir(parents=True,exist_ok=True)
    base=make_ground(SEED+sum(ord(c) for c in sc.id)*17)
    expected=[sdir/f'frame_{i:04d}.jpg' for i in range(NFRAMES)]
    for i,path in enumerate(expected):
        if path.exists() and path.stat().st_size>1000: continue
        t=i/max(1,NFRAMES-1); im=base.copy(); border(im); dust(im,SEED+i+len(sc.id)*100,45); sc.draw_fn(im,t); footer(im,sc.title,sc.subtitle,sc.term); im.convert('RGB').save(path,quality=94,optimize=True)
    out=SCENES_ROOT/f'{sc.id}.mp4'
    if not out.exists() or out.stat().st_size<30000:
        subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate',str(FPS),'-i',str(sdir/'frame_%04d.jpg'),'-c:v','libx264','-pix_fmt','yuv420p','-crf','18','-movflags','+faststart',str(out)],check=True)

def make_contact_sheet():
    thumbs=[]
    for sc in SCENES:
        fp=FRAMES_ROOT/sc.id/f'frame_{int(NFRAMES*.72):04d}.jpg'; thumbs.append(Image.open(fp).convert('RGB').resize((320,180),Image.Resampling.LANCZOS))
    sheet=Image.new('RGB',(1280,720),IVORY)
    for i,im in enumerate(thumbs): sheet.paste(im,((i%4)*320,(i//4)*180))
    sheet.save(ROOT/'contact_sheet.jpg',quality=95)

def write_metadata():
    manifest={
      'project':'Tantrāloka — Vikalpa, Mantra-vīrya, and True Japa',
      'source_basis':'Tantrāloka Chapter 4: vikalpasaṃskāra (4.2–12), sattarka (4.13–32cd), mantravīrya (4.181cd–193), and true japa (4.194–203), with Abhinavagupta’s Tantrasāra Chapter 4 as a condensed interpretive witness.',
      'source_critical_note':'Direct textual claims, derived explanatory diagrams, and synthetic visual inferences are labeled separately. The pack is philosophical and non-instructional.',
      'style':{'family':'clean cognitive glass and living typography','background':'unlined ivory field','ink':'black and graphite','accent':'ruby, lapis, gold, teal','materials':['cognitive glass','ink knots','phoneme beads','heart waves','luminous continuity bands']},
      'fps':FPS,'resolution':[W,H],'scene_duration_seconds':DURATION,'total_scenes':len(SCENES),'total_duration_seconds':round(len(SCENES)*DURATION,2),
      'scenes':[{'id':s.id,'title':s.title,'subtitle':s.subtitle,'mode':s.mode,'summary':s.summary,'group':s.group,'technique_notes':s.technique,'tags':s.tags,'source_status':s.source_status,'textual_anchor':s.textual_anchor,'duration_seconds':DURATION,'output_filename':f'scenes/{s.id}.mp4'} for s in SCENES]
    }
    (ROOT/'scene_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    catalog={'ids':[s.id for s in SCENES],'titles':{s.id:s.title for s in SCENES},'modes':{s.id:s.mode for s in SCENES},'theme_clusters':{'vikalpa_refinement':['vm01','vm02','vm03','vm04','vm05'],'mantra_vitality':['vm06','vm07','vm08','vm09'],'true_japa':['vm10','vm11','vm12','vm13'],'seal':['vm14']},'reusability_notes':{'vm02':'Use for conceptual contraction and self-limitation.','vm03':'Use for counter-concept and cognitive deconstruction.','vm04':'Use for sattarka or reasoned alignment.','vm05':'Use for progressive cognitive refinement.','vm06':'Use for inert formula versus living practice.','vm07':'Use for mantra vitality.','vm10':'Use for mechanical versus inward repetition.','vm11':'Use for true japa and parāmarśa.','vm12':'Use for inner/outer integration.','vm14':'Use as the living-mantra closing seal.'}}
    (ROOT/'scene_catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False),encoding='utf-8')
    (ROOT/'AGENT_KNOWLEDGE_DOSSIER.md').write_text('''# AGENT KNOWLEDGE DOSSIER — Vikalpa, Mantra-vīrya, True Japa\n\n## Doctrinal engine\nChapter 4 does not oppose thought and realization in a simplistic way. Binding vikalpa can be countered by a liberating vikalpa, refined through right reasoning, and made transparent to awareness.\n\n## Mantra vitality\nMantra-vīrya is not represented as acoustic loudness or magical charge. It is the conscious potency by which phoneme, meaning, and reflective awareness operate as one living act.\n\n## True japa\nThe Tantrasāra defines japa as inward parāmarśa of the supreme principle as one’s own nature, independent of the diversity of external and internal knowables.\n\n## Visual restrictions\n- Do not portray thought as inherently evil.\n- Do not reduce mantra to sound waves.\n- Do not claim that counting is useless; distinguish counted repetition from the text’s definition of true inward japa.\n- Do not turn the pack into a procedural ritual manual.\n\n## Source-status system\n- direct: closely tied to textual statement\n- derived: interpretive visualization supported by the text\n- synthetic: explanatory synthesis\n''',encoding='utf-8')
    (ROOT/'SOURCE_NOTES.md').write_text('''# SOURCE NOTES — Vikalpa, Mantra-vīrya, True Japa\n\n## Primary structure\n- Tantrāloka 4.2–12: purification and empowerment of conceptual thought.\n- Tantrāloka 4.13–32cd: the nature of right reasoning.\n- Tantrāloka 4.181cd–193: vitality of mantra.\n- Tantrāloka 4.194–203: true repetition of mantra.\n\n## Condensed witness\nAbhinavagupta’s Tantrasāra Chapter 4 states that beings consider themselves bound through the force of vikalpa, and that an opposing vikalpa can break the thought that causes bondage. It identifies sattarka as a direct means and defines japa as inward reflective awareness of the supreme principle as one’s own nature.\n\n## Critical cautions\n- Scene 6’s “inert shell” is a derived contrast, not a quotation.\n- Scene 9’s sound–meaning–awareness triangle is synthetic.\n- Scene 13’s continuous luminous band is a pedagogical inference and is not labeled ajapa.\n''',encoding='utf-8')
    (ROOT/'STYLE_EVOLUTION.md').write_text('''# STYLE EVOLUTION — Living-Mantra Pack\n\n## New material vocabulary\n- unlined ivory cognitive field\n- black ink contraction knots\n- transparent reasoning glass\n- ruby counter-vikalpa filament\n- dim and awakened phoneme orbits\n- gold heart-wave circuitry\n- continuous recognition band\n\n## New relationships\n1. binding vikalpa → counter-vikalpa\n2. reasoning → cognitive alignment\n3. phoneme shell → mantra vitality\n4. repetition → inward parāmarśa\n5. inner and outer knowables → twofold awareness\n\n## Closing seal\nThree interlocking ellipses—vikalpa, vīrya, and japa—fold into a ruby-gold awareness eye.\n''',encoding='utf-8')
    (ROOT/'README.md').write_text(f'''# Tantrāloka — Vikalpa, Mantra-vīrya, and True Japa\n\nIncluded:\n- vikalpa_mantravirya_japa_animation.mp4\n- contact_sheet.jpg\n- scenes/*.mp4\n- render_pack.py\n- scene_manifest.json\n- scene_catalog.json\n- AGENT_KNOWLEDGE_DOSSIER.md\n- SOURCE_NOTES.md\n- STYLE_EVOLUTION.md\n- validation.json\n\nSpecs:\n- {W}x{H}\n- {FPS} fps\n- {len(SCENES)} scenes\n- {DURATION}s per scene\n- {len(SCENES)*DURATION:.1f}s total\n\nRender:\n```bash\npython render_pack.py\n```\n\nThe renderer is resume-safe.\n''',encoding='utf-8')

def validate_outputs():
    combined=ROOT/'vikalpa_mantravirya_japa_animation.mp4'
    probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height,r_frame_rate,codec_name,pix_fmt:format=duration,size','-of','json',str(combined)]))
    scene_files=[]
    for s in SCENES:
        fp=SCENES_ROOT/f'{s.id}.mp4'; scene_files.append({'id':s.id,'exists':fp.exists(),'size_bytes':fp.stat().st_size if fp.exists() else 0})
    val={'combined_probe':probe,'scene_files':scene_files,'expected_scene_count':len(SCENES),'expected_duration_seconds':round(len(SCENES)*DURATION,2),'contact_sheet_exists':(ROOT/'contact_sheet.jpg').exists()}
    (ROOT/'validation.json').write_text(json.dumps(val,indent=2),encoding='utf-8')

def make_zip():
    z=ROOT/'vikalpa_mantravirya_japa_pack.zip'
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as zf:
        for name in ['vikalpa_mantravirya_japa_animation.mp4','contact_sheet.jpg','scene_manifest.json','scene_catalog.json','AGENT_KNOWLEDGE_DOSSIER.md','SOURCE_NOTES.md','STYLE_EVOLUTION.md','render_pack.py','README.md','validation.json']:
            zf.write(ROOT/name,arcname=name)
        for fp in sorted(SCENES_ROOT.glob('*.mp4')): zf.write(fp,arcname=f'scenes/{fp.name}')

def render_all():
    FRAMES_ROOT.mkdir(exist_ok=True); SCENES_ROOT.mkdir(exist_ok=True)
    for s in SCENES:
        print('Rendering',s.id,s.title,flush=True); render_scene(s)
    concat=ROOT/'concat_list.txt'; concat.write_text('\n'.join([f"file '{(SCENES_ROOT/(s.id+'.mp4')).as_posix()}'" for s in SCENES]))
    combined=ROOT/'vikalpa_mantravirya_japa_animation.mp4'
    if not combined.exists() or combined.stat().st_size<100000:
        subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(combined)],check=True)
    make_contact_sheet(); write_metadata(); validate_outputs(); make_zip(); print('DONE',ROOT,flush=True)

if __name__=='__main__': render_all()
