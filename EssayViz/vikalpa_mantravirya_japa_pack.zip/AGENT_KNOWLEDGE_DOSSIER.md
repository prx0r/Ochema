# AGENT KNOWLEDGE DOSSIER — Vikalpa, Mantra-vīrya, True Japa

## Doctrinal engine
Chapter 4 does not oppose thought and realization in a simplistic way. Binding vikalpa can be countered by a liberating vikalpa, refined through right reasoning, and made transparent to awareness.

## Mantra vitality
Mantra-vīrya is not represented as acoustic loudness or magical charge. It is the conscious potency by which phoneme, meaning, and reflective awareness operate as one living act.

## True japa
The Tantrasāra defines japa as inward parāmarśa of the supreme principle as one’s own nature, independent of the diversity of external and internal knowables.

## Visual restrictions
- Do not portray thought as inherently evil.
- Do not reduce mantra to sound waves.
- Do not claim that counting is useless; distinguish counted repetition from the text’s definition of true inward japa.
- Do not turn the pack into a procedural ritual manual.

## Source-status system
- direct: closely tied to textual statement
- derived: interpretive visualization supported by the text
- synthetic: explanatory synthesis
