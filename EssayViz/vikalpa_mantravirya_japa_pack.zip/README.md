# Tantrāloka — Vikalpa, Mantra-vīrya, and True Japa

Included:
- vikalpa_mantravirya_japa_animation.mp4
- contact_sheet.jpg
- scenes/*.mp4
- render_pack.py
- scene_manifest.json
- scene_catalog.json
- AGENT_KNOWLEDGE_DOSSIER.md
- SOURCE_NOTES.md
- STYLE_EVOLUTION.md
- validation.json

Specs:
- 1280x720
- 10 fps
- 14 scenes
- 4.8s per scene
- 67.2s total

Render:
```bash
python render_pack.py
```

The renderer is resume-safe.
