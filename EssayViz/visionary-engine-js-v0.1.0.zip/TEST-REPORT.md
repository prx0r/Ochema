# Test Report

Executed:

```bash
npm test
npm run validate
npm run compile:example
```

Result:

```text
8 tests passed
Essay 3 project valid: 9 beats
11 compilation artifacts emitted
```

The package does not render Skia frames by itself. Rendering is delegated to an
installed `MOTHERFUCKER` framework root through the backend adapter.
