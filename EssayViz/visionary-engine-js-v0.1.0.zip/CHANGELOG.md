# Changelog

## 0.1.0

- Formalized essay source locks and argument IR.
- Added continuity, candidate, storyboard, typography, signal, timing, render
  and review planners.
- Added typed registries for capabilities, composition, style, motion, signals,
  typography and motifs.
- Added a `MOTHERFUCKER` backend adapter.
- Added CLI commands: validate, compile, doctor and render.
- Added four agent skills.
- Added schemas and extension templates.
- Added a complete Essay 3 reference project.
- Added end-to-end compiler tests.
