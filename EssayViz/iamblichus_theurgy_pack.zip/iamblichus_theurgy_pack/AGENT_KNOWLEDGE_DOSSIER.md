# AGENT KNOWLEDGE DOSSIER — Iamblichus / Theurgy

## Aim
This pack visualizes key Iamblichean ideas in a refined, abstract, reusable way for philosophical documentary video.

## Core ideas represented
1. **Theurgy exceeds discursive philosophy**
2. **Hierarchy of divine kinds**: gods, archangels, angels, daimons, heroes, archons, souls
3. **Vertical causality**: higher causes are present in lower effects according to mode and capacity
4. **Epitēdeiotēs / receptivity**: the participant must be prepared to receive
5. **Symbola / synthēmata**: sacred signs rooted in divine order
6. **Divine names**: symbolic vocal vehicles
7. **Purification**: preparation and refinement of the participant
8. **Invocation without coercion**: gods are not forced; the participant is aligned
9. **Descent of presence**: a superior causality manifests downward
10. **Immanence and transcendence**: the divine is present without being reduced
11. **Body as ritual interface**: material and embodied forms can mediate divine relation
12. **Prayer / ascent / anagogy**: attention and soul lifted upward by symbolic means

## Visual rules
- Preserve hierarchy. Iamblichus is vertically ordered.
- Do not depict theurgy as magical domination or button-pushing.
- Keep rituals conceptual and symbolic, not operational or procedural.
- Higher orders should feel calm, ordered, and superior rather than theatrical.
- Descent of presence is crucial: do not model everything as human effort alone.
- Symbols should look rooted and archetypal, not arbitrary graphic decoration.

## Style family
- Warm white background
- Black geometry and line work
- Crimson for divine source, descending presence, and decisive causal emphasis
- Grey/soft lines for mediated relations and secondary structures
- More ritual verticality than Proclus, but still minimal and diagrammatic

## Reuse guidance
- `ia02`–`ia05`: hierarchy and kinds of beings
- `ia06`–`ia07`: causality and receptivity
- `ia08`–`ia09`: symbola, synthēmata, divine names
- `ia10`–`ia12`: philosophy vs theurgy, purification, non-coercive invocation
- `ia13`–`ia19`: descent, embodied ritual, anagogy, illumination
- `ia20`: closing synthesis frame

## Comparison guardrails
- Do not reduce theurgy to modern psychology, even if you later compare them.
- Do not confuse Iamblichean theurgy with later occultism without historical framing.
- Do not depict gods as anthropomorphic figures unless the documentary itself explicitly chooses that idiom.
- When compared with Trika, Sufism, or Kabbalah, keep the analogies structural, not identity claims.

## Backend note
These scenes are portable semantic diagrams.
A more advanced renderer can preserve the same scene logic while upgrading:
- typography
- easing
- line fidelity
- shader glow
- layer-based camera motion
- richer symbol animation
