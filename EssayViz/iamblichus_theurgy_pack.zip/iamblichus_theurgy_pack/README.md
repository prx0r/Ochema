# Iamblichus — Theurgy Pack

Included files:
- iamblichus_theurgy_animation.mp4
- contact_sheet.jpg
- scene_manifest.json
- scene_catalog.json
- AGENT_KNOWLEDGE_DOSSIER.md
- README.md

Specs:
- Resolution: 1280x720
- FPS: 12
- Scene count: 20
- Duration per scene: 4.4s
- Total runtime: 1.5 minutes
