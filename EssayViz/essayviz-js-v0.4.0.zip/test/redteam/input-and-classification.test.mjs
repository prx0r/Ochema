import test from 'node:test';
import assert from 'node:assert/strict';
import { writeFile, mkdtemp, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { ingestEssay } from '../../src/ingest/essay-ingestor.mjs';
import { compileEssay } from '../../src/compiler/essay-compiler.mjs';

const fixture=name=>new URL(`../fixtures/redteam/${name}`,import.meta.url);

test('short keyword-poem abstains instead of confidently becoming tutorial',async()=>{
  const result=await ingestEssay(fixture('keywords-poem.md'));
  assert.equal(result.classification.abstained,true);
  assert.equal(result.classification.genre,'unclassified');
});

test('short science-keyword poem abstains',async()=>{
  const result=await ingestEssay(fixture('science-poem.md'));
  assert.equal(result.classification.abstained,true);
});

test('code blocks are excluded from prose classification',async()=>{
  const result=await ingestEssay(fixture('code-heavy.md'),{genre:'tutorial'});
  assert.equal(result.parsed.codeBlocks.length,1);
  assert.ok(!result.parsed.paragraphs.some(p=>p.text.includes('premise = model.data')));
});

test('inline math is extracted',async()=>{
  const result=await ingestEssay(fixture('inline-math.md'),{genre:'logical-proof'});
  assert.equal(result.parsed.equations.length,2);
});

test('non-latin heuristic classification abstains without explicit genre',async()=>{
  const result=await ingestEssay(fixture('multilingual.md'));
  assert.equal(result.classification.abstained,true);
  assert.ok(result.classification.warnings.some(x=>x.includes('devanagari')));
});

test('instruction-like source text is flagged as data risk',async()=>{
  const result=await ingestEssay(fixture('adversarial.md'),{genre:'science'});
  assert.ok(result.sourceRisks.length>0);
});

test('empty source fails before project compilation',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'essayviz-empty-'));const path=join(dir,'empty.md');await writeFile(path,'');
  try{await assert.rejects(()=>compileEssay(path),e=>e.code==='EMPTY_SOURCE');}finally{await rm(dir,{recursive:true,force:true});}
});

test('oversized word input is rejected by policy',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'essayviz-large-'));const path=join(dir,'large.md');await writeFile(path,'# Large\n\n'+('word '.repeat(5000)));
  try{await assert.rejects(()=>compileEssay(path,{inputPolicy:{maxWords:1000}}),e=>e.code==='INPUT_TOO_LARGE');}finally{await rm(dir,{recursive:true,force:true});}
});
