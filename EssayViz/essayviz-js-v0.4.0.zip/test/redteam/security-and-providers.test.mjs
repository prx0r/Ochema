import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, mkdir, rm, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { loadPack } from '../../src/packs/pack-loader.mjs';
import { clearTtsProviders, registerTtsProvider } from '../../src/providers/tts/registry.mjs';
import { MockTtsProvider } from '../../src/providers/tts/mock-provider.mjs';
import { synthesizeNarration } from '../../src/providers/tts/orchestrator.mjs';
import { createElevenLabsTtsProvider } from '../../src/providers/tts/elevenlabs-provider.mjs';
import { createMcpServer } from '../../src/mcp/server.mjs';

test('pack runtime code is denied by default',async()=>{
  const path=new URL('../../examples/expansion-packs/advanced-animation/pack.json',import.meta.url).pathname;
  await assert.rejects(()=>loadPack(path,{loadRuntime:true}),e=>e.code==='UNTRUSTED_PACK_RUNTIME');
});

test('pack runtime cannot escape trusted root',async()=>{
  const dir=await mkdtemp(join(tmpdir(),'essayviz-pack-'));const outside=join(dir,'outside.mjs');const packDir=join(dir,'pack');await mkdir(packDir);await writeFile(outside,'export function register(){return {registered:true}}');
  await writeFile(join(packDir,'pack.json'),JSON.stringify({id:'escape',type:'animation',provides:{entries:[]},runtimeModule:'../outside.mjs'}));
  try{await assert.rejects(()=>loadPack(join(packDir,'pack.json'),{loadRuntime:true,allowRuntimeCode:true,allowedRoots:[packDir]}),e=>e.code==='PACK_PATH_ESCAPE');}finally{await rm(dir,{recursive:true,force:true});}
});

test('mock TTS provider synthesizes every scene and returns alignment',async()=>{
  clearTtsProviders();registerTtsProvider(new MockTtsProvider());const dir=await mkdtemp(join(tmpdir(),'essayviz-tts-'));
  try{const manifest=await synthesizeNarration({timing:{scenes:[{sceneId:'s1',narration:'Hello world'}]},providerId:'mock',voice:'mock',outputDirectory:dir,format:'bin'});assert.equal(manifest.scenes.length,1);assert.ok(manifest.scenes[0].alignment.characters.length>0);assert.match((await readFile(manifest.scenes[0].audioPath)).toString(),/^MOCK:/);}finally{await rm(dir,{recursive:true,force:true});}
});

test('ElevenLabs adapter parses timestamp response through injected fetch',async()=>{
  const fetchImpl=async()=>({ok:true,json:async()=>({audio_base64:Buffer.from('audio').toString('base64'),alignment:{characters:['H'],character_start_times_seconds:[0],character_end_times_seconds:[.1]}})});
  const provider=createElevenLabsTtsProvider({apiKey:'test',fetchImpl});const dir=await mkdtemp(join(tmpdir(),'essayviz-eleven-'));
  try{const result=await provider.synthesize({text:'Hi',voice:'voice',outputPath:join(dir,'a.mp3')});assert.equal(result.alignment.characters[0],'H');}finally{await rm(dir,{recursive:true,force:true});}
});

test('MCP server exposes tools and handles unknown methods',async()=>{
  const server=createMcpServer();const init=await server.handle({jsonrpc:'2.0',id:1,method:'initialize',params:{}});assert.equal(init.result.serverInfo.name,'essayviz');const tools=await server.handle({jsonrpc:'2.0',id:2,method:'tools/list',params:{}});assert.ok(tools.result.tools.some(t=>t.name==='essayviz.planEssay'));const unknown=await server.handle({jsonrpc:'2.0',id:3,method:'nope',params:{}});assert.equal(unknown.error.code,-32601);
});
