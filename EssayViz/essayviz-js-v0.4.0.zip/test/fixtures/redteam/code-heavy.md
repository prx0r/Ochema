# A renderer tutorial

```js
if (field) then(render());
const premise = model.data;
```

Open the project and run the command.
