import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { parseMarkdownEssay } from "../src/ingest/markdown-parser.mjs";
import { classifyEssay } from "../src/classification/genre-classifier.mjs";
import { compileEssay } from "../src/compiler/essay-compiler.mjs";
import { AttractorEngine, createAttractorPreset, ParticleFieldEngine, particleFields, DiagramEngine } from "../src/engines/index.mjs";
import { ShaderGraph, createLygiaManifest, stableAttractorShaderPrototype } from "../src/shaders/index.mjs";
import { buildWordTimeline, planTightCoupling } from "../src/audio/word-sync.mjs";

const expected = {
  "logical-proof.md": "logical-proof",
  "poem.md": "poem",
  "explanatory.md": "explanatory",
  "science.md": "science",
  "comparative.md": "comparative",
  "textual-scholarship.md": "textual-scholarship",
  "tutorial.md": "tutorial",
};

for (const [file, genre] of Object.entries(expected)) {
  test(`classifies ${file} as ${genre}`, async () => {
    const source = await readFile(new URL(`../examples/genres/${file}`, import.meta.url), "utf8");
    const classification = classifyEssay(parseMarkdownEssay(source));
    assert.equal(classification.genre, genre);
  });
}

test("compiles an essay from raw markdown through all layers", async () => {
  const result = await compileEssay(new URL("../examples/genres/science.md", import.meta.url), { maxBeats: 8 });
  assert.equal(result.ingestion.classification.genre, "science");
  assert.equal(result.coverage.coverage, 1);
  assert.equal(result.project.beats.length, result.scenePack.scenes.length);
  assert.ok(result.strategy.beats.some((beat) => beat.selected.mode === "field"));
  assert.ok(result.wordSync.scenes.every((scene) => scene.words.length > 0));
});

test("stable attractor converges", () => {
  const engine = new AttractorEngine(createAttractorPreset("calm-focus"));
  const points = engine.trajectory({ x: 2, y: -2 }, { steps: 600 });
  const last = points.at(-1);
  assert.ok(Math.abs(last.x) < 0.01);
  assert.ok(Math.abs(last.y) < 0.01);
});

test("particle field is deterministic", () => {
  const options = { count: 8, seed: 42, field: particleFields.vortex() };
  const a = new ParticleFieldEngine(options);
  const b = new ParticleFieldEngine(options);
  assert.deepEqual(a.step(1 / 60, 0.1), b.step(1 / 60, 0.1));
});

test("diagram engine separates layout from graph semantics", () => {
  const graph = { nodes: [{ id: "a", level: 0 }, { id: "b", level: 1 }], edges: [{ from: "a", to: "b" }] };
  const layout = new DiagramEngine({ layout: "layered" }).arrange(graph);
  assert.equal(layout.edges[0].from, "a");
  assert.notEqual(layout.nodes[0].y, layout.nodes[1].y);
});

test("shader graph topologically orders nodes", () => {
  const graph = new ShaderGraph().add("uv", "coordinates").add("field", "vector").add("ink", "render").connect("uv", "field").connect("field", "ink");
  assert.deepEqual(graph.manifest().order, ["uv", "field", "ink"]);
});

test("LYGIA manifest rejects unknown categories", () => {
  assert.throws(() => createLygiaManifest({ includes: ["unknown/foo"] }));
  assert.ok(stableAttractorShaderPrototype().lygia.includes.includes("space/ratio"));
});

test("word-level coupling preserves duration", () => {
  const timeline = buildWordTimeline("Therefore the edge becomes licensed", { duration: 5 });
  assert.ok(Math.abs(timeline.at(-1).end - 5) < 1e-9);
  const plan = planTightCoupling({ narration: "Therefore the edge becomes licensed", duration: 5, semanticCues: [{ id: "c", pattern: "Therefore" }] });
  assert.ok(plan.semanticCues[0].time !== null);
});
