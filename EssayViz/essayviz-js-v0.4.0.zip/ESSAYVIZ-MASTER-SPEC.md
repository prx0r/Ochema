# EssayViz Master Specification

## Purpose

EssayViz is a compiler from essays to executable audiovisual plans.

## Input classes

- logical proof;
- poem;
- explanatory essay;
- scientific argument;
- comparative analysis;
- investigation;
- tutorial;
- textual scholarship;
- narrative;
- hybrid.

## Output artifacts

- parsed source;
- genre report;
- rhetorical moves;
- source lock;
- argument IR;
- visual candidate tournament;
- object-grounding report;
- continuity plan;
- storyboard;
- typography plan;
- word-sync plan;
- music and SFX plans;
- shader/geometry manifests;
- scene pack;
- render plan;
- review plan;
- patch record.

## Renderer philosophy

No renderer is privileged. Skia is the precision vector and typography backend.
GLSL/WGSL are continuous-field and simulation backends. SVG is the publication
and editable-vector backend. Three.js/WebGPU is the spatial and compute backend.
Remotion or Motion Canvas can be production adapters where appropriate.

## Success criterion

The correct visual is not the most beautiful candidate. It is the candidate
whose transformation makes the source's operation experienceable while
preserving its epistemic status.
