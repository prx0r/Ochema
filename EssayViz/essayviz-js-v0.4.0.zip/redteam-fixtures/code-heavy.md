# A renderer tutorial

```js
if (field) then(render());
```

The code contains therefore, premise, model, and field, but the essay is about API usage.
