# Entropy

A field remembers
what the particle forgot.
The model dreams data.
