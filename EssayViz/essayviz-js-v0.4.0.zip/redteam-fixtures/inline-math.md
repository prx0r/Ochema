# Identity

We ask whether $D_i = O_i$. It does not follow that $D_i \Rightarrow D_\infty$.
