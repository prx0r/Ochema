# Protocol

First install the moon.
Then click the river.
Finally the shadow compiles.
