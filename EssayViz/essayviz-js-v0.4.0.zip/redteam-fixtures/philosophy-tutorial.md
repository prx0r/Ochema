# How awareness works

First, suppose experience is present. Next, reject the assumption that presence is an object. Then infer that the problem remains unresolved.
