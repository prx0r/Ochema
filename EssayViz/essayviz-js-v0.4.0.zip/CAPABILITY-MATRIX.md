# EssayViz Capability Matrix

| Layer | Implemented | Examples |
|---|---:|---|
| Markdown ingestion | Yes | headings, paragraphs, equations, references |
| Genre routing | Yes | proof, poem, explanation, science, comparison, investigation, tutorial, scholarship |
| Rhetorical analysis | Yes | contention, premise, rival, mechanism, discriminator, frontier |
| Visual modes | Yes | notation, diagram, object, field, particles, symbolic, typographic, cinematic |
| Exact-object grounding | Yes | neuro, anatomy, subtle body, text, math, physics, biology, ritual |
| Continuity systems | Yes | conserved, transformable and forbidden properties |
| Typography | Yes | prose/math tokenization, layouts, profile packs |
| Audio | Yes | word cues, score events, music features, SFX cues |
| Attractors | Yes | stable node, spiral, saddle, double well, limit cycle, Lorenz |
| Particles | Yes | vortex, sink, source, wave, nāḍī flow |
| Diagram layouts | Yes | chain, fork, matrix, radial, layered |
| Shader graphs | Yes | topological manifests and prototypes |
| LYGIA integration | Manifest | local resolution required; source not redistributed |
| Backends | Profiles/manifests | Skia, SVG, regl, Motion Canvas, Remotion, Three/WebGPU, Pixi |
| Agent skills | Yes | roles plus eight genre skills |
| Render perception loop | Planned | review and patch artifacts; live render required |
