import {
  capabilityRegistry, styleRegistry, motionRegistry
} from "@prx0r/visionary-engine/registries";

capabilityRegistry.register("my-topology-pack", {
  kind:"capability",
  relations:["coupling","bifurcation"],
  mechanisms:["kernel-split","graded-fission"]
});

styleRegistry.register("etched-scientific", {
  theme:"whiteScientific",
  material:"etched-metal",
  density:"sparse"
});

motionRegistry.register("hysteretic-split", {
  verbs:["strain","separate","retain","snap"],
  randomAccess:"checkpointed"
});
