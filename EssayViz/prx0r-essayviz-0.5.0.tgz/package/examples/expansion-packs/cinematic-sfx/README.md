# Cinematic Sfx

Working `sound-effect` example pack.
