export async function register({pack}){ return {registered:true,id:pack.id,type:pack.type}; }
