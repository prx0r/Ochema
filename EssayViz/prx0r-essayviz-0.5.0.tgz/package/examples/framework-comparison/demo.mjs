import { mkdir,writeFile } from "node:fs/promises";import { resolve,dirname } from "node:path";
const frameworks=[
 {id:"lygia",layer:"shader functions",borrow:"granular cross-language primitives",essayGap:"no rhetorical compiler"},
 {id:"regl",layer:"GPU commands",borrow:"stateless resources and draw commands",essayGap:"no semantic selection"},
 {id:"motion-canvas",layer:"vector animation",borrow:"signals, generators and time events",essayGap:"no source analysis"},
 {id:"hydra",layer:"visual synthesis",borrow:"composable transform chains and feedback",essayGap:"no evidence contracts"},
 {id:"remotion",layer:"video production",borrow:"parameterized rendering and agent skills",essayGap:"no visual rhetoric"},
 {id:"elkjs",layer:"diagram layout",borrow:"specialized layout algorithms",essayGap:"cannot choose graph meaning"},
 {id:"tone",layer:"audio scheduling",borrow:"transport and sample-accurate event timing",essayGap:"does not choose form"}
];
const out=resolve(process.argv[2]??"build/framework-comparison/report.json");await mkdir(dirname(out),{recursive:true});await writeFile(out,JSON.stringify({version:"1.0",frameworks,essayviz:"rhetoric-to-visual compiler"},null,2)+"\n");console.log(out);
