import { readdir,writeFile,mkdir } from "node:fs/promises";
import { join,resolve } from "node:path";
import { compileEssay } from "../../src/compiler/essay-compiler.mjs";
const output=resolve(process.argv[2]??"build/genre-lab/report.json");const dir=new URL("../genres/",import.meta.url);const files=(await readdir(dir)).filter(x=>x.endsWith(".md"));const results=[];
for(const file of files){const compiled=await compileEssay(new URL(`../genres/${file}`,import.meta.url),{genre:"auto",maxBeats:8});results.push({file,genre:compiled.ingestion.classification.genre,confidence:compiled.ingestion.classification.confidence,moves:compiled.ingestion.rhetoric.moves.length,beats:compiled.project.beats.length,selectedModes:[...new Set(compiled.strategy.beats.map(b=>b.selected.mode))],coverage:compiled.coverage.coverage});}
await mkdir(resolve(output,".."),{recursive:true});await writeFile(output,JSON.stringify({version:"1.0",results},null,2)+"\n");console.log(output);
