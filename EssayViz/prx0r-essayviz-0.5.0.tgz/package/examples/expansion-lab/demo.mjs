import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import {
  registerBuiltins,
  objectRegistry, animationRegistry, transitionRegistry, musicRegistry,
  soundEffectRegistry, typographyRegistry, layoutRegistry,
  TimelineEngine, AnimationEngine, VisualObjectEngine, SignalEngine,
  createTransition, planMusic, planSoundEffects, compileCueSheet,
  TypographyLayoutEngine, tokenizeNotation, loadPack
} from "../../src/index.mjs";

registerBuiltins();
const packIds=[
  "precision-typography","continuity-objects","advanced-animation",
  "semantic-transitions","music-forms","cinematic-sfx","editorial-layouts"
];
const loaded=[];
for(const id of packIds){
  loaded.push(await loadPack(new URL(`../expansion-packs/${id}/pack.json`,import.meta.url).pathname));
}

const objectEngine=new VisualObjectEngine();
const seed=objectEngine.instantiate("fivefold-seed",{scale:1,rotation:0},{
  meaning:"identity through change",conserved:["fivefold contour","rhythmic signature"],
  transformable:["scale","rotation","carrier"],forbidden:["unrelated replacement"]
});
objectEngine.transform(seed.id,{scale:1.8,rotation:Math.PI/5,carrier:"gold-thread"});

const timeline=new TimelineEngine({
  duration:12,
  events:[
    {id:"seed-entry",time:0,end:4},
    {id:"carrier-transfer",time:4,end:8},
    {id:"recognition",time:8,end:12}
  ]
});
const animation=new AnimationEngine([
  {target:"seed.scale",start:0,duration:12,from:1,to:1.8,easing:"easeInOut"},
  {target:"seed.rotation",start:0,duration:12,from:0,to:Math.PI*2,easing:"linear"}
]);
const signals=new SignalEngine([
  {source:"onset",target:"particles.emit",attack:.02,release:.2,range:[0,40]},
  {source:"speechDensity",target:"secondary.opacity",attack:.1,release:.5,range:[1,.15]}
]);
const transition=createTransition({
  verb:"transfer",from:"cello-carrier",to:"flute-carrier",
  invariant:"interval-rhythm relation",duration:2
});
const typography=new TypographyLayoutEngine({minimumBodyPx:14});
const layout=typography.layout([
  {id:"equation",text:"D_i ↔ O_i",size:34},
  {id:"caption",text:"One token identity under two modes of access.",size:18}
]);

const music=planMusic({
  form:"passacaglia",thesis:"identity persists through carrier turnover",
  continuityObject:"fivefold-seed",
  stages:[
    {id:"opening",function:"present ground",subjectPresence:1},
    {id:"transfer",function:"migrate carrier",subjectPresence:.7},
    {id:"recognition",function:"return relational identity",subjectPresence:1}
  ]
});
const storyboard={scenes:[
  {id:"s1",operation:"introduce seed"},
  {id:"s2",operation:"transfer carrier"},
  {id:"s3",operation:"recognize invariant"}
]};
const timing={duration:12,scenes:[
  {sceneId:"s1",start:0},{sceneId:"s2",start:4},{sceneId:"s3",start:8}
]};
const sfx=planSoundEffects(storyboard);
const cueSheet=compileCueSheet({timing,music,sfx});

const report={
  loadedPacks:loaded.map(x=>({id:x.pack.id,type:x.pack.type,registered:x.registration?.registered??false})),
  builtinCounts:{
    objects:objectRegistry.list().length,
    animations:animationRegistry.list().length,
    transitions:transitionRegistry.list().length,
    music:musicRegistry.list().length,
    soundEffects:soundEffectRegistry.list().length,
    typography:typographyRegistry.list().length,
    layouts:layoutRegistry.list().length
  },
  visualObjects:objectEngine.snapshot(),
  timelineSamples:[0,4,8,12].map(time=>timeline.at(time)),
  animationSamples:[0,6,12].map(time=>({time,values:animation.sample(time)})),
  signalSamples:[
    signals.sample({onset:0,speechDensity:0},1/60),
    signals.sample({onset:1,speechDensity:1},1/60)
  ],
  transition,
  typography:{tokens:tokenizeNotation("The claim D_i ↔ O_i remains hypothetical."),layout},
  cueSheet
};

const output=resolve(process.argv[2]??"build/expansion-lab/report.json");
await mkdir(resolve(output,".."),{recursive:true});
await writeFile(output,JSON.stringify(report,null,2)+"\n");
console.log(output);
