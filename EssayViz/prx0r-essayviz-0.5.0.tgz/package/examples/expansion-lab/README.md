# Expansion Laboratory

Runs all first-class extension categories together.

```bash
node examples/expansion-lab/demo.mjs build/expansion-lab/report.json
```

The report proves:

- dynamic pack loading;
- runtime registration;
- visual-object conservation laws;
- random-access timeline sampling;
- deterministic animation;
- signal smoothing;
- semantic transitions;
- typography tokenization and layout;
- music-form planning;
- SFX cue timing.
