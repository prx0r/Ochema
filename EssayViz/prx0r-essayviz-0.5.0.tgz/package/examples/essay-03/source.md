# Essay 3 — Description Is Not Presence

Reference example based on the user-supplied essay. The complete source should
remain alongside this project in production. The project locks the essay's
distinctions among description, realization and identity, and preserves the
final identity-versus-correlation frontier.
