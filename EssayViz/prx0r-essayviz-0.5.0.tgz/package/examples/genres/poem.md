# The River Remembers No Water

The river keeps its name while every bright fragment leaves.
It bends around stone, carrying a shape made only of departure.

Again the moon breaks upon it. Again the pieces join downstream.
What returns is not the water, but the relation that lets water become a river.