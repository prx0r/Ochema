# Why an Unsupported Bridge Fails

The exact contention is that a model of report does not by itself explain felt presence.

1. A report system can discriminate and communicate internal states.
2. Discrimination and communication are functional capacities.
3. Felt presence is not defined as either capacity.

Therefore a further identity premise is required. However, this does not prove that physicalism is false. What remains unresolved is which organization, if any, is identical with presence.