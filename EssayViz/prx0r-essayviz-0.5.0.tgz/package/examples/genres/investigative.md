# The Missing Manuscript Diagram

A catalogue records a circular diagram, but the surviving folio contains only a rectangular stain. One hypothesis is that the diagram was cut out. Another is that the catalogue described a different copy. Ink transfer on the facing page supports the first hypothesis, while a mismatched folio number supports the second. The evidence does not yet decide the case.