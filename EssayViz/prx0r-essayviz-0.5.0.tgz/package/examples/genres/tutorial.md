# Build a Three-Step Argument Diagram

First create three proposition nodes. Next connect the first two premises to the conclusion with neutral dependency edges. Then mark the final unsupported implication with a dashed edge. Verify that the solid and dashed relations remain distinguishable at the target video resolution. Finally export a contact sheet and inspect all labels for collision.