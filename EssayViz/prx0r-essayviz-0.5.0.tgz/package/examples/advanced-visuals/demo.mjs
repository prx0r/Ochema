import { mkdir,writeFile } from "node:fs/promises";import { resolve,dirname } from "node:path";
import { AttractorEngine,createAttractorPreset,ParticleFieldEngine,particleFields,DiagramEngine } from "../../src/engines/index.mjs";
import { stableAttractorShaderPrototype,reactionDiffusionPrototype,signedDistanceWorldPrototype } from "../../src/shaders/index.mjs";
import { planTightCoupling } from "../../src/audio/word-sync.mjs";
import { listBackends,recommendBackend,reglManifest } from "../../src/index.mjs";
const attractors={};for(const id of ["calm-focus","conceptual-tension","rival-bifurcation","self-organizing-cycle"]){const engine=new AttractorEngine(createAttractorPreset(id));attractors[id]=engine.trajectory({x:1.2,y:-.8},{steps:120}).filter((_,i)=>i%20===0);}
const particles=new ParticleFieldEngine({count:12,seed:9,field:particleFields.nadi()});let particleSnapshot;for(let i=0;i<60;i++)particleSnapshot=particles.step(1/60,i/60);
const graph={nodes:[{id:"p1",level:0},{id:"p2",level:0},{id:"c",level:1},{id:"u",level:2}],edges:[{from:"p1",to:"c"},{from:"p2",to:"c"},{from:"c",to:"u",status:"unsupported"}]};
const diagrams=Object.fromEntries(["chain","fork","matrix","radial","layered"].map(layout=>[layout,new DiagramEngine({layout}).arrange(graph)]));
const shaders={stable:stableAttractorShaderPrototype(),reactionDiffusion:reactionDiffusionPrototype(),sdf:signedDistanceWorldPrototype()};
const sync=planTightCoupling({narration:"Because the premises converge, therefore the conclusion becomes licensed, but the final bridge does not.",duration:9,semanticCues:[{id:"because",pattern:"Because"},{id:"therefore",pattern:"therefore"},{id:"not",pattern:"not"}]});
const report={version:"1.0",attractors,particleSnapshot,diagrams,shaders,regl:reglManifest(shaders.stable),wordSync:sync,backends:listBackends(),recommendations:{notation:recommendBackend({mode:"notation"}).id,field:recommendBackend({mode:"field"}).id,cinematic:recommendBackend({mode:"cinematic"}).id}};
const out=resolve(process.argv[2]??"build/advanced-visuals/report.json");await mkdir(dirname(out),{recursive:true});await writeFile(out,JSON.stringify(report,null,2)+"\n");console.log(out);
