export function createLogger({ sink = console, context = {} } = {}) {
  const emit = (level, event, details = {}) => {
    const record = { ts: new Date().toISOString(), level, event, ...context, ...details };
    const method = level === 'error' ? 'error' : level === 'warn' ? 'warn' : 'log';
    sink[method]?.(JSON.stringify(record));
    return record;
  };
  return {
    child(extra) { return createLogger({ sink, context: { ...context, ...extra } }); },
    info(event, details) { return emit('info', event, details); },
    warn(event, details) { return emit('warn', event, details); },
    error(event, details) { return emit('error', event, details); },
  };
}
