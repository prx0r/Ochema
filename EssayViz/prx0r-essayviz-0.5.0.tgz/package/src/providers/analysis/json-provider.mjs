import { readJson } from '../../core/fs.mjs';
import { AnalysisProvider, validateAnalysisResult } from './provider.mjs';
export class JsonAnalysisProvider extends AnalysisProvider {
  constructor(path){super('json');this.path=path;}
  async analyze(){return validateAnalysisResult(await readJson(this.path));}
}
