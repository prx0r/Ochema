import { VisionaryError } from '../../core/errors.mjs';
export class AnalysisProvider {
  constructor(id){this.id=id;}
  async analyze(_request){throw new VisionaryError(`Analysis provider ${this.id} does not implement analyze`,{code:'NOT_IMPLEMENTED'});}
}
export function validateAnalysisResult(result){
  if(!result||typeof result!=='object')throw new VisionaryError('Invalid analysis result',{code:'INVALID_ANALYSIS'});
  if(!result.classification?.genre)throw new VisionaryError('Analysis result missing classification.genre',{code:'INVALID_ANALYSIS'});
  if(!Array.isArray(result.rhetoric?.moves))throw new VisionaryError('Analysis result missing rhetoric.moves',{code:'INVALID_ANALYSIS'});
  for(const move of result.rhetoric.moves){for(const field of ['id','section','text','role','relation'])if(typeof move[field]!=='string'||!move[field])throw new VisionaryError(`Invalid analysis move field ${field}`,{code:'INVALID_ANALYSIS'});}
  return result;
}
