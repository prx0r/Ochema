import { registerTtsProvider, listTtsProviders } from './registry.mjs';
import { createEdgeTtsProvider } from './command-provider.mjs';
import { createElevenLabsTtsProvider } from './elevenlabs-provider.mjs';
import { MockTtsProvider } from './mock-provider.mjs';
export function registerBuiltinTtsProviders({env=process.env}={}){
  const existing=new Set(listTtsProviders());
  if(!existing.has('edge-tts'))registerTtsProvider(createEdgeTtsProvider());
  if(!existing.has('mock'))registerTtsProvider(new MockTtsProvider());
  if(env.ELEVENLABS_API_KEY&&!existing.has('elevenlabs'))registerTtsProvider(createElevenLabsTtsProvider({apiKey:env.ELEVENLABS_API_KEY}));
  return listTtsProviders();
}
