import { VisionaryError } from '../../core/errors.mjs';

export class TtsProvider {
  constructor(id) { this.id = id; }
  async synthesize(_request) {
    throw new VisionaryError(`TTS provider ${this.id} does not implement synthesize`, { code: 'NOT_IMPLEMENTED' });
  }
  async healthCheck() { return { id: this.id, healthy: true }; }
}

export function validateTtsResult(result) {
  if (!result || typeof result !== 'object') throw new VisionaryError('Invalid TTS result', { code: 'INVALID_TTS_RESULT' });
  if (!result.audioPath && !result.audioBuffer && !result.audioBase64) {
    throw new VisionaryError('TTS result must contain audioPath, audioBuffer, or audioBase64', { code: 'INVALID_TTS_RESULT' });
  }
  return result;
}
