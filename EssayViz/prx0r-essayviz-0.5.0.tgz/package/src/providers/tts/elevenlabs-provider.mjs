import { HttpTtsProvider } from './http-provider.mjs';
export function createElevenLabsTtsProvider({ apiKey, modelId='eleven_multilingual_v2', outputFormat='mp3_44100_128', fetchImpl, timeoutMs }={}){
  if(!apiKey) throw new Error('ElevenLabs apiKey is required');
  return new HttpTtsProvider({
    id:'elevenlabs',fetchImpl,timeoutMs,
    endpoint:request=>`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(request.voice)}/with-timestamps?output_format=${encodeURIComponent(outputFormat)}`,
    headers:{'xi-api-key':apiKey},
    buildBody:request=>({text:request.text,model_id:request.modelId??modelId,voice_settings:request.voiceSettings}),
    parseResponse:async response=>{const data=await response.json();return{audioBase64:data.audio_base64,alignment:data.alignment??null,normalizedAlignment:data.normalized_alignment??null};}
  });
}
