import { writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { TtsProvider, validateTtsResult } from './provider.mjs';
import { VisionaryError } from '../../core/errors.mjs';

export class HttpTtsProvider extends TtsProvider {
  constructor({ id, endpoint, headers = {}, buildBody, parseResponse, timeoutMs = 120_000, fetchImpl = globalThis.fetch }) {
    super(id); this.endpoint = endpoint; this.headers = headers; this.buildBody = buildBody; this.parseResponse = parseResponse; this.timeoutMs = timeoutMs; this.fetchImpl = fetchImpl;
  }
  async synthesize(request) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.fetchImpl(typeof this.endpoint === 'function' ? this.endpoint(request) : this.endpoint, {
        method: 'POST', headers: { 'content-type': 'application/json', ...this.headers },
        body: JSON.stringify(this.buildBody(request)), signal: controller.signal
      });
      if (!response.ok) throw new VisionaryError(`TTS HTTP ${response.status}`, { code: 'TTS_HTTP_ERROR', details: { status: response.status, body: await response.text() } });
      const parsed = await this.parseResponse(response, request);
      if (parsed.audioBase64 && request.outputPath) {
        const target = resolve(request.outputPath); await mkdir(dirname(target), { recursive: true });
        await writeFile(target, Buffer.from(parsed.audioBase64, 'base64')); parsed.audioPath = target;
      }
      return validateTtsResult({ provider: this.id, ...parsed });
    } finally { clearTimeout(timer); }
  }
}
