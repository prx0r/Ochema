import { join } from 'node:path';
import { getTtsProvider } from './registry.mjs';
export async function synthesizeNarration({timing,providerId,voice,outputDirectory,format='mp3',providerOptions={}}){
  const provider=getTtsProvider(providerId);const scenes=[];
  for(const scene of timing.scenes){
    const outputPath=join(outputDirectory,`${scene.sceneId}.${format}`);
    const result=await provider.synthesize({text:scene.narration,voice,outputPath,sceneId:scene.sceneId,...providerOptions});
    scenes.push({sceneId:scene.sceneId,text:scene.narration,...result});
  }
  return{version:'1.0',provider:providerId,voice,scenes};
}
