import { VisionaryError } from '../../core/errors.mjs';
const providers = new Map();
export function registerTtsProvider(provider, { overwrite = false } = {}) {
  if (!provider?.id || typeof provider.synthesize !== 'function') throw new VisionaryError('Invalid TTS provider', { code: 'INVALID_PROVIDER' });
  if (!overwrite && providers.has(provider.id)) throw new VisionaryError(`TTS provider already registered: ${provider.id}`, { code: 'DUPLICATE_PROVIDER' });
  providers.set(provider.id, provider); return provider;
}
export function getTtsProvider(id) { const p = providers.get(id); if (!p) throw new VisionaryError(`Unknown TTS provider ${id}`, { code: 'UNKNOWN_PROVIDER' }); return p; }
export function listTtsProviders() { return [...providers.keys()]; }
export function clearTtsProviders() { providers.clear(); }
