import { spawn } from 'node:child_process';
import { mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { TtsProvider, validateTtsResult } from './provider.mjs';
import { VisionaryError } from '../../core/errors.mjs';

export class CommandTtsProvider extends TtsProvider {
  constructor({ id = 'command', command, buildArgs, env = {}, timeoutMs = 120_000 }) {
    super(id); this.command = command; this.buildArgs = buildArgs; this.env = env; this.timeoutMs = timeoutMs;
  }
  async synthesize(request) {
    const outputPath = resolve(request.outputPath);
    await mkdir(dirname(outputPath), { recursive: true });
    const args = this.buildArgs(request);
    await run(this.command, args, { env: { ...process.env, ...this.env }, timeoutMs: this.timeoutMs });
    return validateTtsResult({ provider: this.id, audioPath: outputPath, alignment: null });
  }
}
function run(command, args, { env, timeoutMs }) {
  return new Promise((resolvePromise, reject) => {
    const child = spawn(command, args, { env, stdio: ['ignore', 'pipe', 'pipe'] });
    let stderr = '';
    const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new VisionaryError(`TTS command timed out: ${command}`, { code: 'TTS_TIMEOUT' })); }, timeoutMs);
    child.stderr.on('data', chunk => { stderr += chunk; });
    child.on('error', error => { clearTimeout(timer); reject(error); });
    child.on('exit', code => { clearTimeout(timer); code === 0 ? resolvePromise() : reject(new VisionaryError(`TTS command exited ${code}`, { code: 'TTS_FAILED', details: { command, args, stderr } })); });
  });
}
export function createEdgeTtsProvider(options = {}) {
  return new CommandTtsProvider({
    id: 'edge-tts', command: options.command ?? 'edge-tts', timeoutMs: options.timeoutMs,
    buildArgs: ({ text, voice = 'en-GB-SoniaNeural', outputPath }) => ['--voice', voice, '--text', text, '--write-media', resolve(outputPath)]
  });
}
