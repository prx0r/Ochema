import { writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { TtsProvider } from './provider.mjs';
export class MockTtsProvider extends TtsProvider {
  constructor(){super('mock');}
  async synthesize(request){const path=resolve(request.outputPath);await mkdir(dirname(path),{recursive:true});await writeFile(path,Buffer.from(`MOCK:${request.text}`));const chars=[...request.text];const duration=Math.max(0.2,chars.length*0.03);return{provider:this.id,audioPath:path,duration,alignment:{characters:chars,character_start_times_seconds:chars.map((_,i)=>i*duration/chars.length),character_end_times_seconds:chars.map((_,i)=>(i+1)*duration/chars.length)}};}
}
