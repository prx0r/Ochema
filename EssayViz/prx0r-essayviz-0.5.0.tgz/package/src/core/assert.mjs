import { VisionaryError } from "./errors.mjs";
export function assert(condition, message, details = {}) {
  if (!condition) throw new VisionaryError(message, { code: "VALIDATION_ERROR", details });
}
export function nonEmptyString(value, name) {
  assert(typeof value === "string" && value.trim().length > 0, `${name} must be a non-empty string`);
}
