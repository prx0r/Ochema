export class VisionaryError extends Error {
  constructor(message, { code = "VISIONARY_ERROR", details = {} } = {}) {
    super(message);
    this.name = "VisionaryError";
    this.code = code;
    this.details = details;
  }
}
