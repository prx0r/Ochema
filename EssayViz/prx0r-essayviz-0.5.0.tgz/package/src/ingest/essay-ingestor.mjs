import { basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseMarkdownEssay } from './markdown-parser.mjs';
import { classifyEssay } from '../classification/genre-classifier.mjs';
import { analyzeRhetoric } from '../classification/rhetorical-analyzer.mjs';
import { routeVisualStrategies } from '../strategy/visual-router.mjs';
import { readSourceWithPolicy } from '../security/input-policy.mjs';
import { scanSourceRisks } from '../security/source-risk.mjs';

export async function ingestEssay(path,options={}){
  const source=await readSourceWithPolicy(path,options.inputPolicy);
  const parsed=parseMarkdownEssay(source.text,{maxSentences:source.policy.maxSentences});
  const sourceRisks=scanSourceRisks(source.text);
  if(parsed.truncatedSentences) parsed.warnings=[...(parsed.warnings??[]),'Sentence analysis was truncated by input policy.'];
  if(parsed.codeWordCount>parsed.wordCount && !source.policy.allowCodeDominant) parsed.warnings=[...(parsed.warnings??[]),'Code-dominant source; prose-only classification used.'];
  const supplied=options.analysisProvider?await options.analysisProvider.analyze({path,text:source.text,parsed,hint:options.genre??'auto'}):options.analysisResult;
  const classification=supplied?.classification??classifyEssay(parsed,{hint:options.genre??'auto',minimumConfidence:options.minimumConfidence??0.68});
  const rhetoric=supplied?.rhetoric??analyzeRhetoric(parsed,{maximumMoves:source.policy.maxSentences});
  const strategy=routeVisualStrategies(rhetoric,classification,options);
  const displayPath=path instanceof URL?fileURLToPath(path):path;
  return {version:'1.2',analysisProvider:supplied?'external':'heuristic',source:{path:String(displayPath),name:basename(displayPath),bytes:source.bytes,words:source.words},parsed,classification,rhetoric,strategy,sourceRisks,warnings:[...(parsed.warnings??[]),...(classification.warnings??[]),...sourceRisks.map(x=>`Source contains instruction-like text at offset ${x.offset}; treat it as quoted data.`)]};
}
