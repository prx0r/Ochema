function cleanInline(text){
  return text
    .replace(/\[\^([^\]]+)\]/g, '')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .trim();
}

export function parseMarkdownEssay(markdown, { maxSentences = 8000 } = {}) {
  const normalized = String(markdown).replace(/\r\n/g,'\n');
  const { prose, codeBlocks } = stripFencedCode(normalized);
  const lines = prose.split('\n');
  const title = (lines.find(line=>/^#\s+/.test(line)) ?? '# Untitled').replace(/^#\s+/,'').trim();
  const sections=[]; let current={level:1,title:'Opening',body:[],startLine:1};
  const equations=[]; let inEquation=false, equation=[], equationStart=0;
  const references=[];

  for (let index=0; index<lines.length; index+=1) {
    const line=lines[index]; const trimmed=line.trim();
    if (/^\[\^[^\]]+\]:/.test(trimmed) || /^https?:\/\//.test(trimmed)) references.push({ line:index+1, text:trimmed });
    if (trimmed==='$$' || trimmed==='\\[' || trimmed==='\\]') {
      if (!inEquation && trimmed!=='\\]') { inEquation=true; equation=[]; equationStart=index+1; }
      else if (inEquation) { inEquation=false; equations.push({ text:equation.join('\n').trim(), startLine:equationStart, endLine:index+1, display:true }); }
      continue;
    }
    if (inEquation) { equation.push(line); continue; }
    const h=line.match(/^(#{1,6})\s+(.+)$/);
    if (h) {
      pushSection(sections,current,index);
      current={level:h[1].length,title:cleanInline(h[2]),body:[],startLine:index+1};
    } else current.body.push(line);
  }
  pushSection(sections,current,lines.length);
  if (inEquation) equations.push({ text:equation.join('\n').trim(), startLine:equationStart, endLine:lines.length, display:true, unterminated:true });

  const paragraphs=[];
  for (const section of sections) {
    let offset=section.startLine+1;
    for (const chunk of section.text.split(/\n\s*\n/)) {
      const text=cleanInline(chunk);
      if (text && !/^\[\^[^\]]+\]:/.test(text)) paragraphs.push({ section:section.title, text, startLine:offset, endLine:offset+chunk.split('\n').length-1 });
      offset += chunk.split('\n').length+1;
    }
  }
  const sentences=[];
  outer: for (const paragraph of paragraphs) {
    for (const raw of splitSentences(paragraph.text)) {
      const text=cleanInline(raw); if (!text) continue;
      sentences.push({ ...paragraph, text });
      if (sentences.length>=maxSentences) break outer;
    }
  }
  for (const match of prose.matchAll(/\$([^$\n]+)\$/g)) equations.push({ text:match[1].trim(), display:false, offset:match.index });
  const wordCount=(prose.match(/\S+/g)??[]).length;
  const codeWordCount=codeBlocks.reduce((n,b)=>n+(b.text.match(/\S+/g)??[]).length,0);
  return {
    version:'1.1', title, sections, paragraphs, sentences, equations, references,
    codeBlocks, wordCount, codeWordCount,
    languageHint:detectScript(prose),
    truncatedSentences:sentences.length>=maxSentences
  };
}
function pushSection(sections,current,endLine){const text=current.body.join('\n').trim();if(text)sections.push({level:current.level,title:current.title,text,startLine:current.startLine,endLine});}
function stripFencedCode(markdown){const blocks=[];let index=0;const prose=markdown.replace(/```([^\n]*)\n([\s\S]*?)```/g,(_all,lang,text)=>{blocks.push({index:index++,language:lang.trim()||null,text});return '\n[CODE_BLOCK_REMOVED]\n';});return{prose,codeBlocks:blocks};}
function splitSentences(text){if(typeof Intl!=='undefined'&&Intl.Segmenter){try{return [...new Intl.Segmenter(undefined,{granularity:'sentence'}).segment(text)].map(x=>x.segment.trim()).filter(Boolean);}catch{}}return text.split(/(?<=[.!?।])\s+/u);}
function detectScript(text){const counts={latin:(text.match(/[A-Za-z]/g)??[]).length,devanagari:(text.match(/[\u0900-\u097F]/g)??[]).length,cjk:(text.match(/[\u3040-\u30ff\u3400-\u9fff]/g)??[]).length,arabic:(text.match(/[\u0600-\u06ff]/g)??[]).length};const [script,count]=Object.entries(counts).sort((a,b)=>b[1]-a[1])[0];return{script,confidence:count/Math.max(1,Object.values(counts).reduce((a,b)=>a+b,0))};}
