export function estimateSpeechSeconds(text,{wordsPerMinute=145,padding=0.35}={}){
  const words=(text.trim().match(/\S+/g)??[]).length;
  return Math.max(2,words/wordsPerMinute*60+padding);
}
export function planTiming(project, storyboard) {
  let cursor=0;
  const scenes=storyboard.scenes.map(scene=>{
    const beat=project.beats.find(b=>b.id===scene.beatId);
    const duration=Number(beat.duration ?? estimateSpeechSeconds(beat.narration ?? beat.text ?? scene.subtitle));
    const timed={sceneId:scene.id,start:cursor,duration,end:cursor+duration,narration:beat.narration ?? beat.text ?? scene.subtitle};
    cursor+=duration;
    return timed;
  });
  return {version:"1.0",duration:cursor,scenes};
}
