import { signalRegistry } from "../registries/index.mjs";
export function planSignals(project, storyboard) {
  const profile=signalRegistry.get(project.signalProfile);
  return {
    version:"1.0", profile,
    buses:{
      score:{responsibility:"formal visual events",routes:[]},
      music:{responsibility:"performed pressure and timbre",routes:[
        {source:"onset",target:"subordinate.emission",attack:0.01,release:0.18},
        {source:"harmonicEnergy",target:"trace.persistence",attack:0.08,release:0.65}
      ]},
      narration:{responsibility:"attention and semantic emphasis",routes:[
        {source:"speechDensity",target:"information.suppression",attack:0.12,release:0.45},
        {source:"emphasis",target:"focus.strength",attack:0.04,release:0.3}
      ]}
    },
    scenes:storyboard.scenes.map(s=>({sceneId:s.id,policy:"logical topology is never audio-controlled"}))
  };
}
