import { typographyRegistry } from "../registries/index.mjs";
export function planTypography(project, storyboard) {
  const profile=typographyRegistry.get(project.typographyProfile);
  return {
    version:"1.0", profile,
    scenes:storyboard.scenes.map(scene=>({
      sceneId:scene.id,
      hierarchy:{titlePx:28, equationPx:32, bodyPx:18, annotationPx:14},
      maxProseBlocks:profile.maxProseBlocks,
      rules:[
        "Use prose font for IAST and mixed Sanskrit.",
        "Use math font only for pure equations and variables.",
        "Keep equations spatially separate from explanatory prose.",
        "No text may depend on glow for legibility."
      ]
    }))
  };
}
