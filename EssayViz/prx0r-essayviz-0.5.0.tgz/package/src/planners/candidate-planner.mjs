const CANDIDATE_KINDS=["notation","diagram","object","field","particles","symbolic","typographic","cinematic"];
export function planCandidates(argumentIR) {
  return {version:"1.1",beats:argumentIR.beats.map(beat=>{
    const preferred=beat.essayviz?.selectedMode;
    const candidates=CANDIDATE_KINDS.map((kind,index)=>({
      id:`${beat.id}-${kind}`,kind,
      topology:kind===preferred?(beat.essayviz?.topology??suggestTopology(beat.relation,kind)):suggestTopology(beat.relation,kind),
      decisiveMutation:kind===preferred?(beat.essayviz?.decisiveMutation??suggestMutation(beat.operation,kind)):suggestMutation(beat.operation,kind),
      invariant:beat.invariant,forbiddenInference:beat.forbiddenInference,
      scores:{relationFidelity:score(kind,beat),motionProof:motion(kind,beat),domainMatch:kind==="object"?82:70,continuityHandoff:75,silentLegibility:["notation","diagram","object"].includes(kind)?88:70,novelty:55+index*5,epistemicRestraint:82},
      status:kind===preferred?"selected":(!preferred&&kind==="notation"?"provisional":"candidate")
    }));
    return{beatId:beat.id,relation:beat.relation,candidates};
  })};
}
function score(kind,beat){if(kind===beat.essayviz?.selectedMode)return 94;if(beat.semanticRole==="premise"&&kind==="notation")return 90;if(beat.semanticRole==="mechanism"&&["diagram","field","particles"].includes(kind))return 86;if(beat.semanticRole==="definition"&&["typographic","object","notation"].includes(kind))return 84;if(beat.relation==="bridge-failure"&&["notation","diagram"].includes(kind))return 90;return 70;}
function motion(kind,beat){if(kind===beat.essayviz?.selectedMode)return 92;return ["field","particles","symbolic","cinematic"].includes(kind)?84:76;}
function suggestTopology(relation,kind){return({notation:"typed nodes, semantic edges and scope brackets",diagram:"graph, lattice or process diagram",object:"exact object with callouts and state changes",field:"continuous field and trajectories",particles:"agents advected by a semantic field",symbolic:"constructed symbolic geometry",typographic:"language as spatial material",cinematic:"camera, depth and material world"}[kind])+` adapted to ${relation}`;}
function suggestMutation(operation,kind){return `${operation} performed through ${kind}`;}
