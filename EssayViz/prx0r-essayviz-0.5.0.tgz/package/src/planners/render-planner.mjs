export function planRender(project, storyboard, timing, signals) {
  const tts={provider:'edge-tts',voice:'en-GB-SoniaNeural',format:'mp3',...(project.tts??{})};
  return {
    version:'1.1',frameworkAdapter:project.backend??'motherfucker',projectId:project.id,
    packPath:'scene-pack.json',outputPath:`build/${project.id}/video.mp4`,finalPath:`build/${project.id}/final.mp4`,
    audio:{narrationPath:`build/${project.id}/narration.${tts.format}`,featureManifest:`build/${project.id}/features.json`,tts},
    render:project.render,timing,signals,
    commands:{ttsProvider:tts.provider,analyser:'python3 tools/analyse-audio.py',renderer:'node tools/render-pack.mjs',mux:'ffmpeg'}
  };
}
