import { createArgumentIR } from "../ir/argument-ir.mjs";
export function planArgument(project) {
  return createArgumentIR({ title: project.title, beats: project.beats });
}
