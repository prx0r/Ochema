export function planContinuity(project, argumentIR) {
  const declared = project.continuitySystems ?? [];
  const systems = declared.length ? declared : inferContinuity(argumentIR);
  return {
    version:"1.0",
    systems: systems.map((system, index) => ({
      id: system.id ?? `continuity-${index+1}`,
      meaning: system.meaning,
      visualIdentity: system.visualIdentity,
      conserved: system.conserved ?? [],
      transformable: system.transformable ?? [],
      forbidden: system.forbidden ?? [],
      lifecycle: system.lifecycle ?? ["introduction","development","contrast","return","resolution"]
    }))
  };
}
function inferContinuity(argumentIR) {
  const invariants = [...new Set(argumentIR.beats.map(b=>b.invariant).filter(Boolean))];
  return invariants.slice(0,6).map((meaning,index)=>({
    id:`invariant-${index+1}`, meaning,
    visualIdentity:"agent-must-author",
    conserved:["semantic meaning"],
    transformable:["position","scale","material"],
    forbidden:["arbitrary replacement"]
  }));
}
