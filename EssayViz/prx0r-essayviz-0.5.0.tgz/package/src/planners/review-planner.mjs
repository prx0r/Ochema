export function planReview(storyboard) {
  return {
    version:"1.0",
    sampleTimes:[0,0.25,0.55,0.82,1],
    transitionStripFrames:6,
    isolatedTests:["silent","music-only","narration-only","integrated"],
    scenes:storyboard.scenes.map(scene=>({
      sceneId:scene.id,
      tests:[
        "relation can be inferred without title",
        "frames cannot be reordered without changing causality",
        "invariant survives",
        "forbidden inference is not implied",
        "typography remains legible",
        "audio does not alter logical identity"
      ]
    }))
  };
}
