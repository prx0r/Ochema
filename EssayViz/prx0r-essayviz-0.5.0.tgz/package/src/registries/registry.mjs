import { VisionaryError } from '../core/errors.mjs';
export class Registry {
  #items=new Map();
  constructor(name){this.name=name;}
  register(id,value,{overwrite=false}={}){if(!overwrite&&this.#items.has(id))throw new VisionaryError(`${this.name} already contains ${id}`,{code:'DUPLICATE_REGISTRATION'});this.#items.set(id,Object.freeze({id,...value}));return this;}
  get(id){const value=this.#items.get(id);if(!value)throw new VisionaryError(`${this.name} does not contain ${id}`,{code:'MISSING_REGISTRATION'});return value;}
  has(id){return this.#items.has(id);}
  unregister(id){return this.#items.delete(id);}
  clear(){this.#items.clear();return this;}
  list(){return [...this.#items.values()];}
  snapshot(){return Object.freeze(Object.fromEntries(this.#items));}
}
