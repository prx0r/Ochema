export function createSourceLock(input) {
  return Object.freeze({
    title: input.title,
    exactContention: input.exactContention,
    secureConclusions: [...(input.secureConclusions ?? [])],
    nonClaims: [...(input.nonClaims ?? [])],
    rivals: [...(input.rivals ?? [])],
    discriminators: [...(input.discriminators ?? [])],
    evidenceLabels: { ...(input.evidenceLabels ?? {}) },
    survivingFrontier: input.survivingFrontier,
    sources: [...(input.sources ?? [])],
  });
}
