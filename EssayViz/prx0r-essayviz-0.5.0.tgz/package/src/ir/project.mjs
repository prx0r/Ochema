export function createProject(input) {
  return {
    version: "1.0",
    id: input.id,
    title: input.title,
    source: input.source,
    sourceLock: input.sourceLock,
    beats: input.beats,
    continuitySystems: input.continuitySystems ?? [],
    compositionProfile: input.compositionProfile ?? "proof-and-frontier",
    capabilities: input.capabilities ?? ["base"],
    styleProfile: input.styleProfile ?? "crisp-white-notation",
    typographyProfile: input.typographyProfile ?? "logicvid-serif-math",
    signalProfile: input.signalProfile ?? "narration-attention",
    render: {
      width: 1280, height: 720, fps: 24, crf: 16, preset: "medium",
      ...(input.render ?? {})
    }
  };
}
