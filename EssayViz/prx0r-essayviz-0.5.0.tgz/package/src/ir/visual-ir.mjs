export const NODE_TYPES = Object.freeze([
  "proposition","variable","domain","definition","theory","evidence",
  "interpretation","field","agent","carrier","continuity-object"
]);
export const EDGE_TYPES = Object.freeze([
  "licensed","dependency","physical","functional","presupposition",
  "unsupported","definition","comparison","transfer","exclusion"
]);
export function createVisualProgram(input) {
  return {
    version: "1.0",
    sceneId: input.sceneId,
    relation: input.relation,
    topology: input.topology,
    invariant: input.invariant,
    nodes: input.nodes ?? [],
    edges: input.edges ?? [],
    scopes: input.scopes ?? [],
    cuts: input.cuts ?? [],
    geometry: input.geometry ?? {},
    material: input.material ?? {},
    motion: input.motion ?? {},
    style: input.style ?? {},
    signals: input.signals ?? {},
    transition: input.transition ?? {},
    forbiddenInference: input.forbiddenInference ?? "",
  };
}
