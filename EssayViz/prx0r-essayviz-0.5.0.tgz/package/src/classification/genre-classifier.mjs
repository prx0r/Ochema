export const ESSAY_GENRES = Object.freeze([
  "logical-proof",
  "poem",
  "explanatory",
  "science",
  "comparative",
  "investigative",
  "tutorial",
  "textual-scholarship",
  "narrative",
  "hybrid",
  "unclassified",
]);

const WEIGHTED_PATTERNS = {
  "logical-proof": [
    [3, /\b(premise|conclusion|therefore|entails?|implies?|argument|objection|refutation)\b/gi],
    [3, /⇒|⇏|∴|\bboxed\b/g],
    [2, /^\s*\d+[.)]\s+/gm],
    [1, /\bif\b.+\bthen\b/gi],
  ],
  poem: [
    [3, /\b(poem|stanza|refrain|verse|enjambment)\b/gi],
    [2, /\bmoon|river|shadow|silence|dream|remember|again\b/gi],
  ],
  explanatory: [
    [3, /\bhow\b.+\bworks?\b/gi],
    [2, /\bmechanism|component|process|for example|in other words|controls?|consists? of\b/gi],
    [2, /\b(wider|narrower|increases?|decreases?|moves?|admits?)\b/gi],
  ],
  science: [
    [3, /\b(experiment|data|hypothesis|measure|model|variable|prediction|intervention|simulation)\b/gi],
    [2, /\b(neural|biological|physics|particle|field|attractor|entropy|organism|equation)\b/gi],
    [1, /\b(rate|threshold|parameter|state space)\b/gi],
  ],
  comparative: [
    [3, /\bversus|compared with|whereas|both|difference between|rival|two theories|alternative\b/gi],
    [2, /\bshared evidence|predictions diverge|under the same\b/gi],
  ],
  investigative: [
    [3, /\b(mystery|evidence|hypothesis|clue|case|investigation|catalogue|surviving)\b/gi],
    [2, /\bone hypothesis|another hypothesis|supports the first|supports the second|does not yet decide\b/gi],
  ],
  tutorial: [
    [4, /\b(first|next|then|finally)\b/gi],
    [3, /\b(create|click|connect|verify|export|install|run|open|select)\b/gi],
    [2, /\bstep\s+\d+|instructions?|checkpoint\b/gi],
  ],
  "textual-scholarship": [
    [4, /\b(verse|manuscript|translation|commentary|textual|Sanskrit|Tantrāloka|folio|gloss)\b/gi],
    [2, /\bterm|passage|reading|translator|source text\b/gi],
  ],
  narrative: [
    [3, /\b(once|character|entered|walked|said|remembered|returned|story)\b/gi],
    [2, /[“"][^”"]+[”"]/g],
  ],
};

export function classifyEssay(parsed, { hint = "auto", minimumConfidence = 0.68 } = {}) {
  if (hint !== "auto") {
    if (!ESSAY_GENRES.includes(hint) || hint === "unclassified") throw new Error(`Unsupported genre hint: ${hint}`);
    return { genre: hint, primaryGenre: hint, secondaryGenre: null, confidence: 1, scores: { [hint]: 1 }, reasons: ["explicit hint"], abstained: false, warnings: [] };
  }

  const source = [parsed.title, ...parsed.sections.map((s) => s.title), ...parsed.paragraphs.map((p) => p.text)].join("\n");
  const warnings = [];
  const raw = {};
  const reasons = {};

  for (const [genre, rules] of Object.entries(WEIGHTED_PATTERNS)) {
    let score = 0;
    const hits = [];
    for (const [weight, pattern] of rules) {
      const matches = [...source.matchAll(pattern)];
      if (matches.length) {
        score += Math.min(3, matches.length) * weight;
        hits.push(...matches.slice(0, 3).map((match) => match[0]));
      }
    }
    raw[genre] = score;
    reasons[genre] = hits;
  }

  applyStructuralFeatures(parsed, raw, reasons);
  const maximum = Math.max(1, ...Object.values(raw));
  const scores = Object.fromEntries(Object.entries(raw).map(([genre, value]) => [genre, value / maximum]));
  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const [primaryGenre, primaryScore] = sorted[0];
  const [secondaryGenre, secondaryScore] = sorted[1] ?? [null, 0];

  const genuinelyHybrid = primaryScore >= 0.78 && secondaryScore >= 0.72 && Math.abs(primaryScore - secondaryScore) <= 0.12;
  const evidenceMass = Object.values(raw).reduce((a,b)=>a+b,0);
  let confidence = evidenceMass===0 ? 0 : Math.min(0.98, 0.25 + primaryScore * 0.45 + Math.max(0, primaryScore - secondaryScore) * 0.3);
  if(parsed.languageHint?.script && parsed.languageHint.script!=="latin" && parsed.languageHint.confidence>0.55){ confidence*=0.55; warnings.push(`Heuristic classifier has limited coverage for ${parsed.languageHint.script} script.`); }
  if(parsed.wordCount<20){ confidence*=0.7; warnings.push("Source is too short for reliable automatic genre classification."); }
  const abstain = confidence < minimumConfidence;

  return {
    genre: abstain ? "unclassified" : (genuinelyHybrid ? "hybrid" : primaryGenre),
    primaryGenre,
    secondaryGenre: genuinelyHybrid ? secondaryGenre : null,
    confidence,
    scores,
    rawScores: raw,
    reasons: reasons[primaryGenre],
    abstained: abstain,
    warnings,
  };
}

function applyStructuralFeatures(parsed, raw, reasons) {
  const originalLines = parsed.sections.flatMap((section) => section.text.split("\n").map((line) => line.trim()).filter(Boolean));
  const shortLines = originalLines.filter((line) => line.length <= 70);
  const paragraphWordCounts = parsed.paragraphs.map((paragraph) => paragraph.text.split(/\s+/).length);
  const averageParagraphWords = paragraphWordCounts.reduce((a, b) => a + b, 0) / Math.max(1, paragraphWordCounts.length);
  const numberedLines = originalLines.filter((line) => /^\d+[.)]\s+/.test(line)).length;
  const imperativeStarts = originalLines.filter((line) => /^(first|next|then|finally|create|connect|verify|export|install|run|open|select)\b/i.test(line)).length;

  if (originalLines.length >= 4 && shortLines.length / originalLines.length >= 0.72 && averageParagraphWords <= 42) {
    raw.poem += 10;
    reasons.poem.push("short-line structure");
  }
  if (numberedLines >= 2) {
    raw["logical-proof"] += 8;
    reasons["logical-proof"].push("numbered premise structure");
  }
  if (imperativeStarts >= 2) {
    raw.tutorial += 10;
    reasons.tutorial.push("imperative sequence");
  }
  if (parsed.equations.length >= 2) {
    raw["logical-proof"] += 5;
    raw.science += 3;
  }
  if (/^How\b/i.test(parsed.title)) raw.explanatory += 7;
  if (/\bversus|two theories|comparison\b/i.test(parsed.title)) raw.comparative += 7;
  if (/\bmissing|mystery|case\b/i.test(parsed.title)) raw.investigative += 5;
  if (/\breading|translation|commentary|manuscript\b/i.test(parsed.title)) raw["textual-scholarship"] += 7;
}
