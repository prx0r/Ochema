import { assert, nonEmptyString } from '../core/assert.mjs';
import { SEMANTIC_ROLES, RELATIONS } from '../ir/argument-ir.mjs';
export function validateProject(project) {
  assert(project&&typeof project==='object','project must be an object');
  nonEmptyString(project.id,'project.id');
  assert(/^[a-z0-9][a-z0-9._-]{0,127}$/i.test(project.id),'project.id contains unsupported characters');
  nonEmptyString(project.title,'project.title');
  assert(project.sourceLock&&typeof project.sourceLock==='object','project.sourceLock is required');
  nonEmptyString(project.sourceLock.exactContention,'project.sourceLock.exactContention');
  nonEmptyString(project.sourceLock.survivingFrontier,'project.sourceLock.survivingFrontier');
  assert(Array.isArray(project.sourceLock.secureConclusions),'secureConclusions must be an array');
  assert(Array.isArray(project.sourceLock.nonClaims),'nonClaims must be an array');
  assert(Array.isArray(project.beats)&&project.beats.length>0,'project.beats must contain at least one beat');
  assert(project.beats.length<=100,'project.beats exceeds production limit of 100');
  const ids=new Set();
  for(const beat of project.beats){
    nonEmptyString(beat.id,'beat.id');assert(!ids.has(beat.id),`duplicate beat id ${beat.id}`);ids.add(beat.id);
    assert(SEMANTIC_ROLES.includes(beat.semanticRole),`${beat.id}: invalid semanticRole`);
    assert(RELATIONS.includes(beat.relation),`${beat.id}: invalid relation`);
    for(const field of ['sourceSection','incomingBelief','operation','outgoingBelief','invariant','forbiddenInference'])nonEmptyString(beat[field],`${beat.id}.${field}`);
    if(beat.duration!==undefined)assert(Number.isFinite(beat.duration)&&beat.duration>=2&&beat.duration<=120,`${beat.id}.duration must be 2..120 seconds`);
  }
  if(project.render){
    for(const key of ['width','height','fps'])assert(Number.isFinite(project.render[key])&&project.render[key]>0,`render.${key} must be positive`);
    assert(project.render.width<=8192&&project.render.height<=8192,'render dimensions exceed 8192');
    assert(project.render.fps<=120,'render.fps exceeds 120');
  }
  if(project.tts){
    nonEmptyString(project.tts.provider,'project.tts.provider');
    if(project.tts.voice!==undefined)nonEmptyString(project.tts.voice,'project.tts.voice');
  }
  return {valid:true,beatCount:project.beats.length,warnings:productionWarnings(project)};
}
function productionWarnings(project){const warnings=[];if(!project.sourceLock.sources?.length)warnings.push('No source citations recorded.');if(!project.continuitySystems?.length)warnings.push('No explicit continuity systems declared; planner will infer placeholders.');return warnings;}
