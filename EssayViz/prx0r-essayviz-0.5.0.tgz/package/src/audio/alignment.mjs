export function characterAlignmentToWords(text,alignment){
  if(!alignment?.characters||!alignment.character_start_times_seconds||!alignment.character_end_times_seconds)return[];
  const chars=alignment.characters;const starts=alignment.character_start_times_seconds;const ends=alignment.character_end_times_seconds;const words=[];let current='',start=null,end=null;
  const flush=()=>{if(current){words.push({word:current,start,end,center:(start+end)/2});current='';start=null;end=null;}};
  for(let i=0;i<chars.length;i+=1){const char=chars[i];if(/\s/u.test(char)){flush();continue;}if(start===null)start=starts[i];end=ends[i];current+=char;}
  flush();return words;
}
export function alignCuePatterns(words,cues){return cues.map(cue=>{const regex=cue.regex?new RegExp(cue.pattern,cue.flags??'iu'):new RegExp(escapeRegex(cue.pattern),'iu');const matches=words.filter(w=>regex.test(w.word));const chosen=matches[cue.occurrence??0];return{...cue,time:chosen?.center??null,matchedWord:chosen?.word??null};});}
function escapeRegex(value){return String(value).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
