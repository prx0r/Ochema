export const MUSIC_FORMS=["fugue","passacaglia","canon","rondo","phasing","theme-and-variations","through-composed","raga-development","spectral"];
export function planMusic({form,thesis,continuityObject,stages=[]}) {
  if(!MUSIC_FORMS.includes(form))throw new Error(`unsupported musical form ${form}`);
  return {
    form,thesis,continuityObject,
    structuralHomology:`${form} selected to enact: ${thesis}`,
    stages:stages.map((stage,index)=>({
      id:stage.id??`music-${index+1}`,
      function:stage.function??stage,
      tempo:stage.tempo??72,
      density:stage.density??.4,
      tension:stage.tension??.3,
      subjectPresence:stage.subjectPresence??(index===0?1:.5)
    })),
    featureBus:["formalBoundary","motifEntry","carrierTransfer","voiceCount","tension","subjectPresence"]
  };
}
