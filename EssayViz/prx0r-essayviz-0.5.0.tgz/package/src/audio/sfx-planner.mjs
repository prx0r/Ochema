export const SFX_ROLES=["semantic-transition","material-contact","spatial-cue","ritual-action","interface","environment"];
export function planSoundEffects(storyboard,{maximumSimultaneous=2}={}) {
  return {
    version:"1.0",maximumSimultaneous,
    cues:storyboard.scenes.flatMap(scene=>{
      const verb=scene.operation?.split(/\s+/)[0]??"transition";
      return [{
        id:`sfx-${scene.id}`,
        sceneId:scene.id,
        role:"semantic-transition",
        semanticVerb:verb,
        soundFamily:suggestFamily(verb),
        gainDb:-14,
        duckUnderNarrationDb:-6,
        optional:true
      }];
    })
  };
}
function suggestFamily(verb){
  const map={split:"fracture",fold:"paper-tension",converge:"soft-lock",transfer:"passing-tone",withhold:"air-cut",dissolve:"granular-decay",remember:"reverse-resonance"};
  return map[verb]??"subtle-motion";
}
