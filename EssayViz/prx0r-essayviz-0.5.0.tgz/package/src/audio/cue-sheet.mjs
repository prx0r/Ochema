export function compileCueSheet({timing,music,sfx}) {
  const sceneStart=new Map(timing.scenes.map(x=>[x.sceneId,x.start]));
  return {
    duration:timing.duration,
    music,
    sfx:{...sfx,cues:sfx.cues.map(c=>({...c,time:sceneStart.get(c.sceneId)??0}))}
  };
}
