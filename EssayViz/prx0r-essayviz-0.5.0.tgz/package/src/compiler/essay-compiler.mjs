import { stableId } from "../core/determinism.mjs";
import { ingestEssay } from "../ingest/essay-ingestor.mjs";
import { compileProject } from "./project-compiler.mjs";
import { auditEssayCoverage } from "../review/coverage-auditor.mjs";
import { planTightCoupling } from "../audio/word-sync.mjs";
import { planGenreReview } from "../review/genre-review.mjs";
export async function compileEssay(path,options={}){
  const ingestion=await ingestEssay(path,options);
  if(ingestion.classification.abstained && (options.genre??"auto")==="auto" && !options.allowUnclassified){
    const error=new Error(`Automatic genre classification abstained (${ingestion.classification.confidence.toFixed(2)}). Supply --genre or enable allowUnclassified.`); error.code="GENRE_ABSTAINED"; error.details=ingestion.classification; throw error;
  }
  const project=projectFromIngestion(ingestion,options);
  const compiled=compileProject(project);
  const strategy=ingestion.strategy;
  const coverage=auditEssayCoverage(ingestion,strategy,project);
  const genreReview=planGenreReview(ingestion.classification.genre,strategy.beats);
  const wordSync={version:"1.0",scenes:compiled.timing.scenes.map(scene=>planTightCoupling({narration:scene.narration,duration:scene.duration,semanticCues:semanticCues(scene.narration,ingestion.classification.genre)}))};
  return{ingestion,project,strategy,coverage,genreReview,wordSync,...compiled};
}
export function projectFromIngestion(ingestion,options={}){
  const groups=groupMoves(ingestion.rhetoric.moves,{maxBeats:options.maxBeats??14});
  const title=ingestion.parsed.title,id=options.id??slug(title);
  const sourceLock=inferSourceLock(ingestion);
  return{
    version:"1.0",id,title,source:ingestion.source,sourceLock,
    essayviz:{genre:ingestion.classification.genre,classification:ingestion.classification},
    beats:groups.map((group,index)=>beatFromGroup(group,index,ingestion)),
    continuitySystems:inferContinuity(groups,ingestion),
    compositionProfile:ingestion.strategy.profile.composition,
    capabilities:["base","invariant-composition",...new Set(ingestion.strategy.beats.flatMap(b=>b.selected.capabilities))],
    styleProfile:ingestion.strategy.profile.style,
    typographyProfile:"logicvid-serif-math",signalProfile:signalProfile(ingestion.classification.genre),
    render:{width:1280,height:720,fps:24,crf:16,preset:"medium"}
  };
}
function groupMoves(moves,{maxBeats}){
  if(!Number.isInteger(maxBeats)||maxBeats<1||maxBeats>100) throw new Error(`maxBeats must be an integer from 1 to 100`);
  if(moves.length<=maxBeats)return moves.map(x=>[x]);
  const groups=[];let current=[];
  for(const move of moves){
    const boundary=current.length&&((move.section!==current.at(-1).section)||isStrongBoundary(move.role)||current.length>=Math.ceil(moves.length/maxBeats));
    if(boundary){groups.push(current);current=[];}
    current.push(move);
  }
  if(current.length)groups.push(current);
  while(groups.length>maxBeats){
    let best=0,bestSize=Infinity;
    for(let i=0;i<groups.length-1;i++){const size=groups[i].length+groups[i+1].length;if(size<bestSize){best=i;bestSize=size;}}
    groups.splice(best,2,[...groups[best],...groups[best+1]]);
  }
  return groups;
}
function isStrongBoundary(role){return ["contention","rival","objection","discriminator","framework-update","recognition","frontier","conclusion"].includes(role);}
function beatFromGroup(group,index,ingestion){const first=group[0],last=group.at(-1),text=group.map(x=>x.text).join(" ");const selection=ingestion.strategy.beats.find(b=>b.moveId===first.id)?.selected;return{
  id:`b${String(index+1).padStart(2,"0")}`,sourceSection:first.section,sourceSpan:{startLine:first.startLine,endLine:last.endLine},
  semanticRole:normalizeRole(dominant(group.map(x=>x.role))),
  incomingBelief:inferIncoming(first),operation:operationFor(group),outgoingBelief:inferOutgoing(last),
  relation:dominant(group.map(x=>x.relation)),invariant:inferInvariant(text,ingestion),
  likelyMisreading:inferMisreading(text),forbiddenInference:inferForbidden(text),evidenceStatus:"R",
  narration:text,duration:Math.max(5,Math.min(28,text.split(/\s+/).length/145*60+.5)),
  essayviz:{sourceMoveIds:group.map(x=>x.id),selectedMode:selection?.mode,topology:selection?.topology,decisiveMutation:selection?.decisiveMutation}
};}
function normalizeRole(role){return ["exposition","conclusion"].includes(role)?(role==="conclusion"?"consequence":"definition"):role;}
function dominant(xs){const c=new Map();for(const x of xs)c.set(x,(c.get(x)??0)+1);return [...c].sort((a,b)=>b[1]-a[1])[0]?.[0]??"sequence";}
function inferIncoming(m){return `Before this beat, the viewer may not yet distinguish: ${m.text.slice(0,120)}`;}
function inferOutgoing(m){return `After this beat, the viewer should understand: ${m.text.slice(0,160)}`;}
function operationFor(group){const roles=[...new Set(group.map(x=>x.role))];return roles.length===1?`${roles[0]} the claim`:`transform through ${roles.join(" → ")}`;}
function inferInvariant(text,ingestion){if(/same|identity|persist/i.test(text))return"token identity under changing description";if(/field|process|system/i.test(text))return"the same process under changing explanatory focus";if(ingestion.classification.genre==="poem")return"the central image or refrain";return"the exact source claim and its epistemic status";}
function inferMisreading(text){return /analogy|like|as if/i.test(text)?"the analogy is literal identity":"the visual decoration is mistaken for evidence";}
function inferForbidden(text){if(/prove|therefore|entail/i.test(text))return"a stronger conclusion is shown as licensed without its missing premise";if(/science|model|data/i.test(text))return"a model or correlate is shown as identical to the phenomenon";return"the visual introduces a claim not licensed by the source";}
function inferSourceLock(ingestion){const moves=ingestion.rhetoric.moves;const contention=moves.find(m=>m.role==="contention")?.text??ingestion.parsed.paragraphs[0]?.text??ingestion.parsed.title;const conclusions=moves.filter(m=>["conclusion","consequence"].includes(m.role)).map(m=>m.text).slice(-3);const rivals=moves.filter(m=>["rival","objection"].includes(m.role)).map(m=>m.text).slice(0,5);const discriminators=moves.filter(m=>m.role==="discriminator").map(m=>m.text).slice(0,5);const frontier=moves.findLast?.(m=>m.role==="frontier")?.text??moves.filter(m=>m.role==="frontier").at(-1)?.text??"The source does not specify a final unresolved frontier.";return{exactContention:contention,secureConclusions:conclusions.length?conclusions:[contention],nonClaims:["Visual analogy is not evidence.","Renderer choice does not settle ontology."],rivals,discriminators,evidenceLabels:{source:"user-supplied"},survivingFrontier:frontier,sources:ingestion.parsed.references};}
function inferContinuity(groups,ingestion){const title=ingestion.parsed.title;return[{id:"source-thread",meaning:`the central semantic thread of ${title}`,visualIdentity:"agent-authored continuity object",conserved:["meaning","evidence status"],transformable:["scale","material","position","topology"],forbidden:["arbitrary replacement"]}];}
function signalProfile(genre){return genre==="logical-proof"?"narration-attention":genre==="poem"?"hybrid-counterpoint":genre==="science"?"formal-score":"narration-attention";}
function semanticCues(text,genre){const words={"logical-proof":["therefore","because","does not","implies"],poem:["but","again","returns"],science:["causes","changes","predicts","measure"],explanatory:["first","then","because","therefore"]}[genre]??["therefore","however"];return words.map(pattern=>({id:stableId("cue",pattern),pattern}));}
function slug(s){return s.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,64)||"essayviz-project";}
