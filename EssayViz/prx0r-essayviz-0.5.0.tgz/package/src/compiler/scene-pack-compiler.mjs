export function compileScenePack(project, storyboard, timing) {
  const themeMap={
    "crisp-white-notation":"whiteScientific","technical-neural":"whiteScientific",
    "ritual-gold":"midnightVellum","mineral-manuscript":"ivoryManuscript",
    "visionary-midnight":"midnightVellum","ash-and-ember":"midnightVellum"
  };
  return {
    version:"1.0",id:project.id,title:project.title,
    description:`Compiled by @prx0r/visionary-engine from ${project.title}`,
    theme:themeMap[project.styleProfile]??"whiteScientific",
    seed:project.seed??260000,
    capabilityPacks:project.capabilities,
    audioManifest:`build/${project.id}/features.json`,
    render:project.render,
    scenes:storyboard.scenes.map(scene=>{
      const time=timing.scenes.find(x=>x.sceneId===scene.id);
      return {
        id:scene.id,title:scene.title,subtitle:scene.subtitle,
        term:"Logicvid",devanagari:"",
        motif:scene.visualContract.motif,duration:time.duration,
        narration:time.narration,
        params:compileParams(scene)
      };
    })
  };
}
function compileParams(scene){
  if(scene.visualContract.motif==="argument-diagram-v2"){
    return {moves:[
      {type:"claim",text:scene.incomingBelief,size:27,start:0.03,end:0.38},
      {type:"divider",start:0.3,end:0.5},
      {type:"converge",text:scene.outgoingBelief,size:25,status:"resolved",start:0.48,end:0.95}
    ]};
  }
  return {visual:"constraint-field",caption:scene.subtitle,contract:scene.visualContract};
}
