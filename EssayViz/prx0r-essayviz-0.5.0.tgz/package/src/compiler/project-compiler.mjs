import { registerBuiltins } from "../registries/builtins.mjs";
import { validateProject } from "../validation/project-validator.mjs";
import {
  planArgument,planContinuity,planCandidates,planStoryboard,planTypography,
  planSignals,planTiming,planRender,planReview
} from "../planners/index.mjs";
import { compileScenePack } from "./scene-pack-compiler.mjs";
import { planMusic } from "../audio/music-planner.mjs";
import { planSoundEffects } from "../audio/sfx-planner.mjs";
import { compileCueSheet } from "../audio/cue-sheet.mjs";

export function compileProject(project) {
  registerBuiltins();
  validateProject(project);
  const argumentIR=planArgument(project);
  const continuity=planContinuity(project,argumentIR);
  const candidates=planCandidates(argumentIR);
  const storyboard=planStoryboard(project,argumentIR,candidates);
  const typography=planTypography(project,storyboard);
  const signals=planSignals(project,storyboard);
  const timing=planTiming(project,storyboard);
  const scenePack=compileScenePack(project,storyboard,timing);
  const renderPlan=planRender(project,storyboard,timing,signals);
  const reviewPlan=planReview(storyboard);
  const musicPlan=planMusic(project.music ?? {
    form:"through-composed", thesis:project.sourceLock.exactContention,
    continuityObject:continuity.systems[0]?.id ?? "argument",
    stages:storyboard.scenes.map(scene=>({id:scene.id,function:scene.operation}))
  });
  const sfxPlan=planSoundEffects(storyboard,project.soundEffects);
  const cueSheet=compileCueSheet({timing,music:musicPlan,sfx:sfxPlan});
  return {argumentIR,continuity,candidates,storyboard,typography,signals,timing,scenePack,renderPlan,reviewPlan,musicPlan,sfxPlan,cueSheet};
}
