const REQUIREMENTS={
 notation:{arrays:['propositions','edges'],objects:['mutation'],min:{propositions:2,edges:1}},
 diagram:{arrays:['nodes','edges'],strings:['layout'],objects:['mutation'],min:{nodes:2,edges:1}},
 object:{strings:['objectName'],arrays:['parts','stateChanges'],objects:['geometry','mutation'],min:{parts:2,stateChanges:1}},
 field:{strings:['fieldType'],arrays:['entities','controlParameters'],objects:['parameters','mutation'],oneOf:['equation','sampler'],min:{entities:1,controlParameters:1}},
 particles:{strings:['particleMeaning'],objects:['emitter','forceField','mutation'],arrays:['constraints']},
 symbolic:{arrays:['constructionSteps','conservedFeatures'],objects:['mutation'],min:{constructionSteps:2,conservedFeatures:1}},
 typographic:{arrays:['sourceTokens','transformRules'],objects:['mutation'],min:{sourceTokens:1,transformRules:1}},
 cinematic:{arrays:['subjects'],objects:['camera','environment','materials','blocking','mutation'],min:{subjects:1}}
};
const GENERIC=/adapted to|performed through|state-changing operation|relation-specific|continuous vector or scalar field|exact object with callouts/i;
export function validateRealizationSpec(spec){
 const errors=[];const mode=spec?.mode;const req=REQUIREMENTS[mode];
 if(!req)return{valid:false,errors:[`unknown or missing mode: ${mode??'none'}`]};
 for(const k of req.strings??[])if(typeof spec[k]!=='string'||!spec[k].trim())errors.push(`${mode}.${k} must be a non-empty string`);
 for(const k of req.arrays??[])if(!Array.isArray(spec[k]))errors.push(`${mode}.${k} must be an array`);
 for(const k of req.objects??[])if(!spec[k]||typeof spec[k]!=='object'||Array.isArray(spec[k]))errors.push(`${mode}.${k} must be an object`);
 for(const [k,n] of Object.entries(req.min??{}))if((spec[k]?.length??0)<n)errors.push(`${mode}.${k} requires at least ${n} items`);
 if(req.oneOf&&!req.oneOf.some(k=>spec[k]!==undefined))errors.push(`${mode} requires one of: ${req.oneOf.join(', ')}`);
 const prose=JSON.stringify(spec);
 if(GENERIC.test(prose))errors.push(`${mode} contains generic placeholder language`);
 if(!spec.invariant||typeof spec.invariant!=='string')errors.push(`${mode}.invariant is required`);
 if(!spec.forbiddenInference||typeof spec.forbiddenInference!=='string')errors.push(`${mode}.forbiddenInference is required`);
 return{valid:errors.length===0,errors};
}
export function requirementsForMode(mode){return structuredClone(REQUIREMENTS[mode]??null);}
