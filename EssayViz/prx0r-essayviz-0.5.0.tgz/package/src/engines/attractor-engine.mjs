import { makeRng } from "../core/determinism.mjs";
const SYSTEMS={
  "stable-node":({x,y},p)=>({x:p.a*(p.cx-x),y:p.b*(p.cy-y)}),
  spiral:({x,y},p)=>{const dx=x-p.cx,dy=y-p.cy;return{x:-p.omega*dy-p.decay*dx,y:p.omega*dx-p.decay*dy};},
  saddle:({x,y},p)=>({x:p.a*(x-p.cx),y:-p.b*(y-p.cy)}),
  "double-well":({x,y},p)=>({x:p.rate*(x-x*x*x)-p.coupling*y,y:p.rate*(y-y*y*y)-p.coupling*x}),
  lorenz:({x,y,z=0},p)=>({x:p.sigma*(y-x),y:x*(p.rho-z)-y,z:x*y-p.beta*z}),
  "limit-cycle":({x,y},p)=>{const r2=x*x+y*y;return{x:p.mu*x-p.omega*y-p.mu*r2*x,y:p.omega*x+p.mu*y-p.mu*r2*y};}
};
const DEFAULTS={a:1,b:1,cx:0,cy:0,omega:1,decay:.2,rate:1,coupling:.1,sigma:10,rho:28,beta:8/3,mu:1};
export class AttractorEngine{
  constructor({system="stable-node",parameters={},dt=1/60,integrator="rk4",seed=1,bounds=null}={}){
    if(!SYSTEMS[system])throw new Error(`Unknown attractor system ${system}`);
    this.system=system;this.parameters={...DEFAULTS,...parameters};this.dt=dt;this.integrator=integrator;this.rng=makeRng(seed);this.bounds=bounds;
  }
  derivative(state){return SYSTEMS[this.system](state,this.parameters);}
  step(state,dt=this.dt){const next=this.integrator==="euler"?euler(state,dt,s=>this.derivative(s)):rk4(state,dt,s=>this.derivative(s));return this.#bound(next);}
  trajectory(initial,{steps=600,dt=this.dt,noise=0}={}){const points=[{...initial}];let state={...initial};for(let i=0;i<steps;i++){state=this.step(state,dt);if(noise){state.x+=(this.rng()-.5)*noise;state.y+=(this.rng()-.5)*noise;}points.push({...state});}return points;}
  field({xmin=-2,xmax=2,ymin=-2,ymax=2,columns=16,rows=10}={}){const vectors=[];for(let j=0;j<rows;j++)for(let i=0;i<columns;i++){const x=xmin+(xmax-xmin)*i/(columns-1),y=ymin+(ymax-ymin)*j/(rows-1);vectors.push({x,y,...this.derivative({x,y,z:0})});}return vectors;}
  #bound(s){if(!this.bounds)return s;const [min,max]=this.bounds;return Object.fromEntries(Object.entries(s).map(([k,v])=>[k,Math.max(min,Math.min(max,v))]));}
}
function euler(s,dt,f){const d=f(s);return mapState(s,(k,v)=>v+dt*(d[k]??0));}
function rk4(s,dt,f){const k1=f(s),k2=f(add(s,k1,dt/2)),k3=f(add(s,k2,dt/2)),k4=f(add(s,k3,dt));return mapState(s,(k,v)=>v+dt*((k1[k]??0)+2*(k2[k]??0)+2*(k3[k]??0)+(k4[k]??0))/6);}
function add(s,k,m){return mapState(s,(key,v)=>v+(k[key]??0)*m);}
function mapState(s,fn){return Object.fromEntries(Object.entries(s).map(([k,v])=>[k,fn(k,v)]));}
export function createAttractorPreset(id,overrides={}){
 const presets={
  "calm-focus":{system:"stable-node",parameters:{a:.7,b:.7}},
  "conceptual-tension":{system:"spiral",parameters:{omega:1.4,decay:.08}},
  "rival-bifurcation":{system:"double-well",parameters:{rate:.8,coupling:.04}},
  "self-organizing-cycle":{system:"limit-cycle",parameters:{mu:.8,omega:1.2}},
  "chaotic-frontier":{system:"lorenz",parameters:{sigma:10,rho:28,beta:8/3}}
 };
 if(!presets[id])throw new Error(`Unknown attractor preset ${id}`);return {...presets[id],...overrides,parameters:{...presets[id].parameters,...overrides.parameters}};
}
