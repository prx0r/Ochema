function alpha(dt,tau){return -Math.expm1(-dt/Math.max(tau,1e-6));}
export class SignalEngine {
  constructor(routes=[]){this.routes=routes;this.state=new Map();}
  sample(features,dt){
    const output={};
    for(const route of this.routes){
      const raw=Number(features[route.source]??0);
      const previous=this.state.get(route.target)??raw;
      const tau=raw>previous?(route.attack??.05):(route.release??.3);
      const value=previous+(raw-previous)*alpha(dt,tau);
      this.state.set(route.target,value);
      output[route.target]=applyRange(value,route.range);
    }
    return output;
  }
}
function applyRange(v,range){if(!range)return v;return range[0]+v*(range[1]-range[0]);}
