const LAYOUTS = {
  chain: layoutChain,
  fork: layoutFork,
  matrix: layoutMatrix,
  radial: layoutRadial,
  layered: layoutLayered,
};

export class DiagramEngine {
  constructor({ layout = "layered", width = 1280, height = 720, padding = 80 } = {}) {
    this.layout = layout;
    this.width = width;
    this.height = height;
    this.padding = padding;
  }

  arrange(graph) {
    const fn = LAYOUTS[this.layout];
    if (!fn) throw new Error(`Unknown diagram layout ${this.layout}`);
    return fn(graph, { width: this.width, height: this.height, padding: this.padding });
  }

  transitions(previous, next) {
    const a = new Map(previous.nodes.map((node) => [node.id, node]));
    const b = new Map(next.nodes.map((node) => [node.id, node]));
    const ids = new Set([...a.keys(), ...b.keys()]);
    return [...ids].map((id) => ({
      id,
      from: a.get(id) ?? null,
      to: b.get(id) ?? null,
      kind: !a.has(id) ? "enter" : !b.has(id) ? "exit" : "move",
    }));
  }
}

function layoutChain(graph, { width = 1280, height = 720, padding = 80 } = {}) {
  const n = graph.nodes.length;
  return {
    ...graph,
    nodes: graph.nodes.map((node, index) => ({
      ...node,
      x: padding + (width - 2 * padding) * (index / Math.max(1, n - 1)),
      y: height / 2,
    })),
  };
}

function layoutFork(graph, { width = 1280, height = 720, padding = 80 } = {}) {
  const root = graph.nodes[0];
  const rest = graph.nodes.slice(1);
  return {
    ...graph,
    nodes: [
      { ...root, x: width / 2, y: padding + 80 },
      ...rest.map((node, index) => ({
        ...node,
        x: padding + (width - 2 * padding) * (index / Math.max(1, rest.length - 1)),
        y: height - padding - 100,
      })),
    ],
  };
}

function layoutMatrix(graph, { width = 1280, height = 720, padding = 80 } = {}) {
  const columns = Math.ceil(Math.sqrt(graph.nodes.length));
  const rows = Math.ceil(graph.nodes.length / columns);
  return {
    ...graph,
    nodes: graph.nodes.map((node, index) => ({
      ...node,
      x: padding + (width - 2 * padding) * ((index % columns) / Math.max(1, columns - 1)),
      y: padding + (height - 2 * padding) * (Math.floor(index / columns) / Math.max(1, rows - 1)),
    })),
  };
}

function layoutRadial(graph, { width = 1280, height = 720 } = {}) {
  const cx = width / 2;
  const cy = height / 2;
  const radius = Math.min(width, height) * 0.32;
  return {
    ...graph,
    nodes: graph.nodes.map((node, index) => ({
      ...node,
      x: cx + Math.cos((index / graph.nodes.length) * Math.PI * 2 - Math.PI / 2) * radius,
      y: cy + Math.sin((index / graph.nodes.length) * Math.PI * 2 - Math.PI / 2) * radius,
    })),
  };
}

function layoutLayered(graph, { width = 1280, height = 720, padding = 80 } = {}) {
  const levels = new Map();
  for (const node of graph.nodes) levels.set(node.id, node.level ?? 0);
  const maxLevel = Math.max(0, ...levels.values());
  const groups = Array.from({ length: maxLevel + 1 }, () => []);
  for (const node of graph.nodes) groups[levels.get(node.id)].push(node);

  return {
    ...graph,
    nodes: groups.flatMap((group, level) =>
      group.map((node, index) => ({
        ...node,
        x: padding + (width - 2 * padding) * ((index + 1) / (group.length + 1)),
        y: padding + (height - 2 * padding) * (level / Math.max(1, maxLevel)),
      })),
    ),
  };
}
