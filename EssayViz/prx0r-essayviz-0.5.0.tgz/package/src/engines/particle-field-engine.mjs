import { makeRng } from "../core/determinism.mjs";
export class ParticleFieldEngine{
  constructor({count=100,seed=1,bounds={x:[-1,1],y:[-1,1]},field,life=[2,6],drag=.02}={}){
    this.rng=makeRng(seed);this.bounds=bounds;this.field=field??((p,t)=>({x:-p.y*.2,y:p.x*.2}));this.life=life;this.drag=drag;
    this.particles=Array.from({length:count},(_,i)=>this.#spawn(i,0));
  }
  #spawn(id,t){const r=this.rng;return{id,x:mix(...this.bounds.x,r()),y:mix(...this.bounds.y,r()),vx:0,vy:0,age:0,life:mix(...this.life,r()),born:t,channel:id%3};}
  step(dt,time,{emit=true,forces=[]}={}){
    this.particles=this.particles.map(p=>{
      let q={...p,age:p.age+dt};if(q.age>=q.life||outside(q,this.bounds))return emit?this.#spawn(q.id,time):q;
      const base=this.field(q,time);let fx=base.x,fy=base.y;for(const force of forces){const f=force(q,time);fx+=f.x;fy+=f.y;}
      q.vx=(q.vx+fx*dt)*(1-this.drag);q.vy=(q.vy+fy*dt)*(1-this.drag);q.x+=q.vx*dt;q.y+=q.vy*dt;return q;
    });return this.snapshot();
  }
  snapshot(){return this.particles.map(p=>({...p,progress:p.age/p.life}));}
}
function mix(a,b,t){return a+(b-a)*t;}function outside(p,b){return p.x<b.x[0]||p.x>b.x[1]||p.y<b.y[0]||p.y>b.y[1];}
export const particleFields={
  vortex:({strength=.6}={})=>(p)=>({x:-p.y*strength,y:p.x*strength}),
  sink:({x=0,y=0,strength=.8}={})=>(p)=>({x:(x-p.x)*strength,y:(y-p.y)*strength}),
  source:({x=0,y=0,strength=.8}={})=>(p)=>({x:(p.x-x)*strength,y:(p.y-y)*strength}),
  wave:({frequency=3,amplitude=.5,speed=1}={})=>(p,t)=>({x:.25,y:Math.sin(p.x*frequency+t*speed)*amplitude}),
  nadi:({amplitude=.45,frequency=3,speed=1}={})=>(p,t)=>({x:-p.x*.7+Math.sin(p.y*frequency+t*speed)*amplitude,y:.35})
};
