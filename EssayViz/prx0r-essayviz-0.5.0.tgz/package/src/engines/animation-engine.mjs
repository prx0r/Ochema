const easing={
 linear:t=>t,
 easeInOut:t=>t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2,
 easeOut:t=>1-Math.pow(1-t,3),
 smooth:t=>t*t*(3-2*t)
};
export function interpolate(from,to,t,curve="smooth"){
  const q=(easing[curve]??easing.smooth)(Math.max(0,Math.min(1,t)));
  if(typeof from==="number"&&typeof to==="number")return from+(to-from)*q;
  if(Array.isArray(from)&&Array.isArray(to))return from.map((v,i)=>interpolate(v,to[i],q,"linear"));
  const out={};for(const key of Object.keys(from))out[key]=interpolate(from[key],to[key],q,"linear");return out;
}
export class AnimationEngine {
  constructor(tracks=[]){this.tracks=tracks;}
  sample(time){
    const values={};
    for(const track of this.tracks){
      const local=(time-track.start)/Math.max(.0001,track.duration);
      values[track.target]=interpolate(track.from,track.to,local,track.easing);
    }
    return values;
  }
}
