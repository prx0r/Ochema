export class CompositionEngine {
  constructor(profile){this.profile=profile;}
  mapBeats(beats){
    const stages=this.profile.stages??[];
    return beats.map((beat,index)=>({
      ...beat,
      compositionStage:stages[Math.min(index,stages.length-1)]??`stage-${index+1}`,
      previous:index?beats[index-1].id:null,
      next:index<beats.length-1?beats[index+1].id:null
    }));
  }
}
