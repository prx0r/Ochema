import { assert } from "../core/assert.mjs";
export class TimelineEngine {
  constructor({duration,events=[]}) {
    assert(duration>0,"timeline duration must be positive");
    this.duration=duration;
    this.events=[...events].sort((a,b)=>a.time-b.time);
  }
  at(time) {
    const t=Math.max(0,Math.min(this.duration,time));
    const active=this.events.filter(e=>e.time<=t && (e.end===undefined || e.end>=t));
    const previous=[...this.events].reverse().find(e=>e.time<=t)??null;
    const next=this.events.find(e=>e.time>t)??null;
    return {time:t,progress:t/this.duration,active,previous,next};
  }
  validate() {
    const errors=[];
    for(const event of this.events){
      if(event.time<0||event.time>this.duration)errors.push(`${event.id}: out of range`);
      if(event.end!==undefined&&event.end<event.time)errors.push(`${event.id}: end before start`);
    }
    return {valid:errors.length===0,errors};
  }
}
