export const TRANSITION_VERBS=Object.freeze([
 "fold","split","transfer","remember","condense","dissolve","entrain",
 "unbind","invert","compare","withhold","germinate","fracture","repair"
]);
export function createTransition({verb,from,to,invariant,duration=1,parameters={}}) {
  if(!TRANSITION_VERBS.includes(verb))throw new Error(`unsupported transition verb ${verb}`);
  return {verb,from,to,invariant,duration,parameters,semantic:true};
}
export function validateTransition(t) {
  const errors=[];
  if(!t.invariant)errors.push("missing invariant");
  if(t.from===t.to)errors.push("from and to must differ");
  if(t.duration<=0)errors.push("duration must be positive");
  return {valid:errors.length===0,errors};
}
