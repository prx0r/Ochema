import { stableId } from "../core/determinism.mjs";
export class VisualObjectEngine {
  constructor(){this.objects=new Map();}
  instantiate(type,props={},semantic={}) {
    const id=props.id??stableId(type,JSON.stringify({props,semantic,count:this.objects.size}));
    const object={id,type,props:{...props},semantic:{
      meaning:semantic.meaning??"",
      conserved:[...(semantic.conserved??[])],
      transformable:[...(semantic.transformable??[])],
      forbidden:[...(semantic.forbidden??[])]
    }};
    this.objects.set(id,object);return object;
  }
  transform(id,patch) {
    const current=this.objects.get(id);
    if(!current)throw new Error(`unknown visual object ${id}`);
    const next={...current,props:{...current.props,...patch}};
    this.objects.set(id,next);return next;
  }
  snapshot(){return [...this.objects.values()].map(x=>structuredClone(x));}
}
