import { mkdir, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { createPackManifest } from "./pack-types.mjs";

export async function scaffoldPack({directory,id,type,title=id}) {
  const root=resolve(directory,id);
  await mkdir(root,{recursive:true});
  const manifest=createPackManifest({
    id,type,title,
    description:`${title} extension pack`,
    runtimeModule:"runtime.mjs",
    provides:defaultProvides(type),
    agentHints:{useWhen:[],avoidWhen:[],creativeQuestions:[]}
  });
  await writeFile(join(root,"pack.json"),JSON.stringify(manifest,null,2)+"\n");
  await writeFile(join(root,"runtime.mjs"),runtimeTemplate(type,id));
  await writeFile(join(root,"README.md"),`# ${title}\n\nType: \`${type}\`\n`);
  return root;
}
function defaultProvides(type){
  const key={
    "visual-object":"objects",animation:"animations",transition:"transitions",
    music:"forms","sound-effect":"cues",typography:"profiles",style:"profiles",
    layout:"layouts",capability:"mechanisms",composition:"profiles",motion:"profiles",
    signal:"routes",backend:"adapters"
  }[type]??"entries";
  return {[key]:[]};
}
function runtimeTemplate(type,id){
  return `export async function register(context){\n  return { id: ${JSON.stringify(id)}, type: ${JSON.stringify(type)}, registered: true, context };\n}\n`;
}
