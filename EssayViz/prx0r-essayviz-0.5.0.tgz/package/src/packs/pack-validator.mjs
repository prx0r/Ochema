import { assert, nonEmptyString } from '../core/assert.mjs';
import { PACK_TYPES } from './pack-types.mjs';
export function validatePackManifest(pack) {
  assert(pack&&typeof pack==='object','pack must be an object');
  nonEmptyString(pack.id,'pack.id');
  assert(/^[a-z0-9][a-z0-9._-]{0,127}$/i.test(pack.id),'pack.id contains unsupported characters');
  assert(PACK_TYPES.includes(pack.type),`unsupported pack type ${pack.type}`);
  assert(typeof pack.provides==='object'&&pack.provides!==null&&!Array.isArray(pack.provides),'pack.provides must be an object');
  if(pack.runtimeModule!==null&&pack.runtimeModule!==undefined){
    nonEmptyString(pack.runtimeModule,'pack.runtimeModule');
    assert(!pack.runtimeModule.includes('\0'),'pack.runtimeModule contains a null byte');
  }
  if(pack.requires!==undefined) assert(Array.isArray(pack.requires),'pack.requires must be an array');
  return {valid:true,id:pack.id,type:pack.type};
}
