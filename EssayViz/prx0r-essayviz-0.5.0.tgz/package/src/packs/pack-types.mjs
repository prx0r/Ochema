export const PACK_TYPES = Object.freeze([
  "capability","composition","style","motion","signal","typography",
  "visual-object","animation","transition","music","sound-effect","layout","backend"
]);
export function createPackManifest(input) {
  return {
    version: input.version ?? "1.0",
    id: input.id,
    type: input.type,
    title: input.title ?? input.id,
    description: input.description ?? "",
    extends: input.extends ?? [],
    compatibility: input.compatibility ?? { visionary: ">=0.2.0" },
    provides: input.provides ?? {},
    defaults: input.defaults ?? {},
    runtimeModule: input.runtimeModule ?? null,
    agentHints: input.agentHints ?? {},
    validation: input.validation ?? {},
  };
}
