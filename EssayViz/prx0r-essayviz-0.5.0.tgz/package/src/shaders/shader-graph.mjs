export class ShaderGraph{
  constructor(){this.nodes=[];this.edges=[];}
  add(id,type,params={}){if(this.nodes.some(n=>n.id===id))throw new Error(`Duplicate shader node ${id}`);this.nodes.push({id,type,params});return this;}
  connect(from,to,input="source"){this.edges.push({from,to,input});return this;}
  topological(){const incoming=new Map(this.nodes.map(n=>[n.id,0]));for(const e of this.edges)incoming.set(e.to,(incoming.get(e.to)??0)+1);const queue=[...incoming].filter(([,d])=>d===0).map(([id])=>id),out=[];while(queue.length){const id=queue.shift();out.push(this.nodes.find(n=>n.id===id));for(const e of this.edges.filter(e=>e.from===id)){incoming.set(e.to,incoming.get(e.to)-1);if(incoming.get(e.to)===0)queue.push(e.to);}}if(out.length!==this.nodes.length)throw new Error("Shader graph contains a cycle");return out;}
  manifest(){return{version:"1.0",nodes:this.nodes,edges:this.edges,order:this.topological().map(n=>n.id)};}
}
