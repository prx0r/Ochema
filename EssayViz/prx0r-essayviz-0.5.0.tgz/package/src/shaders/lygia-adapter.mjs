const CATEGORIES=new Set(["math","space","color","animation","generative","sdf","draw","sample","filter","distort","lighting","geometry","morphological","simulate"]);
export function createLygiaManifest({language="glsl",includes=[],defines={},uniforms={},entry="main"}={}){
  for(const include of includes){const category=include.split("/")[0];if(!CATEGORIES.has(category))throw new Error(`Unknown LYGIA category ${category}`);}
  return {version:"1.0",adapter:"lygia",language,includes,defines,uniforms,entry,
    note:"Manifest only. EssayViz does not redistribute LYGIA source; resolve it in the target shader build and review its license."};
}
export function includeLines(manifest){return manifest.includes.map(path=>`#include "lygia/${path}.${manifest.language==="wgsl"?"wgsl":"glsl"}"`).join("\n");}
export const LYGIA_CATEGORIES=[...CATEGORIES];
