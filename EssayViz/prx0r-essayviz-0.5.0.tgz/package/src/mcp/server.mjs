import readline from 'node:readline';
import { createEssayVizTools, describeEssayVizTools } from '../agent/tool-facade.mjs';

export function createMcpServer(options = {}) {
  const tools = createEssayVizTools(options);
  const descriptions = describeEssayVizTools();
  return {
    async handle(message) {
      const { id, method, params = {} } = message;
      try {
        if (method === 'initialize') return ok(id, { protocolVersion: '2025-03-26', capabilities: { tools: {}, resources: {}, prompts: {} }, serverInfo: { name: 'essayviz', version: '0.4.0' } });
        if (method === 'tools/list') return ok(id, { tools: descriptions.map(d => ({ name: d.name, description: `${d.purpose} Side effects: ${d.sideEffects}`, inputSchema: d.inputSchema })) });
        if (method === 'tools/call') {
          const fn = tools[params.name]; if (!fn) throw new Error(`Unknown tool ${params.name}`);
          const result = await fn(params.arguments ?? {});
          return ok(id, { content: [{ type:'text', text: JSON.stringify(result) }], isError: false });
        }
        if (method === 'resources/list') return ok(id, { resources: [{ uri:'essayviz://skills', name:'EssayViz skills index', mimeType:'application/json' }] });
        if (method === 'resources/read' && params.uri === 'essayviz://skills') return ok(id, { contents: [{ uri:params.uri, mimeType:'application/json', text:JSON.stringify({ skills:['source-analyst','visual-strategist','visual-realizer','audio-director','perception-critic'] }) }] });
        if (method === 'prompts/list') return ok(id, { prompts: [{ name:'essayviz-director', description:'Direct a source-to-render EssayViz workflow.' }] });
        if (method === 'prompts/get' && params.name === 'essayviz-director') return ok(id, { description:'EssayViz director', messages:[{ role:'user', content:{ type:'text', text:'Read the source, create a source lock, compile candidates, require review gates, and never equate planning with rendered quality.' } }] });
        return fail(id, -32601, `Method not found: ${method}`);
      } catch (error) { return fail(id, -32000, error.message, { code:error.code, details:error.details }); }
    }
  };
}
export async function runMcpStdio(options = {}) {
  const server = createMcpServer(options); const rl = readline.createInterface({ input:process.stdin, crlfDelay:Infinity });
  for await (const line of rl) { if (!line.trim()) continue; const response = await server.handle(JSON.parse(line)); process.stdout.write(JSON.stringify(response)+'\n'); }
}
function ok(id,result){return{jsonrpc:'2.0',id,result};}
function fail(id,code,message,data){return{jsonrpc:'2.0',id,error:{code,message,data}};}
