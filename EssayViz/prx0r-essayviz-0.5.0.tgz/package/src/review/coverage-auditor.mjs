export function auditEssayCoverage(ingestion, plan, project = null) {
  const moveIds=new Set(ingestion.rhetoric.moves.map(m=>m.id));
  const planned=new Set(plan.beats.map(b=>b.moveId));
  const compiled=new Set((project?.beats??[]).flatMap(b=>b.essayviz?.sourceMoveIds??[]));
  const missingStrategy=[...moveIds].filter(id=>!planned.has(id));
  const missingCompiled=project?[...moveIds].filter(id=>!compiled.has(id)):[];
  const duplicatedCompiled=project?duplicates((project.beats??[]).flatMap(b=>b.essayviz?.sourceMoveIds??[])):[];
  const ungrounded=plan.beats.filter(b=>b.selected.mode==='object'&&!b.selected.objectGrounding.length).map(b=>b.moveId);
  const repeated=detectRuns(plan.beats.map(b=>b.selected.mode),3);
  return {
    version:'1.1',
    coverage:(moveIds.size-missingStrategy.length)/Math.max(1,moveIds.size),
    strategyCoverage:(moveIds.size-missingStrategy.length)/Math.max(1,moveIds.size),
    compiledCoverage:project?(moveIds.size-missingCompiled.length)/Math.max(1,moveIds.size):null,
    missingStrategy,missingCompiled,duplicatedCompiled,ungrounded,repeatedModeRuns:repeated,
    passed:missingStrategy.length===0&&missingCompiled.length===0&&duplicatedCompiled.length===0&&repeated.length===0
  };
}
function detectRuns(xs,max){const out=[];let start=0;for(let i=1;i<=xs.length;i++){if(xs[i]!==xs[start]){if(i-start>max)out.push({mode:xs[start],start,length:i-start});start=i;}}return out;}
function duplicates(xs){const seen=new Set(),dupes=new Set();for(const x of xs){if(seen.has(x))dupes.add(x);seen.add(x);}return [...dupes];}
