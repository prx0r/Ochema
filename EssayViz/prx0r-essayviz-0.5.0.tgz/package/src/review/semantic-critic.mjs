export function critiqueVisualPlan({move,candidate,scene}){
 const failures=[];
 if(candidate.scores?.semanticFit<75)failures.push(issue("hard_fail","semantic-fit","Candidate does not encode the rhetorical operation.","Change topology or mode."));
 if(candidate.scores?.silentLegibility<65)failures.push(issue("soft_fail","silent-legibility","The relation may depend too heavily on narration.","Add visible state change, labels or comparison structure."));
 if(!scene?.invariant)failures.push(issue("hard_fail","invariant","No continuity invariant declared.","Declare what must survive transformation."));
 if(!scene?.forbiddenInference)failures.push(issue("hard_fail","epistemic-restraint","No forbidden inference declared.","State the strongest visual overclaim to avoid."));
 if(["field","particles","cinematic"].includes(candidate.mode)&&move.role==="premise")failures.push(issue("advisory","mode-mismatch","A premise may be clearer in notation before abstraction.","Consider notation lead followed by field elaboration."));
 return{passed:!failures.some(f=>f.severity==="hard_fail"),failures};
}
function issue(severity,test,observation,patchInstruction){return{severity,test,observation,patchInstruction};}
