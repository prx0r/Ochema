import { validateRealizationSpec } from '../realization/spec-validator.mjs';
export function evaluateBeautyGate({storyboard,realizations={},renderReview={}}){
 const scenes=storyboard.scenes.map(scene=>{
  const spec=realizations[scene.id];const validation=validateRealizationSpec(spec);
  const review=renderReview[scene.id]??{};
  const gates={
   realizationSpecificity:validation.valid,
   renderedFrames:Boolean(review.framesInspected),
   silentLegibility:review.silentLegibility===true,
   transitionCausality:review.transitionCausality===true,
   typography:review.typographyPass===true,
   continuity:review.continuityPass===true,
   forbiddenInference:review.forbiddenInferencePass===true
  };
  return{sceneId:scene.id,mode:spec?.mode??null,gates,errors:validation.errors,pass:Object.values(gates).every(Boolean)};
 });
 return{version:'1.0',scenes,pass:scenes.every(s=>s.pass),summary:{total:scenes.length,passed:scenes.filter(s=>s.pass).length,missingRealization:scenes.filter(s=>!s.gates.realizationSpecificity).length,unreviewed:scenes.filter(s=>!s.gates.renderedFrames).length}};
}
