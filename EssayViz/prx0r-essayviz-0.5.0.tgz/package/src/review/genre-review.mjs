const TESTS={
 "logical-proof":["every edge has an epistemic status","decisive mutations occur on the correct clause","scope brackets match the conclusion","countermodels are structurally fair"],
 poem:["visuals preserve ambiguity","refrain or image invariant survives","transformation follows prosody rather than nouns","no diagram explains the poem away"],
 explanatory:["every exact object is grounded","visual adds spatial or causal information","named components appear before or as they are introduced","mechanism can be inferred silently"],
 science:["data, model, simulation and interpretation are distinct","interventions change measurable state","particles and fields encode a specified quantity","uncertainty remains visible"],
 comparative:["rivals begin from shared evidence","panel density and prestige are balanced","one intervention produces divergent predictions","selection is not hidden in style"],
 investigative:["evidence classes remain distinct","hypotheses remain live until discriminated","timeline and source provenance are legible","uncertainty is not resolved by dramatic music"],
 tutorial:["actions match exact UI or object state","errors and checkpoints are visible","result is verified","timing follows action completion"],
 "textual-scholarship":["source, translation and reconstruction are labelled","quoted text is not silently paraphrased","term segmentation is accurate","metaphysical interpretation is separated from philology"],
 narrative:["character and place continuity survive","camera subjectivity is intentional","motifs return with transformed meaning","exposition does not replace dramatic action"],
 hybrid:["each beat uses the appropriate local genre gate","style remains coherent across mode changes"]
};
export function planGenreReview(genre,beats){return{version:"1.0",genre,globalTests:TESTS[genre]??TESTS.hybrid,beats:beats.map(beat=>({moveId:beat.moveId,mode:beat.selected.mode,tests:modeTests(beat.selected.mode)}))};}
function modeTests(mode){return({notation:["math legible","edge semantics clear","no text collision"],diagram:["topology matches relation","layout does not imply hierarchy accidentally"],object:["object grounded","callouts point to exact structures"],field:["state quantity specified","trajectory is causal rather than decorative"],particles:["particle meaning specified","emission and advection have separate roles"],symbolic:["construction law documented","symbol is not used as unearned evidence"],typographic:["language transformation preserves wording status","line breaks and emphasis are intentional"],cinematic:["camera adds subjectivity or scale","material scene justifies production cost"]})[mode]??[];}
