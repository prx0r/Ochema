import { join } from 'node:path';
import { compileEssay } from '../compiler/essay-compiler.mjs';
import { validateProject } from '../validation/project-validator.mjs';
import { readJson,writeJson } from '../core/fs.mjs';
import { scaffoldPack } from '../packs/scaffold.mjs';
import { loadPack } from '../packs/pack-loader.mjs';
import { inspectMotherfucker } from '../adapters/motherfucker.mjs';
import { resolveWithinRoots } from '../security/path-policy.mjs';

export function createEssayVizTools({inputPolicy={},packTrust={},frameworkRoot='MOTHERFUCKER',allowedSourceRoots=[process.cwd()],allowedWriteRoots=[process.cwd()]}={}){
  return{
    'essayviz.planEssay':async({path,genre='auto',maxBeats=14,outDir='build/essayviz-mcp'})=>{
      const source=resolveWithinRoots(path,allowedSourceRoots,{purpose:'source path'});const out=resolveWithinRoots(outDir,allowedWriteRoots,{purpose:'output directory'});
      const result=await compileEssay(source,{genre,maxBeats,inputPolicy});const files={'project.json':result.project,'source-lock.json':result.project.sourceLock,'storyboard.json':result.storyboard,'scene-pack.json':result.scenePack,'render-plan.json':{...result.renderPlan,packPath:join(out,'scene-pack.json')},'review-plan.json':result.reviewPlan,'coverage-audit.json':result.coverage};
      for(const[name,value]of Object.entries(files))await writeJson(join(out,name),value);
      return{projectId:result.project.id,genre:result.ingestion.classification.genre,beatCount:result.project.beats.length,outputDirectory:out,artifacts:Object.keys(files).map(name=>join(out,name)),warnings:result.ingestion.warnings};
    },
    'essayviz.validateProject':async({path})=>validateProject(await readJson(resolveWithinRoots(path,allowedSourceRoots,{purpose:'project path'}))),
    'essayviz.scaffoldPack':async args=>scaffoldPack({...args,directory:resolveWithinRoots(args.directory,allowedWriteRoots,{purpose:'pack directory'})}),
    'essayviz.loadPack':async({path,loadRuntime=false})=>loadPack(resolveWithinRoots(path,allowedSourceRoots,{purpose:'pack path'}),{loadRuntime,...packTrust}),
    'essayviz.doctor':async()=>inspectMotherfucker(resolveWithinRoots(frameworkRoot,allowedSourceRoots,{purpose:'framework root'})),
  };
}
export function describeEssayVizTools(){return[
  {name:'essayviz.planEssay',purpose:'Compile an essay and write bounded planning artifacts.',sideEffects:'Reads one allowed source and writes an allowed output directory.',inputSchema:{type:'object',required:['path'],properties:{path:{type:'string'},genre:{type:'string'},maxBeats:{type:'integer',minimum:1,maximum:100},outDir:{type:'string'}},additionalProperties:false}},
  {name:'essayviz.validateProject',purpose:'Validate a project before compilation.',sideEffects:'Read-only.',inputSchema:{type:'object',required:['path'],properties:{path:{type:'string'}},additionalProperties:false}},
  {name:'essayviz.scaffoldPack',purpose:'Create an extension-pack skeleton.',sideEffects:'Writes an allowed directory.',inputSchema:{type:'object',required:['id','type','directory'],properties:{id:{type:'string'},type:{type:'string'},directory:{type:'string'},title:{type:'string'}},additionalProperties:false}},
  {name:'essayviz.loadPack',purpose:'Validate a pack; runtime code is disabled unless server policy explicitly trusts it.',sideEffects:'Read-only unless trusted runtime code is enabled.',inputSchema:{type:'object',required:['path'],properties:{path:{type:'string'},loadRuntime:{type:'boolean'}},additionalProperties:false}},
  {name:'essayviz.doctor',purpose:'Inspect renderer compatibility.',sideEffects:'Read-only.',inputSchema:{type:'object',properties:{},additionalProperties:false}},
];}
