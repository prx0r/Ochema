const BACKENDS={
  skia:{strengths:["typography","precise vector notation","deterministic CPU rendering"],bestFor:["proofs","diagrams","manuscript plates","exact objects"],contract:{input:"scene-pack",output:"PNG frames / MP4"}},
  svg:{strengths:["editable vectors","publication export","DOM inspection"],bestFor:["diagrams","math","interactive annotation"],contract:{input:"visual IR",output:"SVG documents"}},
  regl:{strengths:["stateless WebGL commands","custom shaders","framebuffers"],bestFor:["fields","particles","feedback","filters"],contract:{input:"shader graph + resources",output:"WebGL frames"}},
  "motion-canvas":{strengths:["generator timing","signals","voice-over preview","vector scenes"],bestFor:["explanatory animation","tutorials","proof walkthroughs"],contract:{input:"storyboard + cues",output:"TypeScript scene modules"}},
  remotion:{strengths:["parameterized video","React composition","captions","server rendering"],bestFor:["templated series production","mixed media","web deployment"],contract:{input:"render plan",output:"React compositions"}},
  "three-webgpu":{strengths:["3D","compute shaders","node materials","WebGL fallback"],bestFor:["spatial worlds","large simulations","anatomical depth","camera subjectivity"],contract:{input:"shader graph + scene graph",output:"WebGPU/WebGL frames"}},
  pixi:{strengths:["display tree","render textures","filters","sprites"],bestFor:["compositing","image assets","2D particles","post-processing"],contract:{input:"layer graph",output:"WebGL/WebGPU 2D frames"}}
};
export function getBackendProfile(id){const p=BACKENDS[id];if(!p)throw new Error(`Unknown backend ${id}`);return{id,...p};}
export function listBackends(){return Object.entries(BACKENDS).map(([id,p])=>({id,...p}));}
export function recommendBackend(scene){const mode=scene.mode??scene.visualMode;if(["notation","diagram","typographic","object"].includes(mode))return getBackendProfile("skia");if(["field","particles"].includes(mode))return getBackendProfile("regl");if(mode==="cinematic")return getBackendProfile("three-webgpu");return getBackendProfile("skia");}
