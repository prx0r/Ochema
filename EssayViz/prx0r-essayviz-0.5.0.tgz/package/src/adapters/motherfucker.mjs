import { access } from 'node:fs/promises';
import { join,resolve } from 'node:path';
import { spawn } from 'node:child_process';
import { VisionaryError } from '../core/errors.mjs';

export async function inspectMotherfucker(root){
  const required=['renderer.mjs','motifs.mjs','schema.mjs','tools/render-pack.mjs'];const missing=[];
  for(const file of required){try{await access(join(resolve(root),file));}catch{missing.push(file);}}
  return{root:resolve(root),valid:missing.length===0,missing};
}
export async function runMotherfuckerRender(renderPlan,{frameworkRoot,dryRun=false,timeoutMs=30*60_000,signal,logger}={}){
  const root=resolve(frameworkRoot);const inspection=await inspectMotherfucker(root);
  if(!inspection.valid)throw new VisionaryError('Invalid MOTHERFUCKER framework root',{details:inspection});
  const args=[join(root,'tools/render-pack.mjs'),resolve(renderPlan.packPath)];
  if(dryRun)return{command:process.execPath,args,cwd:root};
  logger?.info('render.started',{root,args,timeoutMs});
  return new Promise((resolvePromise,reject)=>{
    const child=spawn(process.execPath,args,{cwd:root,stdio:'inherit'});let settled=false;
    const finish=(fn,value)=>{if(settled)return;settled=true;clearTimeout(timer);signal?.removeEventListener?.('abort',abort);fn(value);};
    const abort=()=>{child.kill('SIGTERM');setTimeout(()=>child.kill('SIGKILL'),2000).unref();finish(reject,new VisionaryError('Render aborted',{code:'RENDER_ABORTED'}));};
    signal?.addEventListener?.('abort',abort,{once:true});
    const timer=setTimeout(()=>{child.kill('SIGTERM');setTimeout(()=>child.kill('SIGKILL'),2000).unref();finish(reject,new VisionaryError(`Renderer timed out after ${timeoutMs}ms`,{code:'RENDER_TIMEOUT'}));},timeoutMs);
    child.on('error',error=>finish(reject,error));
    child.on('exit',code=>{logger?.info('render.exited',{code});code===0?finish(resolvePromise,{code}):finish(reject,new VisionaryError(`renderer exited ${code}`,{code:'RENDER_FAILED',details:{exitCode:code}}));});
  });
}
