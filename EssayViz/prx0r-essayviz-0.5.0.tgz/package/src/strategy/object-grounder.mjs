const DOMAIN_PATTERNS=[
  ["brain",/brain|cortex|neural|neuron|synapse/i,"neurocognition"],
  ["body",/body|organ|heart|lung|cell|tissue|anatom/i,"human-anatomy"],
  ["subtle-body",/cakra|chakra|nāḍī|nadi|kundalini|mantra/i,"yogic-subtle-body"],
  ["text",/verse|manuscript|translation|commentary|chapter/i,"textual-scholarship"],
  ["math",/equation|variable|function|matrix|graph|topology|quotient/i,"mathematical-notation"],
  ["physics",/field|particle|quantum|energy|entropy|wave/i,"physics-visuals"],
  ["biology",/organism|morphology|regulation|evolution|ecology/i,"systems-biology"],
  ["ritual",/ritual|deity|yantra|lotus|mudrā|temple/i,"tantric-geometry"]
];
export function groundObjects(text,{catalog=[]}={}){
  const grounded=[];
  for(const [kind,pattern,capability] of DOMAIN_PATTERNS){if(pattern.test(text))grounded.push({kind,capability,confidence:.82,source:"lexical"});}
  for(const object of catalog){if(new RegExp(`\\b${escapeRegex(object.name)}\\b`,`i`).test(text))grounded.push({kind:"catalog-object",capability:object.pack,id:object.id,confidence:.95,source:"catalog"});}
  return dedupe(grounded);
}
function escapeRegex(s){return s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");}
function dedupe(xs){const m=new Map();for(const x of xs)m.set(`${x.capability}:${x.id??x.kind}`,x);return [...m.values()];}
