import { getGenreProfile } from "./genre-profiles.mjs";
import { createCandidates } from "./candidate-factory.mjs";
export function routeVisualStrategies(rhetoric,classification,options={}){
  const genre=classification.genre==="hybrid"?(classification.primaryGenre??"hybrid"):classification.genre;
  const profile=getGenreProfile(genre);let previous=null,run=0;
  const beats=rhetoric.moves.map(move=>{
    const candidates=createCandidates(move,{genre,objectCatalog:options.objectCatalog});
    let selected=candidates.find(c=>c.scores.semanticFit>=78&&c.scores.silentLegibility>=70&&!c.hardFailures.length)??candidates[0];
    if(selected.mode===previous){run+=1;}else{previous=selected.mode;run=1;}
    if(run>2){const alternative=candidates.find(c=>c.mode!==selected.mode&&!c.hardFailures.length&&c.scores.semanticFit>=selected.scores.semanticFit-12);if(alternative){selected=alternative;previous=selected.mode;run=1;}}
    return{moveId:move.id,role:move.role,relation:move.relation,profile,candidates,selected,selectionReason:`highest viable semantic and genre fit for ${move.role}/${move.relation}, with anti-monotony routing`};
  });
  return{version:"1.1",genre,profile,beats};
}
