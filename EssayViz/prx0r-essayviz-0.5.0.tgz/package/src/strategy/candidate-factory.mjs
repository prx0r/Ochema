import { getGenreProfile } from "./genre-profiles.mjs";
import { groundObjects } from "./object-grounder.mjs";

const MODES = ["notation", "diagram", "object", "field", "particles", "symbolic", "typographic", "cinematic"];
const GENRE_MODE_PRIORS = {
  "logical-proof": { notation: 30, diagram: 24, typographic: 10 },
  poem: { field: 26, symbolic: 28, typographic: 24, cinematic: 12 },
  explanatory: { object: 30, diagram: 26, cinematic: 8 },
  science: { field: 26, particles: 24, diagram: 22, notation: 15 },
  comparative: { diagram: 30, notation: 24, object: 8 },
  investigative: { object: 22, diagram: 24, cinematic: 18, typographic: 8 },
  tutorial: { object: 28, diagram: 24, typographic: 14 },
  "textual-scholarship": { typographic: 28, object: 22, notation: 20, symbolic: 8 },
  narrative: { cinematic: 28, object: 20, symbolic: 18 },
  hybrid: {},
};

export function createCandidates(move, { genre = "hybrid", objectCatalog = [] } = {}) {
  const profile = getGenreProfile(genre);
  const objects = groundObjects(move.text, { catalog: objectCatalog });
  const candidates = MODES.map((mode, index) => {
    const semanticFit = compatibility(mode, move, genre, objects);
    return {
      id: `${move.id}-${mode}`,
      mode,
      genre,
      relation: move.relation,
      topology: topologyFor(mode, move.relation),
      decisiveMutation: mutationFor(mode, move.role, move.relation),
      objectGrounding: objects,
      capabilities: [...new Set(objects.map((item) => item.capability))],
      audioCoupling: audioFor(mode, profile.audio),
      scores: {
        semanticFit,
        genreFit: 65 + (GENRE_MODE_PRIORS[genre]?.[mode] ?? 0),
        silentLegibility: silent(mode),
        novelty: 55 + index * 5,
        renderRisk: risk(mode),
      },
      hardFailures: objectFailure(mode, objects),
    };
  });

  return candidates.sort((a, b) => utility(b) - utility(a));
}

function compatibility(mode, move, genre, objects) {
  let score = 52 + (GENRE_MODE_PRIORS[genre]?.[mode] ?? 0);
  if (move.role === "premise" && mode === "notation") score += 26;
  if (move.role === "mechanism" && ["diagram", "field", "particles"].includes(mode)) score += 24;
  if (move.role === "definition" && ["typographic", "object", "notation"].includes(mode)) score += 18;
  if (["rival", "objection", "discriminator"].includes(move.role) && ["diagram", "notation"].includes(mode)) score += 18;
  if (move.relation === "bridge-failure" && ["notation", "diagram"].includes(mode)) score += 24;
  if (move.relation === "transformation" && ["field", "symbolic", "cinematic"].includes(mode)) score += 18;
  if (mode === "object" && objects.length) score += 24;
  if (mode === "object" && !objects.length) score -= 28;
  return Math.max(0, Math.min(100, score));
}

function objectFailure(mode, objects) {
  return mode === "object" && !objects.length ? ["No exact object grounding found"] : [];
}
function utility(candidate) {
  return candidate.scores.semanticFit * 1.5 + candidate.scores.genreFit + candidate.scores.silentLegibility * 0.4 - candidate.scores.renderRisk - candidate.hardFailures.length * 60;
}
function silent(mode) {
  return ["notation", "diagram", "object"].includes(mode) ? 90 : ["field", "particles", "symbolic"].includes(mode) ? 74 : 66;
}
function risk(mode) {
  return { notation: 10, diagram: 15, object: 25, field: 42, particles: 48, symbolic: 35, typographic: 18, cinematic: 55 }[mode];
}
function topologyFor(mode, relation) {
  return ({
    notation: "typed propositions and semantic edges",
    diagram: "relation-specific graph or process diagram",
    object: "exact object with callouts and state changes",
    field: "continuous vector or scalar field",
    particles: "agents advected by a semantic field",
    symbolic: "constructed geometric symbol",
    typographic: "text as spatial and temporal material",
    cinematic: "camera, depth and material scene",
  })[mode] + ` for ${relation}`;
}
function mutationFor(mode, role, relation) {
  return `${role}:${relation} enacted by ${mode} through a state-changing operation`;
}
function audioFor(mode, audio) {
  return {
    mode: audio.narration,
    formal: mode === "notation" ? "word-boundary" : mode === "field" ? "score-event" : "phrase-boundary",
    music: audio.music,
    sfx: audio.sfx,
  };
}
