const INJECTION_PATTERNS=[
  /ignore (all|any|the) previous instructions/ig,
  /system prompt/ig,
  /you are now/ig,
  /classify this as/ig,
  /call the tool/ig,
  /exfiltrat/ig,
];
export function scanSourceRisks(text){
  const findings=[];
  for(const pattern of INJECTION_PATTERNS){for(const match of text.matchAll(pattern))findings.push({type:'instruction-like-source-text',match:match[0],offset:match.index,severity:'warning'});}
  return findings;
}
