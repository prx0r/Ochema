import { realpath } from 'node:fs/promises';
import { dirname, resolve, relative, isAbsolute } from 'node:path';
import { VisionaryError } from '../core/errors.mjs';

export async function resolveTrustedRuntime(manifestPath, runtimeModule, {
  allowedRoots = [dirname(resolve(manifestPath))], allowRuntimeCode = false
} = {}) {
  if (!runtimeModule) return null;
  if (!allowRuntimeCode) {
    throw new VisionaryError('Runtime code loading is disabled by default', {
      code: 'UNTRUSTED_PACK_RUNTIME', details: { manifestPath, runtimeModule }
    });
  }
  const candidate = resolve(dirname(resolve(manifestPath)), runtimeModule);
  const realCandidate = await realpath(candidate);
  const trusted = await Promise.all(allowedRoots.map(root => realpath(resolve(root)).catch(() => resolve(root))));
  const inside = trusted.some(root => {
    const rel = relative(root, realCandidate);
    return rel === '' || (!rel.startsWith('..') && !isAbsolute(rel));
  });
  if (!inside) {
    throw new VisionaryError('Pack runtime escapes allowed roots', {
      code: 'PACK_PATH_ESCAPE', details: { realCandidate, allowedRoots: trusted }
    });
  }
  return realCandidate;
}
