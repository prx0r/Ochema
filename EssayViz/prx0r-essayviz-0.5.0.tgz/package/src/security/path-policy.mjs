import { resolve, relative, isAbsolute } from 'node:path';
import { VisionaryError } from '../core/errors.mjs';
export function resolveWithinRoots(path,roots,{purpose='path'}={}){
  const target=resolve(path);const allowed=(roots?.length?roots:[process.cwd()]).map(resolve);
  const ok=allowed.some(root=>{const rel=relative(root,target);return rel===''||(!rel.startsWith('..')&&!isAbsolute(rel));});
  if(!ok)throw new VisionaryError(`${purpose} is outside allowed roots`,{code:'PATH_NOT_ALLOWED',details:{target,allowed}});
  return target;
}
