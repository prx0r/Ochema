import { stat, readFile } from 'node:fs/promises';
import { VisionaryError } from '../core/errors.mjs';

export const DEFAULT_INPUT_POLICY = Object.freeze({
  maxBytes: 2_000_000,
  maxWords: 30_000,
  maxSentences: 8_000,
  allowEmpty: false,
  allowCodeDominant: false,
  acceptedExtensions: ['.md', '.markdown', '.txt'],
});

export async function readSourceWithPolicy(path, policy = {}) {
  const effective = { ...DEFAULT_INPUT_POLICY, ...policy };
  const info = await stat(path);
  if (info.size > effective.maxBytes) {
    throw new VisionaryError(`Source exceeds maxBytes (${info.size} > ${effective.maxBytes})`, {
      code: 'INPUT_TOO_LARGE', details: { path, bytes: info.size, policy: effective }
    });
  }
  const text = await readFile(path, 'utf8');
  const words = (text.match(/\S+/g) ?? []).length;
  if (!effective.allowEmpty && words === 0) {
    throw new VisionaryError('Source is empty', { code: 'EMPTY_SOURCE', details: { path } });
  }
  if (words > effective.maxWords) {
    throw new VisionaryError(`Source exceeds maxWords (${words} > ${effective.maxWords})`, {
      code: 'INPUT_TOO_LARGE', details: { path, words, policy: effective }
    });
  }
  return { text, bytes: info.size, words, policy: effective };
}
