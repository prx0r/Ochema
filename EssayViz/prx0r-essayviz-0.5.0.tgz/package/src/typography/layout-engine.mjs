export class TypographyLayoutEngine {
  constructor(profile){this.profile=profile;}
  layout(blocks,{width=1280,height=720,margin=72,gap=20}={}){
    let y=margin;const placed=[];
    for(const block of blocks){
      const size=block.size??this.profile.minimumBodyPx??14;
      const lines=wrap(block.text,block.maxChars??Math.floor((width-margin*2)/(size*.56)));
      const h=lines.length*size*1.28;
      if(y+h>height-margin)throw new Error(`typography overflow in block ${block.id??placed.length}`);
      placed.push({...block,x:block.align==="left"?margin:width/2,y,width:width-margin*2,height:h,lines});
      y+=h+gap;
    }
    return placed;
  }
}
function wrap(text,max){
  const words=text.split(/\s+/),lines=[];let line="";
  for(const word of words){
    const candidate=line?`${line} ${word}`:word;
    if(candidate.length>max&&line){lines.push(line);line=word;}else line=candidate;
  }
  if(line)lines.push(line);return lines;
}
