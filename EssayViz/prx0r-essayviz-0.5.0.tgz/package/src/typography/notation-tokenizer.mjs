const tokenPattern=/(\\[A-Za-z]+|⇒|⇏|↔|∴|∧|∨|¬|∃|∀|[A-Za-z]_[A-Za-z0-9∞]+|[A-Za-z]\([^)]+\))/g;
export function tokenizeNotation(text){
  const parts=[];let last=0;
  for(const match of text.matchAll(tokenPattern)){
    if(match.index>last)parts.push({type:"prose",value:text.slice(last,match.index)});
    parts.push({type:"math",value:match[0]});last=match.index+match[0].length;
  }
  if(last<text.length)parts.push({type:"prose",value:text.slice(last)});
  return parts;
}
