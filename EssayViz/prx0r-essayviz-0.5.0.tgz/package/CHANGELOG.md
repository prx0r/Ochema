# Changelog

## 0.5.0

- Added mode-specific realization specification validation.
- Added rendered beauty gate requiring frame inspection.
- Added `essayviz beauty-check`.
- Generic placeholder topology language now fails realization validation.
- Added destructive six-genre beauty-or-bullshit benchmark.

# Changelog

## 0.4.0 — Production hardening and red team

- Added bounded input policies and early empty/oversize failures.
- Added classifier abstention, non-Latin warnings and code-block isolation.
- Added source prompt-injection warnings and line provenance.
- Added external JSON/LLM analysis-provider boundary.
- Added secure-by-default pack loading and trusted-root containment.
- Added replaceable TTS providers, Edge, generic command/HTTP, ElevenLabs timestamps and mock testing.
- Added character-to-word alignment utilities and regex-safe cue matching.
- Added local MCP tool facade with bounded filesystem roots and artifact-return semantics.
- Added renderer timeout, cancellation and structured errors.
- Added deeper project validation and compiled source-move coverage.
- Added 13 hostile/security/provider tests, raising the suite to 48 tests.
- Added production checklist, residual-risk register and corpus report.


## 0.3.0 — EssayViz

- Renamed the package to `@prx0r/essayviz`.
- Added Markdown essay ingestion.
- Added genre classification and rhetorical analysis.
- Added eight visual candidate modes.
- Added genre-specific routing, audio and review policies.
- Added exact-object grounding.
- Added raw-essay compilation and CLI commands.
- Added stable attractor, particle field and diagram engines.
- Added shader graphs, LYGIA manifests and GPU prototypes.
- Added word-level semantic audio coupling.
- Added Skia, SVG, regl, Motion Canvas, Remotion, Three/WebGPU and Pixi backend profiles.
- Added specialist agent skills and genre skills.
- Added eight genre examples, advanced visual demos and framework research.
- Expanded the test suite to 35 tests before packaging.

## 0.2.0

- Added pack extension engines, music, SFX, typography and pack scaffolding.

## 0.1.0

- Initial typed authoring and orchestration framework.
