# Test Report — v0.4.0

Executed successfully:

```text
48 unit, red-team, security and provider tests
2 renderer-adapter integration tests
8 genre examples compiled
14-source normal/hostile corpus run
Essay 3 project validation and compilation
advanced visual demo
framework comparison demo
```

Destructive pre-fix benchmark:

```text
140,002 words
10.38 seconds
approximately 2.4 GB RSS
853 MB output
```

The same class of input is now rejected by bounded input policy before rhetorical
candidate expansion.

Not executed in this environment:

- live native Skia rendering against the current repository;
- real external TTS billing/rate-limit behavior;
- remote authenticated MCP transport;
- GPU shader compilation across target devices;
- perceptual quality certification of final frames.
