# Multi-Agent Workflow

```text
Source Analyst
→ Visual Strategist
→ Director approval
→ Visual Realizer
→ Audio Director
→ deterministic validation
→ renderer
→ Perception Critic
→ targeted patches
→ Director release gate
```

## Why roles are separated

The model that invents a visual tends to rationalize it. The model that writes
renderer code tends to optimize for what is easy to implement. The source
analyst should not inherit either bias. The perception critic should receive
rendered evidence and the source contract, not the inventor's private drafting
narrative.

## Patch protocol

```json
{
  "severity": "hard_fail",
  "sceneId": "sc-04",
  "observation": "The object disappears before the claimed identity transfer.",
  "failedTest": "continuity invariant",
  "patchTarget": "scene.motion",
  "patchInstruction": "Preserve the contour through the carrier transition."
}
```
