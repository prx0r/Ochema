# Storyboarding

A storyboard scene is a belief transformation.

```text
incoming audience model
→ visual operation
→ outgoing audience model
```

## Design backward

Begin with:

- discriminator;
- recognition;
- unresolved edge.

Then ask what must have been prepared earlier.

## Scene fields

- argument function;
- relation;
- invariant;
- topology;
- decisive mutation;
- continuity handoff;
- signal strategy;
- typography load;
- transition verb;
- review test.

## Transition verbs

- fold;
- split;
- transfer;
- remember;
- condense;
- dissolve;
- entrain;
- unbind;
- invert;
- compare;
- withhold.

Avoid transition nouns such as “fade” unless fading is the semantic operation.
