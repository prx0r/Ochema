# Music and Sound Effects

## Music packs

A music pack defines:

- form;
- continuity identity;
- transformation operators;
- orchestral carriers;
- cadence and silence policy;
- feature bus.

Example forms:

- migrating passacaglia;
- relational fugue;
- canon;
- phasing;
- spectral field;
- raga-like development;
- through-composed sparse score.

## Sound effects

SFX should have semantic roles:

- semantic transition;
- material contact;
- spatial cue;
- ritual action;
- interface;
- environment.

Examples:

```text
edge becomes licensed → soft lock
unsupported implication cut → filtered air cut
paper geometry folds → paper tension
ritual installation → restrained bell
membrane recovery → low pulse
```

## Mixing policy

- narration has priority;
- SFX remain optional;
- no more than two simultaneous SFX by default;
- use ducking under speech;
- avoid trailer-style impacts for every conclusion;
- silence must be authored, not automatic.
