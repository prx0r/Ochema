# Architecture

## Package layer

`@prx0r/visionary-engine` is a pure authoring layer.

It owns:

- typed project definitions;
- source locks;
- argument IR;
- continuity planning;
- candidate tournaments;
- storyboards;
- typography;
- timing;
- signal routing;
- review planning;
- backend adapters.

## Renderer layer

`MOTHERFUCKER` owns:

- canvas creation;
- motif dispatch;
- capability runtime activation;
- Skia drawing;
- geometry;
- particles;
- materials;
- per-frame audio sampling;
- FFmpeg streaming.

## Why separate them?

The authoring framework can evolve without destabilizing rendering.

Alternative backends can consume the same IR.

Agents can reason about the film without importing Skia.

The renderer remains deterministic and simple.
