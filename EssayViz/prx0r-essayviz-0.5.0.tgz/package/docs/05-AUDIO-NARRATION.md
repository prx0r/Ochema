# Audio and Narration

## Does audio need to exist first?

Only when reacting to the final performance.

### Narration-led film

1. generate scene narration;
2. synthesize each scene separately;
3. measure duration with ffprobe;
4. update scene timing;
5. concatenate narration;
6. analyze features;
7. render;
8. mux.

### Procedural score

Use event data first, then synthesize.

### Existing music

Analyze the final track first.

## Attention budget

During dense narration:

- reduce new particles;
- reduce secondary motion;
- preserve explanatory geometry;
- avoid new labels.

During silence:

- let the visual operation complete;
- do not automatically black out.
