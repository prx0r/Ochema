# End-to-End Pipeline

```text
source.md
→ source-lock.json
→ project.json
→ visionary validate
→ visionary compile
→ planning bundle
→ author candidate selections
→ authored visual programs
→ TTS/audio
→ measured timing
→ scene-pack.json
→ MOTHERFUCKER render
→ contact sheets
→ visual prosecution
→ targeted patch
→ final render
→ mux
```

## Compilation is not final authorship

The compiler produces safe provisional candidates and a structurally valid
scene pack.

An agent must improve:

- topology;
- motif choice;
- exact node and edge semantics;
- domain mechanisms;
- continuity handoffs;
- transitions;
- narration timing.

The compiler prevents omission. It does not impersonate artistic judgment.
