# Cloudflare Orchestration

The npm package is stateless and serializable, making it suitable for a durable
workflow.

Recommended stages:

```text
genesis
→ source lock
→ argument plan
→ candidate tournament
→ integrator
→ deterministic validation
→ score/TTS
→ external CPU render
→ vision QC
→ human gate
→ final render
```

Store:

- state and scores in D1;
- immutable artifacts in R2;
- workflow step IDs in Workflows;
- render jobs in an external service.

Cloudflare should orchestrate and audit. It should not be assumed to provide the
full Skia/FFmpeg render environment.
