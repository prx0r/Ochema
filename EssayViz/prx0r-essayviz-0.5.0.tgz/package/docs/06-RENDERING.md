# Rendering

## Doctor

```bash
visionary doctor --framework /path/to/MOTHERFUCKER
```

## Compile

```bash
visionary compile project.json --out build/my-film
```

## Render plan

`render-plan.json` contains:

- pack path;
- output paths;
- voice;
- feature manifest;
- renderer command;
- mux command;
- timing;
- signal plan.

## Capability-aware rendering

Use the existing:

```bash
node tools/render-pack.mjs scene-pack.json
```

Do not use the base CLI for packs that need dynamic capability activation.

## Determinism

No network calls, current time, or `Math.random()` during frame rendering.

Analyze audio before rendering.
