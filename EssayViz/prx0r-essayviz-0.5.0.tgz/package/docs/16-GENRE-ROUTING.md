# Genre Routing

## Logical proof

Primary forms:

- proposition nodes;
- semantic edges;
- premise accumulation;
- countermodels;
- scope brackets;
- missing bridges;
- matrices and lattices.

Audio:

- word- or clause-level semantic triggers;
- sparse score;
- small lock/cut SFX;
- narration leads precision.

## Poetry

Primary forms:

- metaphor morphing;
- refrain invariants;
- semantic afterimages;
- typography as material;
- abstract fields;
- nonliteral symbolic objects.

Audio:

- line endings and pauses;
- prosody and spectral movement;
- visual transformation may lead interpretation.

## Explanation

Primary forms:

- exact objects;
- cutaways;
- process arrows;
- before/after states;
- component assembly;
- complementary visual examples.

Audio:

- reveal the object immediately before it is named;
- mechanism SFX remain subordinate.

## Science

Primary forms:

- simulations;
- particles;
- vector fields;
- plots;
- equations;
- perturbation and measurement;
- multiple scales.

Audio:

- score events trigger interventions;
- narration labels causal interpretation;
- waveform features modulate performance only.

## Comparative

Primary forms:

- same evidence, parallel models;
- theory matrices;
- divergent predictions;
- shared interventions;
- candidate tournaments.

## Textual scholarship

Primary forms:

- manuscript folios;
- verse segmentation;
- translation stacks;
- term roots;
- commentary layers;
- citation rails;
- reconstruction labels.

## Investigation

Primary forms:

- evidence classes;
- timelines;
- hypothesis worlds;
- reversals;
- unresolved negative space.

## Tutorial

Primary forms:

- cursor paths;
- exact UI or object states;
- checkpoints;
- error states;
- result verification.
