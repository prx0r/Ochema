# Word-Level Audio Coupling

## Logical proof

Trigger structural changes on semantic words:

```text
if
because
therefore
does not
implies
but
```

Example:

```text
"Therefore" begins the conclusion edge.
"Does not" cuts an invalid implication.
```

## Explanation

Reveal an exact object 100–300 milliseconds before naming it so the viewer can
orient, then animate its function during the causal verb.

## Poetry

Use line endings, pauses, refrains and stress rather than individual nouns.

## Science

Trigger interventions on causal verbs and measurement overlays on quantitative
terms.

## Alignment levels

1. estimated word timing;
2. TTS boundary events;
3. forced alignment;
4. manually approved semantic cues.

Production should prefer levels 2–4.
