# Residual Risks

## Still blocking an unconditional production claim

### No live visual benchmark in this environment

The planner and adapters are tested, but final Skia frames and MP4s were not
rendered against the live repository here.

### Heuristic analysis remains shallow

Use an external analysis provider for important essays.

### Scene realization remains partly agent-authored

The compiler chooses visual modes and generic contracts. It does not yet invent
high-quality bespoke runtime modules without an agent or author.

### MCP production transport is external

The built-in server is for local testing. Use the official SDK for remote or
multi-client deployment.

### No distributed workflow runtime

Retries, state persistence, human approval and render queues belong in
Cloudflare Workflows, Temporal, BullMQ or another durable orchestrator.

### No asset-rights engine

Object/image packs need provenance, license and attribution metadata.

### No visual accessibility layer

Captions, audio description, contrast testing and reduced-motion variants remain
to be formalized.

### No pack dependency solver

Pack requirements are declared but not semantically version-resolved.

### No renderer compatibility matrix

Runtime pack APIs should be pinned against kernel versions and capability
contracts.
