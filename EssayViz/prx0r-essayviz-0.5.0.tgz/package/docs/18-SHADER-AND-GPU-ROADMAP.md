# Shader and GPU Roadmap

## LYGIA adapter

EssayViz stores include manifests and semantic shader graphs. It does not copy
LYGIA source. Target projects resolve functions locally and must review LYGIA's
license.

Recommended function families:

```text
space        coordinate transforms
generative   noise and randomness
sdf          topology and shape fields
draw         analytic marks
filter       blur, edge and reconstruction
distort      semantic deformation
simulate     reaction-diffusion and fluids
color        perceptual color spaces and tonemapping
```

## regl adapter

Compile shader graphs into stateless resources and draw commands.

## Three.js WebGPU adapter

Compile material graphs into TSL nodes and use compute passes for particle and
field simulation.

## Skia adapter

Use CPU/vector paths for typography, proof diagrams, annotation and exact line
quality. Composite GPU textures only when the scene requires continuous fields
or large particle systems.

## Hybrid frame pipeline

```text
Skia notation layer
+ GPU field/material layer
+ object/asset layer
+ typography/citations
→ final frame
```
