# Essay-to-Visual Failure Modes

## Noun matching

```text
mentions consciousness → glowing brain
mentions Tantra → generic lotus
mentions network → node graph
```

Failure: topical relevance without explanatory relevance.

## One house style

Failure: every essay receives the same rhythm, centered object, particles and
climax regardless of argument.

## Schema optimization

Failure: the agent satisfies required fields while the visual remains
interchangeable.

## Audio amplitude everywhere

Failure: all parameters pulse together, destroying attention and causality.

## Literalizing metaphor

Failure: a poem or philosophical metaphor is treated as a scientific object.

## Diagramming poetry

Failure: ambiguity, rhythm and image are reduced to explanatory boxes.

## Abstracting exact explanation

Failure: an essay explaining a lens, cell or ritual object receives generic
fields instead of the exact object.

## Visual overclaim

Failure: analogy, reconstruction or correlation is shown as identity or proof.

## Template lock

Failure: the closest existing scene is relabeled rather than structurally
mutated.

## Render blindness

Failure: planning is accepted without inspecting actual frames and transitions.
