# TTS Providers

## Provider contract

```js
class MyProvider extends TtsProvider {
  id = 'my-provider';

  async synthesize({ text, voice, outputPath, sceneId }) {
    return {
      audioPath: outputPath,
      duration: 12.4,
      alignment: null
    };
  }
}
```

Register it:

```js
registerTtsProvider(new MyProvider());
```

## Included providers

### Edge TTS command provider

Requires the `edge-tts` executable.

### ElevenLabs provider

Uses the timestamp endpoint and can return character-level alignment.

### Generic HTTP provider

Supply:

- endpoint;
- headers;
- request-body builder;
- response parser;
- timeout;
- custom `fetch` for testing.

### Generic command provider

Wrap any local executable such as Piper, Kokoro or a custom Python service.

### Mock provider

Produces deterministic test artifacts and alignment without network access.

## Alignment levels

1. estimated word distribution;
2. provider character/word timestamps;
3. forced alignment from final audio;
4. human-approved semantic cues.

Always align against the final normalized text actually spoken by the provider.
