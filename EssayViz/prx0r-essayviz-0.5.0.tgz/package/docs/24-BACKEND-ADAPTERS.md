# Backend Adapters

EssayViz compiles meaning before renderer choice.

## Skia

Default for exact typography, mathematical notation, vectors, annotations and
stable deterministic films.

## regl + LYGIA

Use for continuous fields, framebuffers, feedback, particles and shader
materials. regl contributes command/resource discipline; LYGIA contributes
granular shader functions.

## Motion Canvas

Use when interactive preview, generator timing and voice-over cue editing are
more important than the existing Skia production path.

## Remotion

Use for parameterized production, web applications, captions, mixed media and
cloud rendering.

## Three.js WebGPU

Use for depth, camera subjectivity, compute simulations and large 3D systems.

## SVG

Use for editable publication diagrams and accessible web graphics.

## PixiJS

Use for image layers, sprites, filters, render textures and 2D compositing.

A film may be hybrid. Example:

```text
regl field texture
→ Skia typography and proof overlay
→ Pixi compositing
→ FFmpeg encode
```
