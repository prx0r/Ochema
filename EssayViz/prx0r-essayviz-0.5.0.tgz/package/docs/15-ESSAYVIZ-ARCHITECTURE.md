# EssayViz Architecture

## The core problem

An agent receives prose. It must decide not only what the prose mentions, but
what the prose is *doing*.

```text
"The brain contains recurrent loops"
```

may function as:

- a definition;
- a premise;
- a mechanism;
- a rival explanation;
- an empirical discriminator;
- an analogy.

The appropriate visual depends on the rhetorical role, not the noun `brain`.

## Five compiler layers

### 1. Ingestion

Parses headings, paragraphs, sentences, equations, references and source order.

### 2. Classification

Estimates genre and rhetorical moves.

### 3. Strategy

Generates several visual modes for each move:

```text
notation
diagram
exact object
continuous field
particles
symbolic geometry
typographic transformation
cinematic/material scene
```

### 4. Compilation

Produces source lock, project, argument IR, continuity, storyboard, typography,
signal, music, SFX, timing, scene pack and review plan.

### 5. Perception loop

Reviews rendered frames and patches failed scenes rather than regenerating the
whole film.

## Genre is a routing prior, not a prison

A logical proof may contain one embodied example. A poem may need one diagram.
A science essay may culminate in symbolic geometry. Genre changes priors and
review criteria; it does not prohibit visual modes.
