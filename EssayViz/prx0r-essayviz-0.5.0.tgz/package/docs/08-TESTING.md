# Testing

## Structural

- project validation;
- duplicate beat detection;
- relation vocabulary;
- registry resolution;
- compilation artifact completeness.

## Semantic

- candidate hard gates;
- invariant preservation;
- forbidden inference;
- rival neutrality;
- discriminator visibility.

## Render

- five fixed frames;
- transition strip;
- deterministic hashes;
- isolated audio buses;
- final MP4 validation.

## Quality

Hash equality catches regressions.

It does not prove beauty.

Use rendered review and a perception critic.
