# What an Agent Can Build

## Crisp logic and mathematical films

Activate:

- precision typography;
- notation objects;
- proof animations;
- semantic cuts;
- sparse layout;
- restrained SFX.

## Neurocognitive films

Activate:

- neurocognition capability;
- technical-neural style;
- propagation animations;
- graph and field objects;
- score or EEG signal routes.

## Anatomy and subtle-body films

Activate:

- human anatomy;
- yogic subtle body;
- continuity objects;
- path particles;
- breath-current motion;
- biological and ritual SFX.

Keep physical anatomy and symbolic subtle anatomy epistemically distinct.

## Tantric deity films

Create packs for:

- deity body plans;
- implements;
- mudrās;
- vāhanas;
- aureoles;
- mantra wheels;
- yantra relations;
- installation and dissolution transitions.

A deity pack should be compositional and iconographic, not a directory of
finished portraits.

## Manuscript films

Create:

- page-layout packs;
- folio texture styles;
- marginalia typography;
- diagram reconstruction objects;
- page-turn and reveal animations;
- citation presentation.

## Music-first films

Use:

- formal music pack;
- score feature bus;
- carrier-transfer transitions;
- particles subordinate to performed audio;
- narration timed around formal density.

## Live-data films

Create a signal pack mapping:

- scientific time series;
- biosignals;
- market/network events;
- sensor input;
- user interaction.

External data may alter states and fields. It should not silently alter the
epistemic status of claims.

## Advanced backend possibilities

The same visual IR can eventually target:

- Skia;
- SVG;
- CanvasKit;
- WebGL;
- WebGPU;
- Three.js;
- Lottie/Skottie;
- Rust/WGPU;
- pre-rendered image and video masks.
