# End-to-End Agent Protocol

## Stage 0 — Source integrity

Read the entire source and store a checksum. Do not plan from a summary alone.

## Stage 1 — Ingest

```bash
essayviz ingest essay.md --out build/essay-ingest
```

Inspect:

- heading structure;
- equations;
- references;
- genre confidence;
- rhetorical move classification.

Correct classification errors before visual planning.

## Stage 2 — Build the source lock

Separate:

- secure claims;
- hypotheses;
- analogies;
- rivals;
- non-claims;
- unresolved frontier.

## Stage 3 — Build beats

Each beat is:

```text
incoming belief
→ operation
→ outgoing belief
```

## Stage 4 — Generate all visual modes

For decisive beats generate:

- notation;
- diagram;
- exact object;
- field;
- particles;
- symbolic geometry;
- typographic transformation;
- cinematic/material scene.

## Stage 5 — Ground objects

An exact object visual requires a capability object or source asset. If none is
available, create an object pack or choose another mode. Never invent precise
anatomy, machinery or iconography from a vague label.

## Stage 6 — Tournament

Reject candidates with:

- weak semantic fit;
- no decisive mutation;
- ungrounded object claims;
- hidden epistemic overclaim;
- high render risk without explanatory gain.

## Stage 7 — Continuity

Define at least one continuity system. State conserved, transformable and
forbidden properties.

## Stage 8 — Audio contract

Choose word, phrase, line, score-event or performance coupling. Author semantic
cue points; do not use amplitude as a substitute for meaning.

## Stage 9 — Compile

```bash
essayviz plan-essay essay.md --out build/my-film
```

## Stage 10 — Author renderer-specific programs

Replace provisional motifs with exact scene programs and capability runtime
calls.

## Stage 11 — Render review

Render five frames and transition strips. Test silent, narration-only,
music-only and integrated versions.

## Stage 12 — Patch

Patch failed beats only. Record observations and accepted changes.
