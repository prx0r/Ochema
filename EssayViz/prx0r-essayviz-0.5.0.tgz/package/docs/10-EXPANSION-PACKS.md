# Expansion Pack System

The framework now recognizes twelve extension types.

| Pack | Responsibility |
|---|---|
| Capability | Domain mechanisms and assets |
| Composition | Sequence grammar |
| Style | Palette, materials, density and global restrictions |
| Motion | Reusable transformation behavior |
| Signal | Audio, score, narration and external-data routing |
| Typography | Font roles, hierarchy and notation behavior |
| Visual object | Reusable semantic objects with conservation laws |
| Animation | Random-access animation algorithms |
| Transition | Semantic laws connecting scene states |
| Music | Musical forms and inspectable feature buses |
| Sound effect | Semantic and material cue families |
| Layout | Safe areas, grids and editorial framing |
| Backend | Renderer adapters |

## Create one

```bash
visionary scaffold-pack my-animation \
  --type animation \
  --out packs
```

Then edit:

```text
packs/my-animation/
├── pack.json
├── runtime.mjs
└── README.md
```

Load and test it:

```bash
visionary load-pack packs/my-animation/pack.json
```

## Composition

A production may activate several independent layers:

```json
{
  "capabilities": ["neurocognition", "pathkit-geometry"],
  "styleProfile": "technical-neural",
  "typographyProfile": "mathematical-white",
  "motionPacks": ["advanced-animation"],
  "objectPacks": ["continuity-objects"],
  "transitionPacks": ["semantic-transitions"],
  "musicPack": "music-forms",
  "soundEffectPack": "cinematic-sfx",
  "layoutPack": "editorial-layouts"
}
```
