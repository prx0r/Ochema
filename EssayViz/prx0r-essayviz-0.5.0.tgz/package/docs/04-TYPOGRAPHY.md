# Typography

## Default families

- Source Serif 4: prose, IAST and mixed philosophical text;
- KaTeX Math: pure equations and variables;
- Noto Serif Devanagari: Devanagari;
- EB Garamond: optional manuscript presentation.

## Hierarchy

At 1280×720:

- title: 26–34 px;
- central equation: 28–40 px;
- body: 16–21 px;
- annotation: 13–16 px;
- citation: 12–14 px.

## Rules

- equations receive negative space;
- prose does not cross dense geometry;
- labels stay outside high-degree nodes;
- italics are semantic, not decorative;
- line weight remains visible after video compression;
- typography never depends on glow.
