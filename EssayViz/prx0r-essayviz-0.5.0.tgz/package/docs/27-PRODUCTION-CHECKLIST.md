# Production Checklist

## Source

- input policy configured;
- source lock approved;
- source instruction risks reviewed;
- citations and line provenance preserved;
- genre either high-confidence or explicitly supplied;
- non-English analysis provider selected when needed.

## Planning

- every beat has an operation, invariant and forbidden inference;
- candidate tournament reviewed;
- object grounding includes provenance and rights;
- continuity systems are authored, not placeholders;
- source-move compiled coverage is 100%.

## Audio

- provider health check passes;
- pronunciation lexicon tested;
- exact generated audio measured;
- timestamps use final normalized text;
- retries and rate limits configured;
- narration, score and SFX roles remain separate.

## Rendering

- fonts verified;
- renderer version and capability packs pinned;
- deterministic seed recorded;
- subprocess timeout and cancellation configured;
- review frames generated;
- transition strips generated;
- final mux duration verified.

## Agent execution

- skills pinned by version;
- MCP roots restricted;
- destructive tools require approval;
- pack runtimes disabled unless trusted;
- tool output sizes bounded;
- logs and artifact IDs persisted;
- human release gate enabled.

## Security

- remote MCP uses authentication;
- secrets remain out of prompts and logs;
- pack assets scanned and licensed;
- runtime packs isolated when possible;
- source prompt injection treated as data;
- artifact paths canonicalized.
