# Customizable Stable Attractors

Attractors should be semantic tools.

## Stable node

Use for convergence, regulation and focus.

## Spiral

Use for tension resolving through repeated approach.

## Double well

Use for rival explanations, bistability and threshold decisions.

## Limit cycle

Use for self-maintaining organisms, breath, recurrent cognition and ritual
cycles.

## Lorenz system

Use only when sensitivity, unstable predictability or chaotic structure is the
actual concept. Do not use chaos as decorative complexity.

## Controls

```text
system
parameters
dt
integrator
seed
bounds
initial conditions
noise
```

Review trajectories numerically and visually. Stable attractors should not
explode under production time steps.
