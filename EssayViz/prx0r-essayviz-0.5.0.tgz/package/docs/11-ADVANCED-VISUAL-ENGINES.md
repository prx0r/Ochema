# Advanced Visual Engines

## Timeline engine

Provides deterministic random access over authored events.

Use for:

- motif entries;
- argument state changes;
- score boundaries;
- transition checkpoints.

## Animation engine

Interpolates numbers, vectors and objects with analytic easing.

Use for:

- notation movement;
- path parameters;
- camera framing;
- material properties.

## Visual-object engine

Instantiates reusable objects with semantic contracts:

```text
meaning
conserved features
transformable features
forbidden transformations
```

This is the basis for:

- continuity seeds;
- apertures;
- causal traces;
- deity implements;
- anatomical landmarks;
- notation objects.

## Transition engine

Transitions are semantic verbs, not packaging:

```text
fold
split
transfer
remember
condense
dissolve
entrain
unbind
invert
compare
withhold
germinate
fracture
repair
```

## Signal engine

Uses frame-rate-independent exponential smoothing.

Use it to map:

```text
onset → subordinate emission
RMS → glow pressure
harmonic energy → trace persistence
speech density → information suppression
```

Do not route signals to logical truth values.

## Stateful animation

Some effects require history:

- particles;
- reaction diffusion;
- hysteresis;
- persistent trails.

Support them through checkpoints. Render from the nearest checkpoint when
seeking to an arbitrary frame.
