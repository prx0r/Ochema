# Agent Runtime: Skills, MCP and Providers

## Skills

Skills are versioned instruction files.

They tell an agent:

- how to read an essay;
- how to preserve source status;
- how to generate candidates;
- how to review rendered frames;
- when to stop or ask for human approval.

Skills cannot themselves read files, render videos, call TTS or save artifacts.

## MCP tools

MCP exposes executable operations:

- plan an essay;
- validate a project;
- scaffold a pack;
- inspect the renderer;
- create artifacts;
- submit or inspect render jobs.

Use stdio for a local coding agent. Use Streamable HTTP with authentication for a
remote service.

The built-in `essayviz mcp` server is a local protocol test harness. For a
production deployment, wrap `createEssayVizTools()` with the official MCP SDK so
that schemas, lifecycle, logging, progress and transport behavior are handled by
the maintained implementation.

## Providers

Providers isolate services that vary by deployment:

```text
analysis provider
TTS provider
alignment provider
music provider
SFX provider
renderer backend
artifact store
perception critic
```

An agent should never need to edit the compiler to replace ElevenLabs with Edge
TTS, or Skia with Motion Canvas.

## Recommended operating model

```text
Source Analyst skill
+ external analysis provider or human source lock

Visual Strategist skill
+ EssayViz planning tools

Visual Realizer skill
+ pack registry and renderer tools

Audio Director skill
+ TTS/music/SFX providers

Perception Critic skill
+ rendered contact sheets and vision model

Director skill
+ approval gates and patch acceptance
```

## Why both are necessary

```text
skills without tools
= good advice with no execution

tools without skills
= powerful operations with poor judgment

skills + bounded tools + review gates
= usable agent system
```
