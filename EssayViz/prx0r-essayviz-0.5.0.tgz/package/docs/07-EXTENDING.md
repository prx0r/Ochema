# Extending

## Add a registry entry

```js
import { styleRegistry } from "@prx0r/visionary-engine/registries";

styleRegistry.register("my-style", {
  theme: "whiteScientific",
  material: "etched-metal",
  density: "sparse"
});
```

## Add a planner

A planner accepts typed artifacts and returns a serializable artifact.

It must not render.

## Add a backend

Implement:

```js
inspect(root)
render(renderPlan, options)
```

## Add a renderer capability

Keep implementation in the existing capability pack/runtime-module system.

Add metadata to the authoring registry so agents can discover it.
