# Agent Expansion Workflow

## Step 1 — Identify the missing capability

Do not create a pack because a visual is attractive.

Create it because multiple films need the same:

- domain object;
- transformation;
- material process;
- layout;
- musical form;
- signal route.

## Step 2 — Choose the pack type

Ask which responsibility is being added.

A lotus is a visual object or capability.

Unfolding is an animation.

Germination is a transition.

Gold leaf is a style/material.

Passacaglia is a music pack.

A bell cue is a sound-effect pack.

## Step 3 — Write semantic contracts

For objects:

```text
meaning
conserved
transformable
forbidden
```

For animation:

```text
verb
input state
output state
time behavior
random-access policy
```

For sound:

```text
semantic role
trigger
family
gain
narration ducking
```

## Step 4 — Scaffold

```bash
visionary scaffold-pack my-pack --type visual-object --out packs
```

## Step 5 — Validate and load

```bash
visionary load-pack packs/my-pack/pack.json
```

## Step 6 — Add tests

Test:

- deterministic output;
- pack loading;
- parameter bounds;
- random access;
- semantic metadata;
- incompatibilities.

## Step 7 — Render a laboratory

Do not first test inside a twenty-minute film.

Build a short pack showing:

- minimum parameters;
- maximum parameters;
- transitions;
- audio response;
- mixed-pack composition.
