# Visual Modes

## Notation

Use when the exact inference is primary.

## Diagram

Use when relation topology is primary.

## Exact object

Use when an explanation names a real component whose structure matters.

## Field

Use when causality is distributed, continuous or constraint-based.

## Particles

Use when many local agents or packets enact flow, diffusion, accumulation or
selection.

## Symbolic geometry

Use when a culturally or mathematically constructed form carries relations that
cannot be reduced to a stock icon.

## Typographic transformation

Use when wording, ambiguity, translation, refrain or conceptual substitution is
the content.

## Cinematic/material scene

Use when spatial subjectivity, atmosphere, historical place or scale is
necessary. It carries the highest production risk and should not be the default.
