# EssayViz Framework Comparison

Research date: 2026-07-29.

## What existing frameworks solve

| Framework | Primary strength | Lesson for EssayViz | What it does not solve |
|---|---|---|---|
| LYGIA | Granular, cross-language shader functions organized by math, space, color, animation, generative, SDF, draw, filter, distortion, lighting, geometry and simulation categories | Keep GPU operations tiny, composable, portable and discoverable through semantic manifests | It does not read an essay or decide which shader operation expresses an argument |
| regl | WebGL expressed through resources and complete draw commands with minimal shared state | Backend adapters should compile declarative visual commands rather than mutate global GPU state | It does not provide rhetorical planning or editorial sequencing |
| Motion Canvas | Generator-based vector animation, preview tooling, signals, layouts, time events and voice-over synchronization | Scene timing should be authored around semantic events and inspectable in an editor | It does not choose visual form from source meaning |
| Hydra | Chained source, transform, composite and output operations; multiple framebuffers and feedback | Signal graphs and visual operations should be composable and live-previewable | Its syntax is optimized for visual synthesis, not source-grounded explanation |
| Remotion | Parameterized React video, reusable components, captions, audio and server rendering | EssayViz projects should compile into parameterized backend programs and agent-friendly skills | It leaves rhetorical decomposition and visual-semantic selection to the author |
| Three.js WebGPU/TSL | Node-based materials, WebGPU compute and WebGL fallback | A shader graph IR can target modern GPU backends without embedding raw shader strings everywhere | It is a rendering layer, not an essay compiler |
| PixiJS | Display tree, render textures, stacked filters and blend modes | Offscreen layers and ordered effect graphs should be first-class | It does not create evidence-sensitive explanatory plans |
| p5.js WebGL | Accessible shader hooks and GLSL integration | Prototypes should have low-friction hooks before becoming formal packs | It does not enforce deterministic production or epistemic contracts |
| ELK/elkjs | Layered, radial, force, stress and compound graph layout | Diagram topology should be separated from layout and delegated to specialized algorithms | Layout cannot decide what graph the essay needs |
| KaTeX | Fast deterministic math typesetting and server-side rendering | Equations should be pre-renderable, measurable and independent of prose layout | It does not animate mathematical argument structure |
| Tone.js | Transport, sample-accurate scheduling, synths, effects and audio-rate signals | Formal score events and audio performance should use a real event clock | It does not decide which musical form is homologous to an argument |
| canvas-sketch | Small generative-art workflow and reusable sketch settings | Prototypes benefit from simple deterministic runners and export conventions | It does not solve multi-scene rhetorical continuity |
| Paper.js / PathKit | Rich vector paths, Boolean operations and curve geometry | Geometry engines should expose topology-preserving path operations | They do not perform semantic scene selection |

## EssayViz's distinct responsibility

```text
source meaning
→ genre and rhetorical analysis
→ argument-event chain
→ object grounding
→ candidate visual systems
→ semantic tournament
→ continuity and composition
→ audio/word coupling
→ renderer-neutral visual IR
→ backend execution
→ perception review
```

The missing industry layer is not another canvas API. It is a compiler from
rhetorical operations to visual operations.

## Sources

- LYGIA: https://github.com/patriciogonzalezvivo/lygia
- regl: https://regl-project.github.io/regl/
- Motion Canvas: https://motioncanvas.io/docs/
- Hydra Synth: https://github.com/hydra-synth/hydra
- Remotion: https://www.remotion.dev/docs
- Three.js WebGPU: https://threejs.org/manual/en/webgpurenderer
- PixiJS filters: https://pixijs.com/8.x/guides/components/filters
- p5.js shaders: https://p5js.org/reference/p5/p5.Shader/
- ELKJS: https://github.com/kieler/elkjs
- KaTeX API: https://katex.org/docs/api
- Tone.js: https://tonejs.github.io/
- canvas-sketch: https://github.com/mattdesl/canvas-sketch
- Paper.js: https://paperjs.org/reference/
