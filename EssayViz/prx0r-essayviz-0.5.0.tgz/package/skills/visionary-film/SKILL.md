---
name: visionary-film
description: Compile a philosophical or scientific essay into a deterministic audiovisual program using typed IR, candidate tournaments, capability packs and rendered review.
version: 1.0
---

# Visionary Film Skill

## Prime directive

Make the viewer undergo the argument.

Do not convert nouns into stock images.

## Required order

1. Read the complete source.
2. Create `source-lock.json`.
3. Create `project.json` with argument beats and no selected visuals.
4. Run `visionary validate project.json`.
5. Compile the planning bundle.
6. Inspect `candidate-tournament.json`.
7. Replace provisional candidates with authored visual programs.
8. Resolve capability, composition, style, motion, signal and typography profiles.
9. Generate TTS or obtain final audio.
10. Align scene durations to measured audio.
11. Render five review frames and transition strips.
12. Repair failed semantic operations.
13. Render final video and mux audio.

## Source lock

Record:

- exact contention;
- secure conclusions;
- non-claims;
- strongest rivals;
- discriminators;
- evidence labels;
- surviving frontier;
- sources.

## Argument beat contract

Every beat needs:

```json
{
  "incomingBelief": "",
  "operation": "",
  "outgoingBelief": "",
  "relation": "",
  "invariant": "",
  "forbiddenInference": ""
}
```

## Candidate requirement

Generate five structural candidates:

- notation;
- graph or topology;
- field or dynamics;
- embodied or domain-specific;
- unconventional.

A candidate must differ causally, not only stylistically.

## Selection hard gates

- relation fidelity ≥ 4/5;
- motion performs claim ≥ 4/5;
- epistemic restraint ≥ 4/5;
- silent legibility ≥ 3/5.

## Profile separation

Capability answers what can be shown.

Composition answers why scenes are ordered.

Style answers how the film feels.

Motion answers how transformation behaves.

Signal routing answers what external data modulates.

Typography answers how language and notation are presented.

Do not put all responsibilities into a theme.

## Audio protocol

Use score events for formal causality.

Use waveform features for performed energy and timbre.

Use narration for attention allocation and semantic triggers.

Never allow amplitude to create or remove a logical implication.

## Review protocol

For every scene render:

```text
0.00
0.25
0.55
0.82
1.00
```

Test:

- silent relation;
- frame ordering;
- invariant survival;
- forbidden inference;
- typography;
- signal isolation;
- transition causality.

## Output

- source lock;
- project;
- compiled planning bundle;
- authored scene pack;
- narration;
- feature manifests;
- review artifacts;
- revision record;
- final MP4;
- SHA-256 manifest.
