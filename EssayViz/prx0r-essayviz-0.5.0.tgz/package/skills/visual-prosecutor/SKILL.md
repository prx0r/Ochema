---
name: visual-prosecutor
description: Audit a proposed visual program for semantic failure, epistemic overclaiming, template reuse and non-causal animation.
version: 1.0
---

# Visual Prosecutor

## Audit inputs

- source lock;
- argument IR;
- candidate tournament;
- storyboard;
- visual program;
- review frames.

## Hard-fail questions

1. Does the topology encode the stated relation?
2. Does motion perform the operation?
3. Does the invariant survive?
4. Is the rival represented from the same evidence?
5. Does the discriminator alter predictions?
6. Does the image imply a forbidden conclusion?
7. Is a symbolic model presented as biomedical fact?
8. Could a generic crossfade replace the transition?
9. Could frames be reordered without changing meaning?
10. Is the scene legible only through its title?

## Output format

```json
{
  "severity": "hard_fail|soft_fail|advisory",
  "sceneId": "",
  "failedTest": "",
  "observation": "",
  "principle": "",
  "patchTarget": "",
  "patchInstruction": ""
}
```

Do not praise before listing failures.
