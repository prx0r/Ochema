---
name: audiovisual-sync
description: Plan and verify score-event, waveform and narration synchronization for deterministic rendering.
version: 1.0
---

# Audiovisual Sync

## Choose the mode

### Waveform-first

Final audio exists before visuals.

```text
audio
→ feature analysis
→ visual render
→ mux
```

### Score-first

Formal event data exists before synthesis.

```text
score events
→ visual render
→ audio synthesis
→ mux
```

### Hybrid

Recommended:

```text
score events = formal causality
waveform = performed energy
narration = attention and semantics
```

## Required manifests

### Score

- formal boundaries;
- motif entries;
- carrier transfers;
- voice count;
- tension;
- subject presence.

### Music waveform

- RMS;
- onset;
- beat pulse;
- harmonic/percussive energy;
- spectral centroid;
- chroma when meaningful.

### Narration

- speech active;
- speech density;
- sentence progress;
- emphasis;
- semantic event;
- attention request.

## Sync checks

- measured audio duration equals scene duration;
- no return event occurs in a silence window;
- narration does not compete with maximum visual density;
- signal smoothing is frame-rate independent;
- random access uses feature manifests, not live analysis;
- final mux uses `-shortest` only after durations are verified.
