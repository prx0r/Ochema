---
name: visionary-pack-author
description: Add capability, composition, style, motion, signal or presentation packs without modifying the rendering kernel.
version: 1.0
---

# Pack Author

## Capability pack

Must declare:

- id and version;
- inheritance;
- runtime module;
- assets;
- mechanisms;
- relations;
- operators;
- semantic tags;
- motion proofs;
- epistemic modes;
- parameters.

## Composition profile

Must declare:

- stages;
- transition policy;
- recognition policy;
- allowed variants;
- anti-mannerism notes.

## Style profile

Must declare:

- theme;
- palette;
- line weights;
- material defaults;
- typography;
- density;
- forbidden effects.

## Motion profile

Must declare:

- causal verbs;
- time constants;
- continuity policy;
- random-access policy.

## Signal profile

Must declare:

- buses;
- routes;
- attack/release;
- semantic limits;
- forbidden controls.

## Kernel rule

Prefer registries and adapters.

Modify the kernel only when the new feature cannot be represented through the
visual IR or renderer environment.
