---
name: essayviz-science
description: scientific visual argument.
version: 1.0
---

# EssayViz Science

Separate data, model, simulation and interpretation. Use perturbation, measurement, fields, particles and plots only when they perform the scientific claim.

## Required process

1. Run `essayviz ingest`.
2. Inspect genre confidence and rhetorical moves.
3. Correct misclassified beats before visuals.
4. Generate all eight visual modes for decisive beats.
5. Select by semantic fit, silent legibility and epistemic restraint.
6. Author exact nodes, objects, fields or transformations.
7. Build semantic audio cues.
8. Render five frames and transition strips.
9. Patch failed beats only.
