---
name: essayviz-textual-scholarship
description: text-grounded scholarly film.
version: 1.0
---

# EssayViz Textual Scholarship

Preserve source hierarchy, citation status, translation alternatives, reconstruction labels and textual limits.

## Required process

1. Run `essayviz ingest`.
2. Inspect genre confidence and rhetorical moves.
3. Correct misclassified beats before visuals.
4. Generate all eight visual modes for decisive beats.
5. Select by semantic fit, silent legibility and epistemic restraint.
6. Author exact nodes, objects, fields or transformations.
7. Build semantic audio cues.
8. Render five frames and transition strips.
9. Patch failed beats only.
