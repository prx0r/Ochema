# Production Readiness

## Status

```text
Planning/compiler core: hardened beta
Local agent tooling: hardened beta
TTS provider layer: beta
Pack security defaults: production-oriented
MCP test harness: development only
Remote MCP deployment: adapter required
Live render quality: not certified in this environment
Distributed production service: not included
```

EssayViz should currently be deployed as a controlled internal authoring system
with human approval, not as an unattended public service.
