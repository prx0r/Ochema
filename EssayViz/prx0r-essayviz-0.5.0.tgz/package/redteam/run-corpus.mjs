import { readdir, writeFile, mkdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { compileEssay } from '../src/compiler/essay-compiler.mjs';
import { ingestEssay } from '../src/ingest/essay-ingestor.mjs';

const examplesDir=resolve('examples/genres');
const hostileDir=resolve('test/fixtures/redteam');
const rows=[];
for(const name of await readdir(examplesDir)){
  if(!name.endsWith('.md'))continue;
  const path=join(examplesDir,name);const before=process.memoryUsage().rss;const start=performance.now();
  try{const result=await compileEssay(path,{maxBeats:14});rows.push({suite:'genre',name,status:'compiled',genre:result.ingestion.classification.genre,confidence:result.ingestion.classification.confidence,beats:result.project.beats.length,coverage:result.coverage.compiledCoverage,elapsedMs:Math.round(performance.now()-start),rssDeltaBytes:process.memoryUsage().rss-before,warnings:result.ingestion.warnings});}
  catch(error){rows.push({suite:'genre',name,status:'error',error:error.code??error.message,elapsedMs:Math.round(performance.now()-start)});}
}
for(const name of await readdir(hostileDir)){
  if(!name.endsWith('.md'))continue;
  const path=join(hostileDir,name);const start=performance.now();
  try{const result=await ingestEssay(path);rows.push({suite:'hostile',name,status:result.classification.abstained?'abstained':'classified',genre:result.classification.genre,confidence:result.classification.confidence,sourceRisks:result.sourceRisks.length,warnings:result.warnings,elapsedMs:Math.round(performance.now()-start)});}
  catch(error){rows.push({suite:'hostile',name,status:'error',error:error.code??error.message,elapsedMs:Math.round(performance.now()-start)});}
}
const report={version:'1.0',generatedAt:new Date().toISOString(),summary:{total:rows.length,genreCompiled:rows.filter(r=>r.suite==='genre'&&r.status==='compiled').length,hostileAbstained:rows.filter(r=>r.suite==='hostile'&&r.status==='abstained').length,errors:rows.filter(r=>r.status==='error').length},rows};
await mkdir('build/redteam',{recursive:true});await writeFile('build/redteam/corpus-report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report.summary));
