# Laya Yoga Subtle Body Pack

Included files:
- laya_yoga_subtle_body_animation.mp4
- contact_sheet.jpg
- scene_manifest.json
- scene_catalog.json
- AGENT_KNOWLEDGE_DOSSIER.md
- README.md

Specs:
- Resolution: 1280x720
- FPS: 12
- Scene count: 18
- Duration per scene: 4.0s
- Total runtime: 1.2 minutes
