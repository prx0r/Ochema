# AGENT KNOWLEDGE DOSSIER — Laya Yoga Subtle Body Pack

## Intent
This pack is built for content around Laya Yoga, nāḍīs, prāṇa, mantra, suṣumnā, granthis, chakra-lotuses, subtle physiology, and the contemplative use of the human body.

## What changed from the previous batch
The user asked for:
- more creativity
- less dependence on a single line
- more intuitive explanation of the meditation
- more time for forms to resolve

This pack therefore uses:
- whole-body diagrams instead of isolated abstract lines
- multiple simultaneous layers (body contour, channel, lotus, field, particles, knot, flame)
- longer 4-second scenes with a clear start-middle-resolution arc
- more visually intuitive metaphors for what the practice is doing

## Style Rules
- White / warm-white background
- Black structural lines
- Crimson as energetic accent
- Geometry should feel contemplative and anatomical-symbolic, not medical
- Human body is stylized, not naturalistic
- Motion should make the practice legible even without explanatory labels

## Core semantic families
1. **Body map** — subtle body, axis, channel system
2. **Dual currents** — ida/pingala, sun/moon, reciprocity
3. **Central ascent** — suṣumnā, rising thread, kundalini
4. **Energetic redistribution** — prāṇa tides, five winds, nectar descent
5. **Sound structures** — mantra in the spine, nāda, ajapa japa
6. **Integration / dissolution** — laya into space, integrated subtle body

## How to reuse scenes
Choose scenes by semantic function:
- Explanation of the subtle body: `ly01`, `ly02`, `ly03`
- Breath and prāṇa dynamics: `ly04`, `ly10`, `ly14`
- Chakra-centered practice: `ly05`, `ly06`, `ly12`, `ly16`
- Knot / purification language: `ly07`
- Mantra and sonic practice: `ly08`, `ly09`, `ly15`
- Cooling / descending / integration themes: `ly11`, `ly13`, `ly17`, `ly18`

## Knowledge assumptions
This is a cross-tradition subtle-body pack and should be narrated carefully:
- Nāḍīs are not rendered as modern nerves or literal anatomy.
- Prāṇa is shown as a subtle process, not a measurable fluid.
- Kuṇḍalinī is portrayed as latent upward potential, not sensational spectacle.
- Mantra is treated as an organizing sonic pattern within consciousness and the body.
- The subtle body is a contemplative map, not a biological chart.

## Renderer transfer
These scene specs can be rendered in a sleeker backend without changing semantics.
Backends that can replace the current simple renderer:
- Skia / Canvas2D for cleaner typography and layered vectors
- Motion Canvas for higher polish and keyframed easing
- Three.js / WebGL / shaders for luminous fields and flowing particles
- SVG or Rive for reusable lotus / channel / knot components

The invariant is the **scene meaning**, not the current drawing implementation.
