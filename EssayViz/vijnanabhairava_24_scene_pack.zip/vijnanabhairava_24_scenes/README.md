# Vijñānabhairava 24 Selected Scenes

Files included:
- vijnanabhairava_24_scenes_animation.mp4
- contact_sheet.jpg
- scene_manifest.json
- scene_catalog.json
- AGENT_KNOWLEDGE_DOSSIER.md
- README.md

Render specs:
- Resolution: 1280x720
- FPS: 12
- Scenes: 24
- Duration per scene: 3.0s
- Total runtime: 1.2 min
