# AGENT KNOWLEDGE DOSSIER — Vijñānabhairava 24-Scene Pack

## Purpose
This pack converts 24 selected contemplative motifs from the Vijñānabhairava into reusable minimal motion scenes.
Each scene is a semantic animation unit, not just a one-off illustration.

## Design Language
- Warm white background
- Black ink primary geometry
- Single crimson accent for emphasis / bindu / axis / turning point
- No decorative clutter
- Motion should reveal the teaching rather than label it
- Use subtitles sparingly; let the geometry carry the concept

## Structural Principle
The 24 scenes are grouped into four families:
1. Breath and the middle
2. Sound and mantra
3. Space, light, and the body
4. Mind, affect, interruption, and resolution

## How another agent should reuse these scenes
- Treat each scene as a reusable visual process.
- Swap narration, captions, and Sanskrit terms while preserving the motion logic.
- Reuse by semantic match, not by keyword match alone.

### Example reuse mappings
- `The Two Currents` -> breath, dual currents, polarity, Śiva/Śakti complementarity.
- `The Middle Channel` -> suṣumnā, ascent, axis mundi, still center.
- `The Fading Bell` -> mantra, nāda, resonance, dissolution.
- `Space Inside Space` -> void, ākāśa, recursive awareness, inner/outer collapse.
- `The End of One Thought` -> gap awareness, nonconceptual pause, recognition.
- `Threshold of Sleep` -> dream transition, hypnagogia, avasthā analysis.
- `Everything Is Bhairava` -> culmination, totality, synthesis, nondual resolution.

## Renderer Extension Advice
A sleeker engine can render the same scene spec without changing semantics.
Possible backends:
- Skia / Canvas2D for production video
- Motion Canvas / Three.js for interactive or higher polish
- GLSL shader backends for wavefields, diffraction, and phase transitions

The important invariant is the **semantic scene spec**:
- scene id
- mode / operator family
- title and contemplative summary
- duration
- reusable concept tags

## Scene tags
- Breath: vb02 vb03 vb04 vb05 vb06
- Sound/mantra: vb07 vb08 vb09 vb10 vb11 vb12
- Space/light: vb13 vb14 vb15 vb16 vb17 vb18
- Mind/affect: vb19 vb20 vb21 vb22 vb23 vb24
