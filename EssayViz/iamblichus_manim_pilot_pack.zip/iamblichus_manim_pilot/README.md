# Iamblichus — Manim Pilot

This pack contains **genuine Manim Community source code** for seven Iamblichus/theurgy scenes.

The current runtime did not include Manim and could not reach package repositories, so the included `fallback_animatic.mp4` is an independently rendered planning preview—not a Manim render. The `.py` source is the actual Manim implementation.

## Render locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install manim==0.19.2
bash render_all.sh
```

The script renders the seven classes and concatenates them into `iamblichus_manim_pilot.mp4`.

## Why this experiment matters

Manim lets the visual language move beyond frame-by-frame drawing through:

- semantic object transforms;
- path morphing;
- `LaggedStart` choreography;
- `ReplacementTransform` between symbolic roles;
- camera reframing;
- `MoveAlongPath` for anagogic ascent;
- whole-composition transformations.

That makes it particularly useful for relationships such as procession, purification, recomposition, mediation, and ascent.
