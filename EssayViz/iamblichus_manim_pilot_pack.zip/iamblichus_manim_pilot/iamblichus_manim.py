from manim import *
import numpy as np

config.background_color = "#F5EFE3"
config.pixel_width = 1280
config.pixel_height = 720
config.frame_rate = 30
IVORY = "#F5EFE3"
INK = "#241B19"
CRIMSON = "#812431"
GOLD = "#B28A38"
LAPIS = "#31547D"
PALE = "#D9CDBA"
GREY = "#77706B"


def sacred_title(number: str, title: str, subtitle: str):
    n = Text(number, font_size=22, color=GREY)
    t = Text(title, font_size=34, color=INK)
    s = Text(subtitle, font_size=20, color=CRIMSON)
    g = VGroup(n, t, s).arrange(DOWN, aligned_edge=LEFT, buff=0.06)
    g.to_corner(UL).shift(RIGHT * 0.25 + DOWN * 0.15)
    return g


def radiant_disc(radius=0.16):
    core = Dot(radius=radius, color=CRIMSON)
    rays = VGroup(*[
        Line(radius * 1.6 * RIGHT, radius * 3.6 * RIGHT, color=GOLD, stroke_width=1.5)
        .rotate(k * TAU / 12)
        for k in range(12)
    ])
    rings = VGroup(*[
        Circle(radius=r, color=PALE, stroke_width=1.2, stroke_opacity=0.65)
        for r in (0.35, 0.55, 0.78)
    ])
    return VGroup(rings, rays, core)


def temple_arch(width=3.4, height=3.7):
    left = Line([-width/2, -height/2, 0], [-width/2, height*0.05, 0], color=INK, stroke_width=3)
    right = left.copy().shift(RIGHT * width)
    arch = ArcBetweenPoints(left.get_end(), right.get_end(), angle=-PI, color=INK, stroke_width=3)
    base = Line(left.get_start(), right.get_start(), color=INK, stroke_width=3)
    return VGroup(left, right, arch, base)


def altar():
    top = Rectangle(width=3.0, height=0.42, color=INK, stroke_width=3)
    middle = Rectangle(width=2.25, height=0.55, color=INK, stroke_width=2).next_to(top, DOWN, buff=0)
    base = Rectangle(width=1.45, height=0.62, color=INK, stroke_width=2).next_to(middle, DOWN, buff=0)
    return VGroup(top, middle, base)


def sigils():
    square = Square(0.42, color=INK).add(Line(LEFT*0.12, RIGHT*0.12, color=CRIMSON))
    triangle = Triangle(color=INK).scale(0.27)
    star = Star(n=8, outer_radius=0.30, inner_radius=0.12, color=GOLD)
    circle = Circle(0.22, color=INK).add(Dot(radius=0.045, color=CRIMSON))
    diamond = Square(0.34, color=INK).rotate(PI/4)
    return VGroup(square, triangle, star, circle, diamond)


def vessel():
    body = Polygon(
        [-0.70, -1.15, 0], [-0.58, 0.35, 0], [-0.28, 0.95, 0],
        [0.28, 0.95, 0], [0.58, 0.35, 0], [0.70, -1.15, 0],
        [0.38, -1.62, 0], [-0.38, -1.62, 0],
        color=INK, stroke_width=3
    )
    lip = Arc(radius=0.36, start_angle=0, angle=PI, color=INK, stroke_width=3).shift(UP*0.97)
    return VGroup(body, lip)


class SacredScene(MovingCameraScene):
    def reset_camera(self):
        self.camera.frame.animate.set(width=14).move_to(ORIGIN)

    def clear_with_hold(self, hold=0.35):
        self.wait(hold)
        self.play(FadeOut(VGroup(*self.mobjects)), run_time=0.8)
        self.camera.frame.set(width=14).move_to(ORIGIN)


class ThresholdBeyondDiscourse(SacredScene):
    def construct(self):
        title = sacred_title("01", "The Threshold Beyond Discourse", "philosophy reaches an opening it cannot contain")
        tablet = RoundedRectangle(width=4.2, height=4.1, corner_radius=0.08, color=INK, stroke_width=2).shift(LEFT*3.0 + DOWN*0.25)
        lines = VGroup(*[
            Line(LEFT*1.55, RIGHT*1.45, color=INK if i < 3 else GREY, stroke_width=2 if i < 3 else 1.3)
            .shift(LEFT*3.0 + UP*(1.25-i*0.36))
            for i in range(7)
        ])
        door = temple_arch(3.0, 4.2).shift(RIGHT*2.8 + DOWN*0.2)
        source = radiant_disc(0.12).move_to(RIGHT*2.8 + UP*2.2)
        beams = VGroup(*[
            Line(source.get_center(), RIGHT*(2.0 + k*0.16) + UP*(0.55-k*0.12), color=GOLD, stroke_opacity=0.35)
            for k in range(10)
        ])
        chamber = Rectangle(width=2.55, height=2.8, color=PALE, stroke_width=1).move_to(RIGHT*2.8 + DOWN*0.65)
        caption = Text("beyond logos", font_size=22, color=CRIMSON).move_to(RIGHT*2.8 + DOWN*2.0)

        self.add(title)
        self.play(Create(tablet), LaggedStart(*[Create(x) for x in lines], lag_ratio=0.08), run_time=1.7)
        self.play(Create(door), Create(chamber), run_time=1.5)
        self.play(GrowFromCenter(source), LaggedStart(*[Create(x) for x in beams], lag_ratio=0.06), run_time=1.6)
        self.play(self.camera.frame.animate.set(width=8.8).move_to(RIGHT*1.6), FadeIn(caption), run_time=1.8)
        self.wait(1.4)


class VerticalCausalityRiver(SacredScene):
    def construct(self):
        title = sacred_title("02", "Vertical Causality", "presence flows downward without division")
        source = radiant_disc(0.13).move_to(UP*2.7)
        terraces = VGroup(*[
            ArcBetweenPoints(LEFT*w/2 + UP*y, RIGHT*w/2 + UP*y, angle=-0.25, color=INK if i < 2 else GREY, stroke_width=2.5-i*0.25)
            for i,(w,y) in enumerate([(2.7,1.5),(4.3,0.35),(6.2,-0.9),(8.3,-2.0)])
        ])
        rivers = VGroup()
        for j,offset in enumerate(np.linspace(-1.0,1.0,9)):
            curve = VMobject(color=GOLD if j==4 else PALE, stroke_width=4 if j==4 else 2.3)
            pts=[]
            for q in np.linspace(0,1,80):
                x=offset*(0.3+2.1*q)+0.22*np.sin(5*q+offset*2)
                y=2.55-4.65*q
                pts.append([x,y,0])
            curve.set_points_smoothly(pts)
            rivers.add(curve)
        nodes = VGroup(*[Dot([0,y,0], radius=0.06, color=CRIMSON if i==0 else INK) for i,y in enumerate([1.5,.35,-.9,-2.0])])

        self.add(title)
        self.play(GrowFromCenter(source), run_time=0.9)
        self.play(LaggedStart(*[Create(r) for r in rivers], lag_ratio=0.06), run_time=2.2)
        self.play(LaggedStart(*[Create(t) for t in terraces], lag_ratio=0.15), FadeIn(nodes), run_time=1.7)
        # Manim-specific creative move: morph the river bundle into a causal tree and back.
        tree = VGroup()
        for k in range(5):
            branch = VMobject(color=GOLD if k==2 else GREY, stroke_width=3)
            branch.set_points_smoothly([[0,2.4,0],[0.2*(k-2),1.1,0],[0.75*(k-2),-0.6,0],[1.0*(k-2),-2.1,0]])
            tree.add(branch)
        original_rivers = rivers.copy()
        self.play(Transform(rivers, tree), run_time=1.5)
        self.play(Transform(rivers, original_rivers), run_time=1.2)
        self.wait(1.1)


class SymbolaAltar(SacredScene):
    def construct(self):
        title = sacred_title("03", "Symbola and Synthēmata", "divine signatures become a ritual relation")
        symbols = sigils().arrange(RIGHT, buff=1.0).shift(UP*1.55)
        alt = altar().shift(DOWN*1.25)
        source = radiant_disc(0.10).move_to(UP*2.65)
        tethers = VGroup(*[
            Line(source.get_center(), s.get_center(), color=PALE, stroke_width=1.2)
            for s in symbols
        ])
        ring = Circle(radius=2.1, color=GREY, stroke_width=1.3, stroke_opacity=0.6).shift(UP*0.25)

        self.add(title)
        self.play(Create(ring), GrowFromCenter(source), run_time=1.0)
        self.play(LaggedStart(*[DrawBorderThenFill(s) for s in symbols], lag_ratio=0.16), run_time=2.0)
        self.play(LaggedStart(*[Create(x) for x in tethers], lag_ratio=0.08), Create(alt), run_time=1.4)
        # The symbols do not just fade: they descend and recompose into an altar seal.
        targets = VGroup(*[s.copy().scale(0.72).move_to(alt[0].get_center()+RIGHT*(i-2)*0.48+UP*0.05) for i,s in enumerate(symbols)])
        self.play(Transform(symbols, targets), FadeOut(tethers), run_time=1.8)
        seal = Star(n=10, outer_radius=0.62, inner_radius=0.27, color=GOLD).move_to(alt[0].get_center()+UP*0.7)
        self.play(ReplacementTransform(ring, seal), run_time=1.4)
        self.wait(1.2)


class PurificationClarification(SacredScene):
    def construct(self):
        title = sacred_title("04", "Purification as Clarification", "noise settles into a receptive order")
        rng=np.random.default_rng(7)
        cloud = VGroup(*[
            Dot([rng.uniform(-4.6,4.6), rng.uniform(-2.1,1.7),0], radius=rng.uniform(.025,.055), color=GREY)
            for _ in range(90)
        ])
        basin = Ellipse(width=6.0, height=1.35, color=INK, stroke_width=3).shift(DOWN*1.65)
        mandala = VGroup(
            Circle(.55,color=CRIMSON), Circle(1.1,color=GOLD), Circle(1.72,color=INK),
            Star(n=8,outer_radius=.78,inner_radius=.31,color=CRIMSON)
        ).shift(DOWN*1.65)
        smoke = VGroup()
        for x in (-1.4,-.45,.45,1.4):
            p=ParametricFunction(lambda u,x=x: np.array([x+.18*np.sin(5*u),-1.0+u*2.7,0]),t_range=[0,1],color=GREY,stroke_width=2)
            smoke.add(p)
        orderly = VGroup(*[
            Dot([1.7*np.cos(k*TAU/30), -1.65+1.0*np.sin(k*TAU/30),0], radius=.035, color=GOLD if k%3==0 else GREY)
            for k in range(30)
        ])

        self.add(title)
        self.play(FadeIn(cloud), Create(basin), run_time=1.2)
        self.play(LaggedStart(*[Create(x) for x in smoke], lag_ratio=.2), run_time=1.6)
        self.play(Transform(cloud, orderly), run_time=2.3)
        self.play(LaggedStart(*[Create(x) for x in mandala], lag_ratio=.15), FadeOut(smoke), run_time=1.7)
        self.play(self.camera.frame.animate.set(width=8.5).move_to(DOWN*.65), run_time=1.4)
        self.wait(1.2)


class DescentOfPresence(SacredScene):
    def construct(self):
        title = sacred_title("05", "Descent of Presence", "the prepared chamber becomes theophany")
        left_col = Rectangle(width=.38,height=4.7,color=INK,stroke_width=2.5).shift(LEFT*3.3+DOWN*.1)
        right_col = left_col.copy().shift(RIGHT*6.6)
        archway = temple_arch(5.4,4.8).shift(DOWN*.1)
        chamber = Rectangle(width=4.8,height=3.4,color=PALE,stroke_width=1.2).shift(DOWN*.75)
        oculus = radiant_disc(.11).move_to(UP*2.45)
        v = vessel().scale(.55).shift(DOWN*1.5)
        beam = Polygon([-0.23,2.25,0],[0.23,2.25,0],[1.15,-1.2,0],[-1.15,-1.2,0],fill_color=GOLD,fill_opacity=.18,stroke_opacity=0)
        fill = Rectangle(width=.58,height=.1,fill_color=GOLD,fill_opacity=.55,stroke_opacity=0).move_to(DOWN*1.92)

        self.add(title)
        self.play(Create(left_col),Create(right_col),Create(archway),Create(chamber),run_time=1.7)
        self.play(GrowFromCenter(oculus),Create(v),run_time=1.2)
        self.play(FadeIn(beam),self.camera.frame.animate.set(width=9.2).move_to(DOWN*.2),run_time=1.7)
        self.play(fill.animate.stretch_to_fit_height(1.35).shift(UP*.62),run_time=1.8)
        # Move through the chamber: Manim camera motion gives spatial choreography without full 3D.
        self.play(self.camera.frame.animate.set(width=6.9).move_to(DOWN*.8),run_time=1.6)
        self.wait(1.4)


class AnagogicLift(SacredScene):
    def construct(self):
        title = sacred_title("06", "Symbols Lift the Soul", "anagogy gathers, forms wings, and rises")
        soul = VGroup(Circle(.22,color=CRIMSON),Dot(radius=.05,color=INK)).move_to(DOWN*1.6)
        symbols = sigils().scale(.75)
        symbols[0].move_to([-3.1,-1.8,0]); symbols[1].move_to([-1.8,-2.4,0]); symbols[2].move_to([0,-2.65,0]); symbols[3].move_to([1.8,-2.4,0]); symbols[4].move_to([3.1,-1.8,0])
        source = radiant_disc(.11).move_to(UP*2.75)
        spiral_path = ParametricFunction(lambda u: np.array([1.9*u*np.cos(4*PI*u-PI/2),-1.55+4.0*u,0]),t_range=[0,1],color=GREY,stroke_width=2.2)
        wings = VGroup()
        for side in (-1,1):
            wing=VMobject(color=GOLD,stroke_width=3)
            wing.set_points_smoothly([[0,-1.5,0],[side*.7,-.95,0],[side*1.7,-.25,0],[side*2.55,.45,0]])
            wings.add(wing)

        self.add(title)
        self.play(LaggedStart(*[DrawBorderThenFill(s) for s in symbols],lag_ratio=.14),FadeIn(soul),run_time=1.8)
        self.play(Create(spiral_path),GrowFromCenter(source),run_time=1.4)
        gathered=VGroup(*[s.copy().scale(.65).move_to(DOWN*1.25+RIGHT*(i-2)*.38) for i,s in enumerate(symbols)])
        self.play(Transform(symbols,gathered),Create(wings),run_time=1.8)
        self.play(MoveAlongPath(soul,spiral_path),symbols.animate.shift(UP*2.9).scale(.55),wings.animate.shift(UP*2.9),run_time=3.0,rate_func=smooth)
        self.play(self.camera.frame.animate.set(width=8.2).move_to(UP*.75),run_time=1.4)
        self.wait(1.1)


class GrandTheurgicCosmogram(SacredScene):
    def construct(self):
        title = sacred_title("07", "Theurgic Cosmogram", "hierarchy, symbol, embodiment, and return")
        source = radiant_disc(.10).move_to(UP*2.7)
        crown = VGroup(*[Circle(.14,color=GOLD if i<3 else INK).move_to(p) for i,p in enumerate([
            [-2.4,1.15,0],[-1.6,1.7,0],[-.6,2.0,0],[.6,2.0,0],[1.6,1.7,0],[2.4,1.15,0]
        ])])
        alt=altar().scale(.75).shift(DOWN*1.55)
        body=VGroup(Circle(.22,color=INK),Line(UP*.0,DOWN*1.0,color=INK),Line(DOWN*.35,LEFT*.55+DOWN*.75,color=INK),Line(DOWN*.35,RIGHT*.55+DOWN*.75,color=INK)).shift(UP*.2)
        seals=VGroup(*[Star(n=6,outer_radius=.22,inner_radius=.09,color=GOLD).move_to(p) for p in [LEFT*3+DOWN*1.1,RIGHT*3+DOWN*1.1,LEFT*2.25+DOWN*2.3,RIGHT*2.25+DOWN*2.3]])
        links=VGroup(*[Line(source.get_center(),x.get_center(),color=PALE,stroke_width=1.2) for x in crown])
        return_arc=Arc(radius=3.7,start_angle=-PI*.85,angle=PI*.7,color=CRIMSON,stroke_width=2.2).shift(DOWN*.2)

        self.add(title)
        self.play(GrowFromCenter(source),run_time=.8)
        self.play(LaggedStart(*[Create(x) for x in crown],lag_ratio=.12),LaggedStart(*[Create(x) for x in links],lag_ratio=.08),run_time=1.8)
        self.play(Create(alt),FadeIn(body),LaggedStart(*[DrawBorderThenFill(x) for x in seals],lag_ratio=.12),run_time=1.8)
        self.play(Create(return_arc),run_time=1.5)
        whole=VGroup(source,crown,links,alt,body,seals,return_arc)
        self.play(whole.animate.scale(.88),self.camera.frame.animate.set(width=11.0),run_time=1.6)
        self.play(Rotate(crown,angle=TAU/16),Rotate(seals,angle=-TAU/20),run_time=1.7)
        self.wait(1.5)
