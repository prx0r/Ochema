# What Manim adds to the visual language

## Strongest gains

1. **Objects can change semantic role.** A sign can descend, become part of an altar, and later reappear as a wing or cosmogram component. This is much more meaningful than fading between finished drawings.
2. **Relations can transform.** A river bundle can become a causal tree; scattered particles can become a mandala; an open ring can become a ritual seal.
3. **The camera becomes part of the argument.** Moving through a threshold or into a prepared chamber can express interiorization and participation.
4. **Timing is compositional.** `LaggedStart`, `Succession`, and grouped animation make hierarchy and procession legible.
5. **Geometry remains editable.** Objects can be reused, transformed, recolored, aligned, and nested without manually calculating every video frame.

## Risks

- Manim can default to a generic mathematics-video style.
- Too many `Create()` animations make every doctrine look like line drawing.
- Text can dominate unless the visual relation remains primary.
- The scene language still needs our parchment, temple, altar, gold, crimson, emblem, and architectural systems.

## Best role in the eventual engine

Manim should be a specialist backend for:

- morphing diagrams;
- procession and reversion;
- symbolic recomposition;
- layered causal relations;
- camera navigation through large cosmograms;
- transforms between doctrinal states.

Skia remains better for routine final 2D rendering, while Blender remains stronger for cinematic hero scenes.
