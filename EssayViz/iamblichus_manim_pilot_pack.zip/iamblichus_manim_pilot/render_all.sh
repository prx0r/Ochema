#!/usr/bin/env bash
set -euo pipefail
SCENES=(
  ThresholdBeyondDiscourse
  VerticalCausalityRiver
  SymbolaAltar
  PurificationClarification
  DescentOfPresence
  AnagogicLift
  GrandTheurgicCosmogram
)
mkdir -p rendered
for S in "${SCENES[@]}"; do
  manim -qm --format=mp4 --media_dir media iamblichus_manim.py "$S"
  FOUND=$(find media/videos -type f -name "${S}.mp4" | head -1)
  cp "$FOUND" "rendered/${S}.mp4"
done
: > rendered/concat.txt
for S in "${SCENES[@]}"; do
  echo "file '${S}.mp4'" >> rendered/concat.txt
done
(cd rendered && ffmpeg -y -f concat -safe 0 -i concat.txt -c copy iamblichus_manim_pilot.mp4)
