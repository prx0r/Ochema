#!/usr/bin/env node
import { readFile, mkdir } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { renderVideo, renderContactSheet, validateVideo } from "../MOTHERFUCKER/renderer.mjs";

const packPath=resolve(process.argv[2]??"MOTHERFUCKER/packs/essay-02-crisp-notation-gold-v2.json");
const output=resolve(process.argv[3]??"MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/video.mp4");
await mkdir(dirname(output),{recursive:true});
const pack=JSON.parse(await readFile(packPath,"utf8"));

for(const time of [0.08,0.28,0.55,0.82,0.96]){
  await renderContactSheet(
    pack,
    resolve(`MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/contact-${String(time).replace(".","")}.png`),
    {columns:3,cellWidth:480,time}
  );
}
await renderVideo(pack,output);
const validation=validateVideo(pack,output);
if(!validation.valid)throw new Error(validation.errors.join("\n"));
console.log(JSON.stringify(validation,null,2));
