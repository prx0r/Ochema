#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

mkdir -p build/audio-scenes MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2

python3 - <<'PY'
import json, subprocess
from pathlib import Path
entries=json.loads(Path("narration/narration-scenes.json").read_text())
for entry in entries:
    output=Path("build/audio-scenes")/f'{entry["id"]}.mp3'
    subprocess.run([
      "edge-tts","--voice","en-GB-SoniaNeural",
      "--text",entry["text"],"--write-media",str(output)
    ],check=True)
PY

python3 tools/compile-timed-pack.py "$ROOT"

python3 - <<'PY'
import json
from pathlib import Path
entries=json.loads(Path("narration/narration-scenes.json").read_text())
rows=[f"file '{(Path('build/audio-scenes')/(e['id']+'.mp3')).resolve()}'" for e in entries]
Path("build/audio-scenes/concat.txt").write_text("\n".join(rows)+"\n")
PY

ffmpeg -y -loglevel error -f concat -safe 0 \
  -i build/audio-scenes/concat.txt \
  -c:a libmp3lame -q:a 2 \
  MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/narration.mp3

python3 MOTHERFUCKER/tools/analyse-audio.py \
  MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/narration.mp3 \
  MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/features.json

node tools/render-pack.mjs

ffmpeg -y -loglevel error \
  -i MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/video.mp4 \
  -i MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/narration.mp3 \
  -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -shortest \
  MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/final.mp4

echo "Built MOTHERFUCKER/build/essay-02-crisp-notation-gold-v2/final.mp4"
