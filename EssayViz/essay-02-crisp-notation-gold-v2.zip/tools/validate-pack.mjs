#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";

const root=resolve(process.argv[2]??".");
const pack=JSON.parse(await readFile(
  resolve(root,"MOTHERFUCKER/packs/essay-02-crisp-notation-gold-v2.template.json"),
  "utf8"
));
const derivation=JSON.parse(await readFile(
  resolve(root,"PROCESS/01-COMPREHENSION-AND-DERIVATION.json"),
  "utf8"
));

const errors=[];
if(pack.scenes.length!==12)errors.push("expected twelve scenes");
if(derivation.new_mechanisms.length!==5)errors.push("expected five new mechanisms");

const operations=new Set(pack.scenes.flatMap(s=>s.params.operations.map(o=>o.type)));
for(const mechanism of derivation.new_mechanisms){
  if(!operations.has(mechanism.id))errors.push(`missing operation ${mechanism.id}`);
  for(const field of [
    "source_passage","incoming_belief","operation","outgoing_belief",
    "nodes","edges","invariant","forbidden_inference","decisive_mutation"
  ]){
    if(mechanism[field]===undefined)errors.push(`${mechanism.id}: missing ${field}`);
  }
}

for(const scene of pack.scenes){
  if(scene.motif!=="essay-02-crisp-v2")errors.push(`${scene.id}: wrong motif`);
  for(const op of scene.params.operations){
    if(!Number.isFinite(op.start)||!Number.isFinite(op.end))errors.push(`${scene.id}: untimed operation`);
    if(op.start<0||op.end>1||op.end<=op.start)errors.push(`${scene.id}: invalid timing`);
  }
}

if(errors.length){
  console.error(errors.join("\n"));
  process.exit(1);
}
console.log("Essay 02 crisp notation gold v2: valid");
