#!/usr/bin/env node
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const root=resolve(process.cwd());
async function patch(path,fn){
  const source=await readFile(path,"utf8");
  const updated=fn(source);
  if(updated!==source)await writeFile(path,updated);
  console.log(updated!==source?`patched ${path}`:`unchanged ${path}`);
}

await patch(resolve(root,"motifs.mjs"),source=>{
  if(!source.includes("renderEssay02CrispV2")){
    const importLine='import { renderEssay02CrispV2 } from "./src/essay-02-crisp-v2-motif.mjs";';
    source=`${importLine}\n${source}`;
  }
  if(!source.includes('"essay-02-crisp-v2": renderEssay02CrispV2')){
    source=source.replace(
      "export const motifs = {",
      'export const motifs = {\n  "essay-02-crisp-v2": renderEssay02CrispV2,'
    );
  }
  return source;
});

await patch(resolve(root,"renderer.mjs"),source=>{
  source=source.replace(
    'scene.motif === "argument-diagram-v2" || scene.motif === "logical-argument"',
    'scene.motif === "argument-diagram-v2" || scene.motif === "essay-02-crisp-v2" || scene.motif === "logical-argument"'
  );
  return source;
});

console.log("Essay 02 crisp notation v2 registered.");
