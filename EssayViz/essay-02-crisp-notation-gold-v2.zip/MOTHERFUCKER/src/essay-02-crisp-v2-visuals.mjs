import { TAU, clamp, rgba, smoothstep } from "../math.mjs";
import { drawArrowHead, drawGlowOrb, drawNode, drawRing } from "../primitives.mjs";

const W=1280,H=720,CX=640,CY=330;
const SERIF='"Source Serif 4", "EB Garamond", serif';
const MATH='"KaTeX Math", "Source Serif 4", serif';
const P={
  paper:"#fdfdfb",ink:"#15191e",graphite:"#626a74",grid:"#cfd5d9",
  indigo:"#2f557d",blue:"#347894",crimson:"#a43e47",green:"#397653",
  gold:"#a87a2d",violet:"#65528b",pale:"#e9edef"
};

function font(size,{italic=false,weight=400,math=false}={}){
  return `${italic?"italic ":""}${weight} ${size}px ${math?MATH:SERIF}`;
}
function txt(ctx,value,x,y,{size=18,color=P.ink,alpha=1,align="center",weight=400,italic=false,math=false}={}){
  ctx.save();ctx.font=font(size,{italic,weight,math});ctx.textAlign=align;ctx.textBaseline="middle";
  ctx.fillStyle=rgba(color,alpha);ctx.fillText(String(value),x,y);ctx.restore();
}
function multiline(ctx,value,x,y,opts={}){
  const size=opts.size??18,lh=size*(opts.lineHeight??1.24),arr=String(value).split("\n");
  arr.forEach((line,i)=>txt(ctx,line,x,y+(i-(arr.length-1)/2)*lh,{...opts,size}));
}
function arrow(ctx,a,b,{color=P.graphite,alpha=.48,width=.9,dashed=false,head=7}={}){
  ctx.save();if(dashed)ctx.setLineDash([5,7]);ctx.strokeStyle=rgba(color,alpha);ctx.lineWidth=width;
  ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.restore();
  drawArrowHead(ctx,b.x,b.y,Math.atan2(b.y-a.y,b.x-a.x),head,color,alpha);
}
function bracket(ctx,x1,x2,y,{color=P.graphite,alpha=.42,height=10,label=""}={}){
  ctx.save();ctx.strokeStyle=rgba(color,alpha);ctx.lineWidth=.85;
  ctx.beginPath();ctx.moveTo(x1,y-height);ctx.lineTo(x1,y);ctx.lineTo(x2,y);ctx.lineTo(x2,y-height);ctx.stroke();ctx.restore();
  if(label)txt(ctx,label,(x1+x2)/2,y+24,{size:13,color,alpha:.9});
}
function box(ctx,x,y,w,h,{stroke=P.graphite,fill=null,alpha=.35,width=.9,radius=0}={}){
  ctx.save();ctx.globalAlpha=alpha;if(fill){ctx.fillStyle=fill;ctx.fillRect(x,y,w,h);}
  ctx.strokeStyle=stroke;ctx.lineWidth=width;ctx.strokeRect(x,y,w,h);ctx.restore();
}
function paper(ctx){
  ctx.fillStyle=P.paper;ctx.fillRect(0,0,W,H);
  ctx.save();ctx.strokeStyle=rgba(P.grid,.018);ctx.lineWidth=.45;
  for(let x=80;x<W;x+=80){ctx.beginPath();ctx.moveTo(x,50);ctx.lineTo(x,H-45);ctx.stroke();}
  for(let y=90;y<H;y+=60){ctx.beginPath();ctx.moveTo(45,y);ctx.lineTo(W-45,y);ctx.stroke();}
  ctx.restore();
}
function header(ctx,label){
  txt(ctx,label,72,60,{size:12,color:P.graphite,align:"left",weight:700});
  ctx.save();ctx.strokeStyle=rgba(P.graphite,.2);ctx.lineWidth=.65;
  ctx.beginPath();ctx.moveTo(72,79);ctx.lineTo(390,79);ctx.stroke();ctx.restore();
}
function win(op,t,i,n){
  const s=op.start??i/n,e=op.end??(i+1)/n,p=clamp((t-s)/Math.max(.001,e-s));
  const a=op.persist?smoothstep(s,s+.06,t):smoothstep(s,s+.06,t)*(1-smoothstep(e-.06,e,t));
  return {p,a,visible:t>=s&&(op.persist||t<=e)};
}

/* NEW 1: availability map */
function epistemicAvailabilityMap(ctx,p,op){
  header(ctx,"EPISTEMIC AVAILABILITY");
  const objects=[
    {id:"x₁",x:205,y:215,label:"perceived object"},
    {id:"x₂",x:205,y:330,label:"inferred object"},
    {id:"x₃",x:205,y:445,label:"denied object"},
  ];
  const cognition={x:585,y:330};
  const manifest={x:980,y:330};

  objects.forEach((o,i)=>{
    const q=smoothstep(.03+i*.08,.24+i*.08,p);
    drawRing(ctx,o.x,o.y,48,P.indigo,.25*q,1);
    txt(ctx,o.id,o.x,o.y-4,{size:18,color:P.indigo,math:true,weight:700,alpha:q});
    txt(ctx,o.label,o.x,o.y+68,{size:13,color:P.graphite,alpha:q});
    arrow(ctx,{x:o.x+48,y:o.y},{x:cognition.x-95,y:cognition.y+(i-1)*34},{color:P.indigo,alpha:.42*q});
  });

  const qc=smoothstep(.26,.55,p);
  drawRing(ctx,cognition.x,cognition.y,95,P.blue,.28*qc,1.1);
  multiline(ctx,"manifest\ncognition",cognition.x,cognition.y,{size:20,color:P.blue,weight:700,alpha:qc});

  const qm=smoothstep(.48,.78,p);
  arrow(ctx,{x:cognition.x+95,y:cognition.y},{x:manifest.x-98,y:manifest.y},{color:P.green,alpha:.55*qm,width:1.1});
  drawRing(ctx,manifest.x,manifest.y,98,P.gold,.3*qm,1.1);
  txt(ctx,"Manifest(x)",manifest.x,manifest.y,{size:22,color:P.gold,math:true,weight:700,alpha:qm});

  const final=smoothstep(.72,.96,p);
  bracket(ctx,150,1080,560,{color:P.green,alpha:.48*final,label:"EpistemicallyAvailable(x) ⇒ Manifest(x)"});
}

/* NEW 2: pramana dependency stack */
function pramanaDependencyStack(ctx,p,op){
  header(ctx,"NO EXTERNAL PRAMĀṆA");
  const labels=["perception","inference","testimony","denial"];
  const ys=[170,275,380,485];
  const left=235,mid=640,right=1045;

  labels.forEach((label,i)=>{
    const q=smoothstep(.04+i*.08,.25+i*.08,p);
    box(ctx,left-95,ys[i]-28,190,56,{stroke:P.indigo,alpha:.34*q});
    txt(ctx,label,left,ys[i],{size:16,color:P.indigo,weight:600,alpha:q});
    arrow(ctx,{x:left+95,y:ys[i]},{x:mid-100,y:ys[i]},{color:P.graphite,alpha:.38*q});
    box(ctx,mid-100,ys[i]-28,200,56,{stroke:P.blue,alpha:.3*q});
    txt(ctx,"manifest cognition",mid,ys[i],{size:15,color:P.blue,alpha:q});
    arrow(ctx,{x:mid+100,y:ys[i]},{x:right-80,y:ys[i]},{color:P.gold,alpha:.45*q});
  });

  const qr=smoothstep(.46,.78,p);
  drawRing(ctx,right,CY,88,P.gold,.3*qr,1.2);
  txt(ctx,"M",right,CY,{size:27,color:P.gold,math:true,weight:700,alpha:qr});
  txt(ctx,"presupposed",right,CY+118,{size:14,color:P.gold,alpha:qr});

  const ext=smoothstep(.7,.94,p);
  txt(ctx,"external instrument?",CX,610,{size:18,color:P.crimson,alpha:ext,weight:700});
  ctx.save();ctx.strokeStyle=rgba(P.crimson,.72*ext);ctx.lineWidth=1.4;
  ctx.beginPath();ctx.moveTo(CX-105,590);ctx.lineTo(CX+105,630);ctx.moveTo(CX-105,630);ctx.lineTo(CX+105,590);ctx.stroke();ctx.restore();
}

/* NEW 3: variable matrix */
function variableSeparationMatrix(ctx,p,op){
  header(ctx,"VARIABLE SEPARATION");
  const rows=[
    ["M","manifestation","is something present?"],
    ["O","phenomenal ownership","for whom or as whose field?"],
    ["S","metaphysical self","what enduring entity exists?"],
  ];
  const x0=170,y0=175,rowH=120,col=[0,130,420,820];
  txt(ctx,"var",x0+col[0],125,{size:13,color:P.graphite,weight:700});
  txt(ctx,"name",x0+col[1],125,{size:13,color:P.graphite,weight:700});
  txt(ctx,"question",x0+col[2],125,{size:13,color:P.graphite,weight:700});
  txt(ctx,"entailed by denial?",x0+col[3],125,{size:13,color:P.graphite,weight:700});

  rows.forEach((r,i)=>{
    const q=smoothstep(.04+i*.13,.3+i*.13,p),y=y0+i*rowH;
    ctx.save();ctx.strokeStyle=rgba(P.grid,.45*q);ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(130,y+52);ctx.lineTo(1150,y+52);ctx.stroke();ctx.restore();
    txt(ctx,r[0],x0+col[0],y,{size:24,color:i===0?P.gold:(i===1?P.indigo:P.crimson),math:true,weight:700,alpha:q});
    txt(ctx,r[1],x0+col[1],y,{size:18,color:P.ink,align:"left",alpha:q});
    txt(ctx,r[2],x0+col[2],y,{size:16,color:P.graphite,align:"left",alpha:q});
    const status=i===0?"YES":"NO";
    txt(ctx,status,x0+col[3],y,{size:17,color:i===0?P.green:P.crimson,weight:700,alpha:q});
  });

  const final=smoothstep(.72,.96,p);
  bracket(ctx,140,1140,590,{color:P.gold,alpha:.42*final,label:"M does not collapse into O or S"});
}

/* NEW 4: Saiva premise ladder */
function saivaPremiseLadder(ctx,p,op){
  header(ctx,"FROM MINIMAL RESULT TO ŚAIVA MONISM");
  const rungs=[
    "manifestation is epistemically primitive",
    "all manifestations share one ground",
    "the ground is numerically one",
    "self-manifestation is reflexive agency",
    "local subjects are contractions",
    "objectivity is free articulation",
  ];
  const x=330,y0=140,step=78;
  rungs.forEach((r,i)=>{
    const q=smoothstep(.03+i*.08,.24+i*.08,p),y=y0+i*step;
    box(ctx,x,y,620,46,{stroke:i===0?P.green:(i<3?P.gold:P.crimson),alpha:.28*q});
    txt(ctx,`${i+1}.`,x+28,y+23,{size:15,color:P.graphite,alpha:q,weight:700});
    txt(ctx,r,x+70,y+23,{size:16,color:P.ink,alpha:q,align:"left"});
    if(i<rungs.length-1){
      arrow(ctx,{x:x+310,y:y+46},{x:x+310,y:y+step},{color:i===0?P.gold:P.crimson,alpha:.34*q,dashed:i>0});
    }
  });
  const cut=smoothstep(.62,.88,p);
  ctx.save();ctx.strokeStyle=rgba(P.crimson,.78*cut);ctx.lineWidth=1.6;
  ctx.beginPath();ctx.moveTo(x+290,y0+step-10);ctx.lineTo(x+330,y0+step+28);ctx.moveTo(x+290,y0+step+28);ctx.lineTo(x+330,y0+step-10);ctx.stroke();ctx.restore();
  txt(ctx,"denial argument ends here",980,y0+step+8,{size:14,color:P.crimson,alpha:cut,align:"left",weight:700});
}

/* NEW 5: CIMC interpretation lattice */
function cimcInterpretationLattice(ctx,p,op){
  header(ctx,"CIMC INTERPRETATION LATTICE");
  const center={x:CX,y:150};
  drawRing(ctx,center.x,center.y,92,P.indigo,.27,1.1);
  multiline(ctx,"second-order perception\n+ coherent agency",center.x,center.y,{size:18,color:P.indigo,weight:700});

  const nodes=[
    {x:260,y:430,label:"cause of\nmanifestation",color:P.blue},
    {x:505,y:430,label:"constitutive\norganization",color:P.green},
    {x:775,y:430,label:"structure within\nmanifest process",color:P.gold},
    {x:1020,y:430,label:"model producing\nconsciousness-talk",color:P.crimson},
  ];
  nodes.forEach((n,i)=>{
    const q=smoothstep(.08+i*.08,.3+i*.08,p);
    arrow(ctx,{x:center.x+(i-1.5)*16,y:center.y+92},{x:n.x,y:n.y-82},{color:n.color,alpha:.42*q,dashed:i===3});
    drawRing(ctx,n.x,n.y,82,n.color,.25*q,1);
    multiline(ctx,n.label,n.x,n.y,{size:15,color:n.color,weight:700,alpha:q});
  });

  const final=smoothstep(.68,.95,p);
  txt(ctx,"same transition · four interpretations",CX,585,{size:19,color:P.ink,alpha:final,weight:700});
  bracket(ctx,190,1090,615,{color:P.graphite,alpha:.4*final,label:"architecture alone does not select the metaphysics"});
}

/* prior but sharpened mechanisms */
function reflexiveDenial(ctx,p){
  header(ctx,"REFLEXIVE DENIAL");
  drawRing(ctx,CX,CY,225,P.gold,.3,1.15);
  txt(ctx,"M",CX,CY-260,{size:22,color:P.gold,math:true,weight:700});
  const q=smoothstep(.06,.78,p),a={x:CX-160,y:CY-72},b={x:CX+160,y:CY+72};
  const c={x:a.x+(b.x-a.x)*q,y:a.y+(b.y-a.y)*q};
  ctx.save();ctx.strokeStyle=rgba(P.crimson,.8);ctx.lineWidth=9;ctx.lineCap="round";
  ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(c.x,c.y);ctx.stroke();ctx.restore();
  txt(ctx,"¬M",c.x+25,c.y-26,{size:23,color:P.crimson,math:true,weight:700,alpha:q});
  const r=smoothstep(.55,.92,p);
  drawRing(ctx,c.x,c.y,34,P.gold,.35*r,.8);
  txt(ctx,"token inside M",CX,610,{size:18,color:P.gold,alpha:r,weight:700});
}
function representationalDilemma(ctx,p){
  header(ctx,"REPRESENTATIONALIST DILEMMA");
  drawRing(ctx,CX,145,92,P.indigo,.26,1.1);txt(ctx,"REPRESENTATION",CX,145,{size:18,color:P.indigo,weight:700});
  const left={x:365,y:420},right={x:915,y:420},q=smoothstep(.12,.75,p);
  arrow(ctx,{x:610,y:225},{x:left.x,y:left.y-100},{color:P.blue,alpha:.45*q});
  arrow(ctx,{x:670,y:225},{x:right.x,y:right.y-100},{color:P.gold,alpha:.45*q});
  drawRing(ctx,left.x,left.y,112,P.blue,.28*q,1.1);
  multiline(ctx,"functional\ninformation-bearing",left.x,left.y-15,{size:18,color:P.blue,weight:700,alpha:q});
  txt(ctx,"manifestness unexplained",left.x,585,{size:17,color:P.crimson,alpha:q,weight:700});
  drawRing(ctx,right.x,right.y,112,P.gold,.28*q,1.1);
  multiline(ctx,"presentational\nappearing to awareness",right.x,right.y-15,{size:18,color:P.gold,weight:700,alpha:q});
  txt(ctx,"manifestness presupposed",right.x,585,{size:17,color:P.green,alpha:q,weight:700});
}
function illusionismCheck(ctx,p){
  header(ctx,"ILLUSIONISM: DEFINE “SEEMS”");
  drawRing(ctx,CX,145,74,P.violet,.24,1);txt(ctx,"Seems(p)",CX,145,{size:21,color:P.violet,math:true,weight:700});
  const L={x:350,y:425},R={x:930,y:425},q=smoothstep(.12,.78,p);
  arrow(ctx,{x:610,y:215},{x:L.x,y:L.y-90},{color:P.gold,alpha:.45*q});
  arrow(ctx,{x:670,y:215},{x:R.x,y:R.y-90},{color:P.blue,alpha:.45*q});
  drawRing(ctx,L.x,L.y,105,P.gold,.26*q,1);
  multiline(ctx,"appearing\nseeming",L.x,L.y,{size:19,color:P.gold,weight:700,alpha:q});
  txt(ctx,"manifestation retained",L.x,565,{size:15,color:P.green,alpha:q});
  drawRing(ctx,R.x,R.y,105,P.blue,.26*q,1);
  multiline(ctx,"dispositional\nseeming",R.x,R.y,{size:19,color:P.blue,weight:700,alpha:q});
  multiline(ctx,"judge · report · act\nas though p",R.x,565,{size:14,color:P.graphite,alpha:q});
}
function finalFrontier(ctx,p){
  header(ctx,"SECURED / UNPROVED");
  const q=smoothstep(.04,.5,p);
  multiline(ctx,"Every establishment or denial of reality\noccurs within manifestation.",CX,235,{size:28,color:P.green,weight:700,alpha:q});
  bracket(ctx,260,1020,330,{color:P.green,alpha:.5*q,label:"secured"});
  const r=smoothstep(.45,.88,p);
  multiline(ctx,"Does transcendental priority entail\nontological manifestation-monism?",CX,470,{size:28,color:P.crimson,weight:700,alpha:r});
  bracket(ctx,260,1020,565,{color:P.crimson,alpha:.5*r,label:"unproved"});
  txt(ctx,"next: determination · boundedness · privacy",CX,645,{size:15,color:P.graphite,alpha:smoothstep(.78,.98,p)});
}

const DRAW={
 "epistemic-availability-map":epistemicAvailabilityMap,
 "pramana-dependency-stack":pramanaDependencyStack,
 "variable-separation-matrix":variableSeparationMatrix,
 "saiva-premise-ladder":saivaPremiseLadder,
 "cimc-interpretation-lattice":cimcInterpretationLattice,
 "reflexive-denial-proof":reflexiveDenial,
 "representation-dilemma":representationalDilemma,
 "illusionism-category-check":illusionismCheck,
 "final-frontier":finalFrontier,
};

export function renderEssay02CrispV2(ctx,t,scene,env){
  paper(ctx);
  const ops=scene.params?.operations??[],n=Math.max(1,ops.length);
  ops.forEach((op,i)=>{
    const {p,a,visible}=win(op,t,i,n);if(!visible)return;
    ctx.save();ctx.globalAlpha=a;(DRAW[op.type]??(()=>{}))(ctx,p,op,env);ctx.restore();
  });
  const rms=clamp(env.audio?.rms??0);
  if(rms>.02)drawRing(ctx,CX,CY,288+rms*6,P.gold,.006+rms*.006,.4);
}

export const assetImplementations=Object.freeze({});
export const mechanismImplementations=Object.freeze({
 "essay-02-crisp-v2":renderEssay02CrispV2,
});
