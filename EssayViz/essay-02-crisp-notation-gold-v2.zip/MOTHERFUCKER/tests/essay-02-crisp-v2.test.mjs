import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const pack=JSON.parse(await readFile(
  new URL("../packs/essay-02-crisp-notation-gold-v2.template.json",import.meta.url),
  "utf8"
));

test("film contains twelve source-derived scenes",()=>{
  assert.equal(pack.scenes.length,12);
});

test("five new precision mechanisms are present",()=>{
  const source=JSON.stringify(pack);
  for(const id of [
    "epistemic-availability-map",
    "pramana-dependency-stack",
    "variable-separation-matrix",
    "saiva-premise-ladder",
    "cimc-interpretation-lattice",
  ]) assert.match(source,new RegExp(id));
});

test("every scene uses the crisp notation motif",()=>{
  for(const scene of pack.scenes){
    assert.equal(scene.motif,"essay-02-crisp-v2");
    assert.ok(scene.params.operations.length>0);
  }
});

test("the pack preserves the final unresolved frontier",()=>{
  assert.match(JSON.stringify(pack),/final-frontier/);
  assert.match(pack.description,/granular node, edge, scope/);
});
