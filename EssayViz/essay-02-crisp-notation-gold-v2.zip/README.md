# Essay 02 — Crisp Notation Gold Standard v2

A complete, ready-to-render film pack for:

> Can Manifestation Be Denied?

This is a second-generation notation system built from the supplied essay rather
than from a nearest visual template.

## Five new precision mechanisms

1. `epistemic-availability-map`
2. `pramana-dependency-stack`
3. `variable-separation-matrix`
4. `saiva-premise-ladder`
5. `cimc-interpretation-lattice`

These supplement the earlier denial, representationalist, illusionist and
minimal/maximal mechanisms.

## Visual language

- matte white field;
- Source Serif 4 for prose and IAST;
- KaTeX Math for equations and variables;
- graphite neutral structure;
- indigo physical/functionalist relations;
- gold manifestation/presupposition;
- green licensed implication;
- crimson unsupported bridge or rejected inference;
- exact brackets, scopes, matrices, gates and dependency stacks;
- no particles, cosmic backgrounds or generic mystical effects.

## Apply

Extract over the repository root, then from `MOTHERFUCKER/`:

```bash
node ../tools/apply-essay-02-crisp-v2.mjs
```

## Render

```bash
bash ../tools/build-film.sh
```

## Validate

```bash
node ../tools/validate-pack.mjs ..
node --test tests/essay-02-crisp-v2.test.mjs
```
