# Render Review Checklist

## Typography

- Source Serif 4 is actually registered.
- KaTeX Math is used for variables and equations.
- No label falls below 13 px at 1280×720.
- No labels collide with edges.
- Mathematical notation has more negative space than prose.

## Geometry

- Solid green edges are visibly continuous.
- Dashed crimson edges remain visually distinct.
- Red cuts intersect only the intended edge or rung.
- Brackets delimit exact scope.
- Matrix rows align precisely.
- The premise ladder does not appear as triumphant ascent.
- CIMC branches receive equal visual status.

## Semantics

- The reflexive-denial scene reads as containment, not cosmic luminosity.
- `Manifest(x)` does not read as mental representation.
- No external pramāṇa is shown as a presupposition argument, not an infinite regress.
- M, O and S remain visually independent.
- Buddhist no-self is not marked false.
- Functional representation remains coherent but incomplete.
- Dispositional illusionism remains coherent but changes the starting data.
- CIMC architecture does not select a metaphysical interpretation.
- The final unresolved bracket remains visible.

## Motion

- Every animation mutates proof structure.
- Frames cannot be reordered without changing the apparent reasoning.
- Audio does not create or delete logical content.
- No generic transition replaces the decisive mutation.

## Required review outputs

```text
contact-008.png
contact-028.png
contact-055.png
contact-082.png
contact-096.png
```
