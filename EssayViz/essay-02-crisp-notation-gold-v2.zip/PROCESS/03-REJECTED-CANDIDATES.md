# Rejected Visual Candidates

## Epistemic availability

### Funnel of sensory icons

Rejected because the argument includes inference and denial, not only sensory
input. It also risks identifying manifestation with perception.

### Spotlight illuminating an object

Rejected because physical illumination would reintroduce the misleading light
metaphor the essay explicitly warns against.

### Selected solution

Typed epistemic routes converging into manifest cognition.

## No external pramāṇa

### Circular regress

Rejected because the passage is not primarily an infinite regress argument. It
is a presupposition argument.

### Observer standing outside a circle

Rejected because it visually grants the external position before withdrawing
it.

### Selected solution

Parallel dependency rows all terminating in M, followed by a crossed external
position.

## Manifestation, ownership and selfhood

### Three branches from cognition

Rejected as insufficiently granular. Branches show alternatives, but the essay
requires separate variables and separate entailment questions.

### Nested circles

Rejected because nesting implies ownership or selfhood contains manifestation.

### Selected solution

A matrix with distinct variable, name, question and entailment columns.

## Minimal versus maximal Śaiva reading

### One dashed arrow to Śiva

Rejected because it hides the five additional commitments listed in the essay.

### Mountain or ascending staircase

Rejected because upward movement would imply progress or superiority.

### Selected solution

A neutral premise ladder cut after the secured first rung.

## CIMC

### Robot becoming luminous

Rejected because it presupposes the consciousness interpretation.

### Four sequential scenes

Rejected because the invariant observed architecture would disappear between
interpretations.

### Selected solution

One fixed central transition with four simultaneous interpretive branches.
