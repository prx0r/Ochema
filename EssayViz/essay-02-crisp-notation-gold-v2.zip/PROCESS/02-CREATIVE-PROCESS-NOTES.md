# Creative Process Notes

## Phase 1 — Read for inferential structure

I first removed the essay's rhetorical surface and rewrote it as a dependency
map.

```text
reflexive denial
→ epistemic ineliminability
→ no external pramāṇa
→ minimal conclusion
```

Then I marked everything that does **not** follow:

```text
minimal conclusion
⇏ mental representation only
⇏ substantial ego
⇏ enduring owner
⇏ one universal subject
⇏ Śaiva monism without added premises
```

This produced the film's visual grammar before any aesthetic decision.

## Phase 2 — Identify where the earlier pack lacked precision

The earlier pack correctly used containment, branches and dilemmas. Its weakness
was that some scenes still encoded whole paragraphs as one diagram.

For example, “manifestation, ownership and selfhood are distinct” was shown
through three branches. That was conceptually relevant, but not exact enough.
The new matrix asks three different questions and marks the denial argument's
entailment status separately for each variable.

Likewise, “the maximal reading requires more premises” was previously one broken
edge. The essay actually lists five additional commitments. The new premise
ladder displays all five and marks the exact point where the denial argument
ends.

## Phase 3 — Convert prose into typed objects

Every visual object received a type.

### Proposition node

A claim such as:

```text
Manifest(x)
```

### Domain node

The manifest domain:

```text
M
```

### Definition node

A term whose meaning is contested:

```text
REPRESENTATION
SEEMS(p)
```

### Variable row

A variable that must remain independent:

```text
M
O
S
```

### Interpretation branch

A reading not selected by the evidence alone.

### Scope bracket

The exact range of a secured conclusion.

### Unsupported bridge

A dashed crimson edge whose presence means “proposed, not established.”

This prevented the typography from becoming ornamental.

## Phase 4 — Specify edge semantics before animation

I used a controlled edge vocabulary.

| Edge | Meaning |
|---|---|
| Solid green | licensed implication |
| Solid graphite | neutral dependency |
| Indigo | physical, functional or epistemic route |
| Gold | manifestation or presupposition |
| Dashed crimson | unsupported bridge |
| Red cut | inference explicitly withheld |
| Bracket | exact scope of conclusion |
| Convergence | several routes share one condition |
| Bifurcation | one term or event admits several readings |

An agent should never choose line style after rendering. Line style is part of
the argument schema.

## Phase 5 — Design the decisive mutation first

For each scene I designed the moment that changes the viewer's model.

### Epistemic availability

Decisive mutation:

```text
three different routes converge
→ one solid implication to Manifest(x)
```

### Pramāṇa dependence

Decisive mutation:

```text
all instruments terminate in M
→ proposed external position is crossed out
```

### Variable separation

Decisive mutation:

```text
YES appears only for M
→ O and S remain NO
```

### Śaiva premise ladder

Decisive mutation:

```text
first rung remains green
→ ladder is cut before ontological unity
```

### CIMC lattice

Decisive mutation:

```text
one architecture remains fixed
→ four non-equivalent interpretations appear
```

Only after these moments were fixed did I design the opening arrangement.

## Phase 6 — Keep transitions inside the proof

The animation does not transition by replacing one finished slide with another.

Examples:

- epistemic routes physically converge into the cognition node;
- rows accumulate into a dependency stack;
- the variable matrix reveals entailment status row by row;
- the premise ladder grows upward and is cut at a precise rung;
- the CIMC event remains fixed while interpretations branch around it.

This gives the viewer a visible derivation rather than a sequence of diagrams.

## Phase 7 — Use typography as geometry

The restrained style depends on treating notation as spatial structure.

- Variables are centered within exact nodes.
- Prose labels sit outside logical geometry.
- Equations receive more negative space than explanatory prose.
- Brackets delimit scope instead of using boxes around everything.
- Capitalized operator labels appear only when they behave as stable tokens.
- Sanskrit terms are not used as decoration; each names a formal role.

## Phase 8 — Prevent overclaiming visually

The pack has explicit forbidden implications.

- Gold does not mean “cosmic consciousness.”
- A field labelled M is an epistemic domain, not a glowing metaphysical
  substance.
- The ladder's upper rungs are not illuminated as a climax.
- Buddhist no-self is not struck through.
- Illusionism receives two coherent branches.
- The CIMC lattice does not privilege the constitutive interpretation.
- The final red bracket remains visible rather than being resolved by a
  triumphant ending.

## Phase 9 — Audio discipline

Narration audio changes only a nearly invisible outer ring.

It does not:

- create an implication;
- cut an edge;
- choose a branch;
- alter an entailment status;
- time a conclusion independently of authored scene structure.

The logical animation remains deterministic and semantically authored.

## Phase 10 — Gold-standard agent lesson

The reusable lesson is not “use matrices for philosophy.”

It is:

```text
read the exact claim
→ type the variables
→ type the relations
→ state the forbidden inference
→ identify the decisive mutation
→ design the visual around that mutation
```

A future essay may require a graph, quotient, field, matrix, lattice, temporal
trace or topological split. The process chooses among them. The essay title
does not.
