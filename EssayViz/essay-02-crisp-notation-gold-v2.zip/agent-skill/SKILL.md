---
name: crisp-mathematical-logicvid
description: Derive a granular white-field notation film from a full philosophical essay without reusing the nearest completed template.
version: 2.0
---

# Crisp Mathematical Logicvid

## Mission

Translate an essay into an executable notation system where every node, edge,
bracket and transition has an explicit argumentative role.

## Phase 1 — Source comprehension

Read the complete essay before proposing visuals.

Extract:

```json
{
  "central_contention": "",
  "minimal_result": "",
  "maximal_or_unlicensed_result": "",
  "premises": [],
  "variable_distinctions": [],
  "definition_forks": [],
  "serious_rivals": [],
  "scientific_category_check": "",
  "framework_update": "",
  "surviving_frontier": ""
}
```

Do not silently repair or strengthen the essay.

## Phase 2 — Inferential segmentation

Segment by operation, not paragraph length.

For each segment:

```json
{
  "incoming_belief": "",
  "operation": "",
  "outgoing_belief": "",
  "evidence_status": "",
  "forbidden_inference": ""
}
```

The operation must be a verb such as:

```text
contain
converge
presuppose
separate
branch
define
cut
withhold
identify
compare
```

## Phase 3 — Typed notation model

Before rendering, define:

```json
{
  "nodes": [
    {
      "id": "",
      "type": "proposition|domain|variable|definition|theory|evidence|interpretation",
      "meaning": ""
    }
  ],
  "edges": [
    {
      "from": "",
      "to": "",
      "type": "licensed|dependency|physical|presupposition|unsupported|definition",
      "meaning": ""
    }
  ],
  "scopes": [],
  "cuts": [],
  "invariant": ""
}
```

Never draw an unlabeled semantic edge.

## Phase 4 — Candidate tournament

Generate three topologically distinct candidates for every major mechanism.

Candidates may not differ only by:

- color;
- glow;
- font;
- camera;
- particles;
- orientation.

Score:

- relation fidelity;
- variable fidelity;
- edge semantics;
- invariant preservation;
- decisive mutation;
- silent legibility;
- epistemic restraint;
- anti-template distinctness.

Hard gates:

```text
relation fidelity >= 4
decisive mutation >= 4
epistemic restraint >= 4
```

## Phase 5 — Decisive mutation

Design the state-changing event first.

Examples:

- several routes converge;
- one implication completes and another is cut;
- one variable receives YES while others remain NO;
- a premise ladder is interrupted at one rung;
- one event branches into multiple interpretations.

Then design the initial state that makes the mutation intelligible.

## Phase 6 — Visual semantics

Use this controlled notation:

| Visual form | Meaning |
|---|---|
| Solid green edge | Licensed implication |
| Graphite edge | Neutral dependency |
| Indigo edge | Physical, functional or epistemic route |
| Gold edge/node | Manifestation or presupposition |
| Dashed crimson edge | Unsupported bridge |
| Red cut | Inference withheld |
| Bracket | Exact scope |
| Common root | Shared evidence |
| Matrix row | Independent variable or question |
| Lattice branch | Alternative interpretation |

Do not deviate without documenting the new convention.

## Phase 7 — Typography

- Source Serif 4 for prose, labels and IAST;
- KaTeX Math for equations and variables;
- matte white background;
- body text at least 13 px at 1280×720;
- logical notation larger than commentary;
- preserve negative space;
- never place prose inside dense edge crossings.

## Phase 8 — Transitions

Transitions occur through proof mutation.

Allowed:

- node creation;
- edge completion;
- edge removal;
- convergence;
- bifurcation;
- scope expansion;
- bracket closure;
- matrix reveal;
- premise accumulation.

Forbidden:

- generic crossfade;
- decorative zoom;
- random particle burst;
- arbitrary blur;
- palette change used as the primary argument.

## Phase 9 — Audio

Audio may modulate only subordinate atmosphere and micro-emphasis.

Audio may not:

- license an implication;
- reject a premise;
- choose a rival;
- alter variable status;
- hide an unresolved edge.

## Phase 10 — Required documentation

Deliver:

- source lock;
- comprehension map;
- decision record;
- exact node and edge semantics;
- candidate tournament;
- rejected alternatives;
- decisive mutation for every scene;
- scene pack;
- narration;
- framework patch;
- validation;
- five-time contact sheets;
- final unresolved statement.
