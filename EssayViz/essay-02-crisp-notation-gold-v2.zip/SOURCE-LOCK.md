# Source Lock

This pack is grounded in the supplied Essay 2.

The film must preserve these exact claims:

## Secured

```text
Every establishment or denial of reality occurs within manifestation.
```

## Not secured

```text
All reality is one universal phenomenal subject.
```

## Variables that remain distinct

```text
manifestation
phenomenal ownership
metaphysical selfhood
```

## Serious rivals retained

```text
representational physicalism
illusionism
Buddhist no-self
```

## Scientific function

The argument operates as a category check:

```text
Did the theory explain manifestation,
identify it,
or redefine it away?
```

## Surviving frontier

```text
whether transcendental priority entails ontological
manifestation-monism
```
