# Changelog

## 0.2.0

### Added

- First-class pack types for typography, visual objects, animation,
  transitions, music, sound effects, layouts and backends.
- Deterministic timeline engine.
- Analytic animation engine.
- Semantic visual-object engine with conservation laws.
- Semantic transition engine.
- Frame-rate-independent signal smoothing.
- Typography tokenizer and layout engine.
- Music-form planner and inspectable feature bus.
- Sound-effect planner and absolute cue sheets.
- Pack scaffolding and dynamic runtime loading.
- Seven working expansion-pack examples.
- Expansion laboratory and capability matrix.
- Clean-install npm integration tests.

### Fixed

- Packaging destination creation.
- Runtime registration result visibility.
- Renderer fixture test discovery.

## 0.1.0

- Formalized source locks, argument IR, continuity, candidates, storyboarding,
  typography, timing, signals, render plans and review plans.
- Added MOTHERFUCKER adapter and Essay 3 reference project.
