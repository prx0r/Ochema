# Conversation Work → Formal Package

| Prior work | Formal package location |
|---|---|
| Argument IR | `src/ir/argument-ir.mjs` |
| Visual proof contracts | `src/ir/visual-ir.mjs` |
| Continuity objects | `continuity-planner.mjs` |
| Five-candidate method | `candidate-planner.mjs` |
| Storyboarding | `storyboard-planner.mjs` |
| Typography rules | `typography-planner.mjs` |
| Music/narration routing | `signal-planner.mjs` |
| TTS timing | `timing-planner.mjs` |
| Render orchestration | `render-planner.mjs` |
| Contact-sheet review | `review-planner.mjs` |
| Capability/style/composition packs | registries and templates |
| MOTHERFUCKER integration | `adapters/motherfucker.mjs` |
| Agent workflows | `skills/*/SKILL.md` |
| Essay 3 | `examples/essay-03/` |
| Cloudflare loop | `docs/09-CLOUDFLARE-ORCHESTRATION.md` |
