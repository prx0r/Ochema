# Test Report — v0.2.0

## Executed successfully

```bash
find src test examples fixtures -name '*.mjs' -print0 | xargs -0 -n1 node --check
npm run test:all
npm run test:integration
npm run demo:expansion
npm run pack:local -- /mnt/data/npm-pack-test
npm install /mnt/data/npm-pack-test/prx0r-visionary-engine-0.2.0.tgz
```

## Results

- 21 unit and package tests passed.
- 2 explicit renderer-adapter integration tests passed.
- Essay 3 validated with 9 argument beats.
- Essay 3 compiled into 14 artifacts.
- 7 first-class extension packs loaded and registered.
- Expansion laboratory executed timeline, animation, objects, signals,
  transitions, typography, music, and SFX.
- npm tarball built successfully.
- npm tarball installed into a clean project.
- Installed CLI validated, compiled, scaffolded, and loaded a new pack.
- JavaScript syntax validation passed across source, tests, examples and
  fixtures.

## Bugs found and fixed during testing

1. npm packaging failed when the destination directory did not exist.
   `tools/pack-local.mjs` now creates it.
2. Runtime pack loading discarded the registration result.
   `loadPack()` now returns `registration`.
3. A renderer fixture under `test/` was accidentally discovered as a test.
   Fixtures were moved to a dedicated top-level directory.

## External boundary not executed here

The live GitHub repository could not be cloned because the execution container
has no outbound DNS. Therefore a real Skia/FFmpeg render against the current
repository was not performed in this environment.

The renderer adapter was executed against a contract-complete mock framework.
A live render still requires:

- the current `MOTHERFUCKER` tree;
- `@napi-rs/canvas`;
- registered fonts;
- FFmpeg;
- capability runtime modules;
- optional `edge-tts` and librosa.
