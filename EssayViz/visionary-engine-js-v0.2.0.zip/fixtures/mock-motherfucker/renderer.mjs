export const mock = "renderer.mjs";
