export const mock = "schema.mjs";
