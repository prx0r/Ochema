#!/usr/bin/env node
import { readFile, writeFile, mkdir } from "node:fs/promises";
import { resolve, dirname } from "node:path";
const packPath=resolve(process.argv[2]);
const pack=JSON.parse(await readFile(packPath,"utf8"));
const output=resolve(process.env.MOCK_RENDER_OUTPUT??"build/mock-render.json");
await mkdir(dirname(output),{recursive:true});
await writeFile(output,JSON.stringify({rendered:true,packId:pack.id,sceneCount:pack.scenes.length},null,2)+"\n");
