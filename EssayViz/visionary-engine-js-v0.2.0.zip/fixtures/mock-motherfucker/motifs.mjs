export const mock = "motifs.mjs";
