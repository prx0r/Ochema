# @prx0r/visionary-engine

A formal JavaScript authoring and orchestration layer for the deterministic
Skia framework in `MOTHERFUCKER/`.

It does not replace the renderer. It formalizes the work required before and
around rendering:

```text
essay
→ source lock
→ argument IR
→ continuity plan
→ candidate tournament
→ storyboard
→ typography plan
→ signal plan
→ timed scene program
→ capability-aware render
→ contact-sheet review
→ patch loop
→ TTS/audio mux
```

## Design principle

The renderer answers:

> How is this frame drawn?

This package answers:

> Why must this frame exist, what relation does it perform, which packs does it
> require, how is it timed, and how is it reviewed?

## Install locally

```bash
npm install
npm link
visionary doctor
```

## Compile the included Essay 3 example

```bash
visionary validate examples/essay-03/project.json
visionary compile examples/essay-03/project.json --out build/essay-03
```

The compiler outputs:

- `argument-ir.json`;
- `continuity-plan.json`;
- `candidate-tournament.json`;
- `storyboard.json`;
- `typography-plan.json`;
- `signal-plan.json`;
- `scene-pack.json`;
- `render-plan.json`;
- `review-plan.json`;
- `manifest.json`.

## Render through the existing framework

```bash
visionary render build/essay-03/render-plan.json \
  --framework ../MOTHERFUCKER
```

## Architecture

```text
@prx0r/visionary-engine
├── IR and schemas
├── planners
├── registries
├── validators
├── compiler
├── renderer adapter
├── audio/TTS orchestration
├── review tools
└── agent skills

MOTHERFUCKER
├── Skia kernel
├── motifs
├── capability runtime modules
├── geometry
├── particles
├── materials
├── audio feature sampling
└── FFmpeg frame streaming
```

## Core package types

### Capability pack

What the engine can show.

### Composition profile

Why scenes occur in a particular order.

### Style profile

Global material and presentation constraints.

### Motion profile

How transformation behaves.

### Signal profile

How score, waveform and narration data modulate subordinate parameters.

### Typography profile

How prose, IAST, equations, labels and citations are laid out.

### Backend adapter

How a compiled scene program reaches a renderer.

## Non-goals

- replacing FFmpeg;
- becoming a general nonlinear editor;
- hiding epistemic distinctions;
- generating visuals by noun-to-template matching;
- making audio amplitude control every parameter.

## Extension categories in v0.2

Typography, visual-object, animation, transition, music, sound-effect and layout packs are now first-class. See `docs/10-EXPANSION-PACKS.md` and `examples/expansion-packs/`.
