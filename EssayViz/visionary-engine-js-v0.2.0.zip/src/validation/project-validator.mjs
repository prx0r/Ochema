import { assert, nonEmptyString } from "../core/assert.mjs";
import { SEMANTIC_ROLES, RELATIONS } from "../ir/argument-ir.mjs";
export function validateProject(project) {
  nonEmptyString(project.id,"project.id");
  nonEmptyString(project.title,"project.title");
  assert(Array.isArray(project.beats) && project.beats.length>0,"project.beats must contain at least one beat");
  const ids=new Set();
  for(const beat of project.beats){
    nonEmptyString(beat.id,"beat.id");
    assert(!ids.has(beat.id),`duplicate beat id ${beat.id}`);ids.add(beat.id);
    assert(SEMANTIC_ROLES.includes(beat.semanticRole),`${beat.id}: invalid semanticRole`);
    assert(RELATIONS.includes(beat.relation),`${beat.id}: invalid relation`);
    for(const field of ["incomingBelief","operation","outgoingBelief","invariant","forbiddenInference"]) nonEmptyString(beat[field],`${beat.id}.${field}`);
  }
  return {valid:true,beatCount:project.beats.length};
}
