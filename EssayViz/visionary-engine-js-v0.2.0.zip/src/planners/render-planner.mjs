export function planRender(project, storyboard, timing, signals) {
  return {
    version:"1.0",
    frameworkAdapter:"motherfucker",
    projectId:project.id,
    packPath:"scene-pack.json",
    outputPath:`build/${project.id}/video.mp4`,
    finalPath:`build/${project.id}/final.mp4`,
    audio:{
      narrationPath:`build/${project.id}/narration.mp3`,
      featureManifest:`build/${project.id}/features.json`,
      voice:"en-GB-SoniaNeural"
    },
    render:project.render,
    timing,
    signals,
    commands:{
      tts:"edge-tts",
      analyser:"python3 tools/analyse-audio.py",
      renderer:"node tools/render-pack.mjs",
      mux:"ffmpeg"
    }
  };
}
