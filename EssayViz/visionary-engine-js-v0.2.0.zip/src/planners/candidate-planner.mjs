const CANDIDATE_KINDS=["notation","graph-topology","field-dynamical","embodied-domain","unconventional"];
export function planCandidates(argumentIR) {
  return {
    version:"1.0",
    beats: argumentIR.beats.map(beat=>({
      beatId:beat.id,
      relation:beat.relation,
      candidates:CANDIDATE_KINDS.map((kind,index)=>({
        id:`${beat.id}-${kind}`,
        kind,
        topology:suggestTopology(beat.relation,kind),
        decisiveMutation:suggestMutation(beat.operation,kind),
        invariant:beat.invariant,
        forbiddenInference:beat.forbiddenInference,
        scores:{
          relationFidelity:index===0?82:74,
          motionProof:index===2?85:76,
          domainMatch:index===3?82:70,
          continuityHandoff:75,
          silentLegibility:index===0?88:72,
          novelty:index===4?90:68,
          epistemicRestraint:82
        },
        status:index===0?"provisional":"candidate"
      }))
    }))
  };
}
function suggestTopology(relation,kind){
  const map={
    "notation":"typed nodes, semantic edges and scope brackets",
    "graph-topology":"graph, lattice or connected component",
    "field-dynamical":"continuous field, trajectories or attractor",
    "embodied-domain":"domain-specific anatomy or agent organization",
    "unconventional":"observer-dependent camera, material process or spatial counterpoint"
  };
  return `${map[kind]} adapted to ${relation}`;
}
function suggestMutation(operation,kind){ return `${operation} performed through ${kind}`; }
