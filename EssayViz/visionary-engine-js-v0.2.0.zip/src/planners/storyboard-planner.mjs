export function planStoryboard(project, argumentIR, candidates) {
  return {
    version:"1.0",
    compositionProfile:project.compositionProfile,
    scenes:argumentIR.beats.map((beat,index)=>{
      const tournament=candidates.beats.find(x=>x.beatId===beat.id);
      const selected=tournament.candidates.find(x=>x.status==="provisional");
      return {
        id:`sc-${String(index+1).padStart(2,"0")}`,
        beatId:beat.id,
        title:beat.sourceSection,
        subtitle:beat.outgoingBelief,
        incomingBelief:beat.incomingBelief,
        operation:beat.operation,
        outgoingBelief:beat.outgoingBelief,
        relation:beat.relation,
        invariant:beat.invariant,
        forbiddenInference:beat.forbiddenInference,
        selectedCandidate:selected.id,
        visualContract:{
          topology:selected.topology,
          decisiveMutation:selected.decisiveMutation,
          motif:chooseMotif(selected.kind),
          capabilities:project.capabilities,
          styleProfile:project.styleProfile
        }
      };
    })
  };
}
function chooseMotif(kind){
  if(kind==="notation") return "argument-diagram-v2";
  if(kind==="embodied-domain") return "semantic-essay";
  return "composition";
}
