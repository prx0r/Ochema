import { access } from "node:fs/promises";
import { join, resolve } from "node:path";
import { spawn } from "node:child_process";
import { VisionaryError } from "../core/errors.mjs";

export async function inspectMotherfucker(root) {
  const required=["renderer.mjs","motifs.mjs","schema.mjs","tools/render-pack.mjs"];
  const missing=[];
  for(const file of required){
    try{await access(join(resolve(root),file));}catch{missing.push(file);}
  }
  return {root:resolve(root),valid:missing.length===0,missing};
}
export async function runMotherfuckerRender(renderPlan,{frameworkRoot,dryRun=false}={}) {
  const root=resolve(frameworkRoot);
  const inspection=await inspectMotherfucker(root);
  if(!inspection.valid) throw new VisionaryError("Invalid MOTHERFUCKER framework root",{details:inspection});
  const args=[join(root,"tools/render-pack.mjs"),resolve(renderPlan.packPath)];
  if(dryRun) return {command:process.execPath,args,cwd:root};
  return new Promise((resolvePromise,reject)=>{
    const child=spawn(process.execPath,args,{cwd:root,stdio:"inherit"});
    child.on("exit",code=>code===0?resolvePromise({code}):reject(new VisionaryError(`renderer exited ${code}`)));
  });
}
