import { pathToFileURL } from "node:url";
import { resolve } from "node:path";
import { readJson } from "../core/fs.mjs";
import { validatePackManifest } from "./pack-validator.mjs";
import {
  capabilityRegistry, compositionRegistry, styleRegistry, motionRegistry,
  signalRegistry, typographyRegistry, objectRegistry, animationRegistry,
  transitionRegistry, musicRegistry, soundEffectRegistry, layoutRegistry
} from "../registries/index.mjs";

const registryByType={
  capability:capabilityRegistry,composition:compositionRegistry,style:styleRegistry,
  motion:motionRegistry,signal:signalRegistry,typography:typographyRegistry,
  "visual-object":objectRegistry,animation:animationRegistry,transition:transitionRegistry,
  music:musicRegistry,"sound-effect":soundEffectRegistry,layout:layoutRegistry
};
export async function loadPack(path,{loadRuntime=true}={}) {
  const full=resolve(path);
  const pack=await readJson(full);
  validatePackManifest(pack);
  registryByType[pack.type]?.register(pack.id,{...pack,manifestPath:full});
  let runtime=null;
  let registration=null;
  if(loadRuntime && pack.runtimeModule){
    const runtimePath=resolve(full,"..",pack.runtimeModule);
    runtime=await import(pathToFileURL(runtimePath).href);
    if(typeof runtime.register==="function") registration=await runtime.register({pack});
  }
  return {pack,runtime,registration};
}
