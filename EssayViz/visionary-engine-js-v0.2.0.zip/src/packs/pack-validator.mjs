import { assert, nonEmptyString } from "../core/assert.mjs";
import { PACK_TYPES } from "./pack-types.mjs";
export function validatePackManifest(pack) {
  nonEmptyString(pack.id,"pack.id");
  assert(PACK_TYPES.includes(pack.type),`unsupported pack type ${pack.type}`);
  assert(typeof pack.provides==="object" && pack.provides!==null,"pack.provides must be an object");
  if(pack.runtimeModule!==null) nonEmptyString(pack.runtimeModule,"pack.runtimeModule");
  return {valid:true,id:pack.id,type:pack.type};
}
