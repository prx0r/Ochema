export const SEMANTIC_ROLES = Object.freeze([
  "hook","contention","definition","premise","mechanism","identity",
  "analogy","objection","rival","discriminator","consequence",
  "framework-update","recognition","frontier","coda"
]);
export const RELATIONS = Object.freeze([
  "identity","dependency","containment","selection","sequence","feedback",
  "transformation","cessation","self-modification","coordination",
  "differentiation","equivalence","compression","coupling","exclusion",
  "competition","bifurcation","history-dependence","bridge-failure","participation"
]);
export function createArgumentBeat(input) {
  return {
    id: input.id,
    sourceSection: input.sourceSection,
    semanticRole: input.semanticRole,
    incomingBelief: input.incomingBelief,
    operation: input.operation,
    outgoingBelief: input.outgoingBelief,
    relation: input.relation,
    invariant: input.invariant,
    likelyMisreading: input.likelyMisreading,
    forbiddenInference: input.forbiddenInference,
    evidenceStatus: input.evidenceStatus ?? "unknown",
    text: input.text ?? "",
  };
}
export function createArgumentIR({ title, beats }) {
  return { version: "1.0", title, beats: beats.map(createArgumentBeat) };
}
