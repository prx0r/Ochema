import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { inspectMotherfucker, runMotherfuckerRender } from "../../src/adapters/motherfucker.mjs";

const framework=resolve("fixtures/mock-motherfucker");

test("doctor recognizes complete framework contract",async()=>{
  const result=await inspectMotherfucker(framework);
  assert.equal(result.valid,true);
});

test("adapter executes capability-aware renderer",async()=>{
  const dir=await mkdtemp(join(tmpdir(),"visionary-render-"));
  const pack=join(dir,"pack.json"),out=join(dir,"render.json");
  await writeFile(pack,JSON.stringify({id:"integration",scenes:[{},{}]}));
  process.env.MOCK_RENDER_OUTPUT=out;
  try{
    await runMotherfuckerRender({packPath:pack},{frameworkRoot:framework});
    const result=JSON.parse(await readFile(out,"utf8"));
    assert.deepEqual(result,{rendered:true,packId:"integration",sceneCount:2});
  }finally{
    delete process.env.MOCK_RENDER_OUTPUT;
    await rm(dir,{recursive:true,force:true});
  }
});
