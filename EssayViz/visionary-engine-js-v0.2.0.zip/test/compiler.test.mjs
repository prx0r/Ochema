import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { compileProject } from "../src/compiler/project-compiler.mjs";

const project=JSON.parse(await readFile(new URL("../examples/essay-03/project.json",import.meta.url),"utf8"));

test("compiles all planning artifacts",()=>{
  const result=compileProject(project);
  for(const key of ["argumentIR","continuity","candidates","storyboard","typography","signals","timing","scenePack","renderPlan","reviewPlan"]) assert.ok(result[key]);
});

test("scene count follows argument beats",()=>{
  const result=compileProject(project);
  assert.equal(result.scenePack.scenes.length,project.beats.length);
  assert.equal(result.storyboard.scenes.length,project.beats.length);
});

test("timing is monotonic",()=>{
  const result=compileProject(project);
  let previous=0;
  for(const scene of result.timing.scenes){
    assert.equal(scene.start,previous);
    assert.ok(scene.end>scene.start);
    previous=scene.end;
  }
});

test("compiled pack preserves capabilities",()=>{
  const result=compileProject(project);
  assert.deepEqual(result.scenePack.capabilityPacks,project.capabilities);
});
