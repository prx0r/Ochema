import test from "node:test";
import assert from "node:assert/strict";
import { makeRng, stableId } from "../src/core/determinism.mjs";

test("rng is deterministic",()=>{
  const a=makeRng(42),b=makeRng(42);
  assert.deepEqual([a(),a(),a()],[b(),b(),b()]);
});
test("stable id is stable",()=>assert.equal(stableId("x","hello"),stableId("x","hello")));
