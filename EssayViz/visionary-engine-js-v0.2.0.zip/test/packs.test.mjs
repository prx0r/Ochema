import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { validatePackManifest, scaffoldPack, loadPack } from "../src/packs/index.mjs";

test("all example extension packs validate and load",async()=>{
  const ids=["precision-typography","continuity-objects","advanced-animation","semantic-transitions","music-forms","cinematic-sfx","editorial-layouts"];
  for(const id of ids){
    const path=new URL(`../examples/expansion-packs/${id}/pack.json`,import.meta.url);
    const manifest=JSON.parse(await readFile(path,"utf8"));
    assert.equal(validatePackManifest(manifest).valid,true);
    const loaded=await loadPack(path.pathname);
    assert.equal(loaded.pack.id,id);
    assert.equal(loaded.registration.registered,true);
  }
});

test("scaffolder creates loadable pack",async()=>{
  const dir=await mkdtemp(join(tmpdir(),"visionary-"));
  try{
    const root=await scaffoldPack({directory:dir,id:"test-pack",type:"animation"});
    const loaded=await loadPack(join(root,"pack.json"));
    assert.equal(loaded.pack.type,"animation");
  }finally{await rm(dir,{recursive:true,force:true});}
});
