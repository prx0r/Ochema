import test from "node:test";
import assert from "node:assert/strict";
import { TypographyLayoutEngine, tokenizeNotation } from "../src/typography/index.mjs";
import { planMusic, planSoundEffects, compileCueSheet } from "../src/audio/index.mjs";

test("notation tokenizer separates math and prose",()=>{
  const tokens=tokenizeNotation("The bridge D_i ⇏ M remains open");
  assert.ok(tokens.some(x=>x.type==="math"));
  assert.ok(tokens.some(x=>x.type==="prose"));
});

test("typography engine lays out blocks without overlap",()=>{
  const e=new TypographyLayoutEngine({minimumBodyPx:14});
  const blocks=e.layout([{id:"a",text:"A concise philosophical claim."},{id:"b",text:"A second explanatory block."}]);
  assert.ok(blocks[1].y>blocks[0].y+blocks[0].height);
});

test("music planner exposes formal feature bus",()=>{
  const p=planMusic({form:"passacaglia",thesis:"identity through change",continuityObject:"seed",stages:["opening","transfer"]});
  assert.ok(p.featureBus.includes("carrierTransfer"));
});

test("sfx plan compiles to absolute cue times",()=>{
  const storyboard={scenes:[{id:"s1",operation:"split field"}]};
  const timing={duration:5,scenes:[{sceneId:"s1",start:2}]};
  const sfx=planSoundEffects(storyboard);
  const sheet=compileCueSheet({timing,music:{},sfx});
  assert.equal(sheet.sfx.cues[0].time,2);
});
