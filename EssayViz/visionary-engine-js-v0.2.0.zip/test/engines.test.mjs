import test from "node:test";
import assert from "node:assert/strict";
import {
  TimelineEngine, AnimationEngine, VisualObjectEngine, createTransition,
  validateTransition, SignalEngine
} from "../src/engines/index.mjs";

test("timeline supports random access",()=>{
  const t=new TimelineEngine({duration:10,events:[{id:"a",time:2,end:6},{id:"b",time:8}]});
  assert.deepEqual(t.at(4).active.map(x=>x.id),["a"]);
  assert.equal(t.at(9).previous.id,"b");
  assert.equal(t.validate().valid,true);
});

test("animation interpolates deterministic values",()=>{
  const e=new AnimationEngine([{target:"x",start:0,duration:10,from:0,to:100,easing:"linear"}]);
  assert.equal(e.sample(5).x,50);
});

test("visual objects preserve semantic contracts",()=>{
  const e=new VisualObjectEngine();
  const o=e.instantiate("seed",{scale:1},{meaning:"identity",conserved:["lobes"]});
  e.transform(o.id,{scale:2});
  assert.equal(e.snapshot()[0].semantic.conserved[0],"lobes");
  assert.equal(e.snapshot()[0].props.scale,2);
});

test("semantic transitions validate",()=>{
  const t=createTransition({verb:"split",from:"one",to:"two",invariant:"carrier",duration:2});
  assert.equal(validateTransition(t).valid,true);
});

test("signal smoothing is stable",()=>{
  const s=new SignalEngine([{source:"rms",target:"glow",attack:.1,release:.5,range:[0,10]}]);
  const a=s.sample({rms:0},1/60).glow;
  const b=s.sample({rms:1},1/60).glow;
  assert.ok(b>a&&b<10);
});
