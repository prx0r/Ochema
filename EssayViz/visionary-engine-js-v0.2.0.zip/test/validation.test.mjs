import test from "node:test";
import assert from "node:assert/strict";
import { validateProject } from "../src/validation/project-validator.mjs";

test("rejects invalid relation",()=>{
  const project={id:"x",title:"x",beats:[{
    id:"b",sourceSection:"s",semanticRole:"premise",incomingBelief:"a",
    operation:"change",outgoingBelief:"b",relation:"not-real",
    invariant:"i",forbiddenInference:"f"
  }]};
  assert.throws(()=>validateProject(project));
});
