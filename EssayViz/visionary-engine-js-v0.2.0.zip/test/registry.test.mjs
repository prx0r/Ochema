import test from "node:test";
import assert from "node:assert/strict";
import { Registry } from "../src/registries/registry.mjs";

test("registry prevents accidental overwrite",()=>{
  const r=new Registry("test");
  r.register("x",{value:1});
  assert.throws(()=>r.register("x",{value:2}));
  assert.equal(r.get("x").value,1);
});
