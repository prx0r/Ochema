#!/usr/bin/env node
import { mkdir } from "node:fs/promises";
import { spawn } from "node:child_process";
import { resolve } from "node:path";
const destination=resolve(process.argv[2]??"dist");
await mkdir(destination,{recursive:true});
const child=spawn("npm",["pack","--pack-destination",destination],{stdio:"inherit"});
child.on("exit",code=>process.exit(code??1));
