# Creation and Verification Notes

## Design boundary

This package separates:

1. conventional mathematical geometry;
2. Fuller-defined mensuration and interpretation;
3. numerical mechanism prototypes;
4. engineering scaffolds;
5. future source-calibrated implementations.

That separation is encoded in object metadata and documentation.

## Implementation order

1. Build deterministic vector/matrix math.
2. Build a renderer-independent mesh object.
3. Generate canonical solids from coordinates.
4. Derive edges from faces and validate topology.
5. Add Euclidean area/volume and Fuller tetravolume as separate fields.
6. Generate the FCC/IVM lattice and verify one interior node has twelve equal
   neighbors.
7. Implement triangular frequency subdivision and spherical projection.
8. Generate the tetrahelix by reflecting the previous apex across an attached
   face.
9. Build a generic distance-constraint projector.
10. Use it for a handed, continuously contracting jitterbug prototype.
11. Add dynamic-relaxation tensegrity scaffolding.
12. Build an SVG projection backend so every subsystem can be visually inspected.
13. Generate a demo contact sheet and inspect it.
14. Add regression tests and capability manifests.

## Jitterbug decisions

The implementation does not interpolate from a cuboctahedron to a target
polyhedron.

It:

- begins with the vector equilibrium triangular faces;
- extracts all edges belonging to those faces;
- applies a shrinking/twisting phase target;
- repeatedly projects the result back onto fixed-length edge constraints;
- reports maximum edge error and enclosed volume.

This is a useful mechanism prototype, but not the completed canonical Fuller
jitterbug. Publication labels such as “icosahedral phase” or “octahedral phase”
are prohibited until explicit geometric conditions identify them.

## Visual inspection

The generated contact sheet was inspected.

### Passed

- canonical solids are visually distinct;
- VE triangular and square faces are visible;
- VE radials are visible;
- geodesic frequency-three subdivision is legible;
- IVM reads as an omnidirectional equal-vector lattice;
- tetrahelix face adjacency is visible;
- jitterbug contraction changes volume and orientation across phases.

### Failed or incomplete

- late jitterbug phases show edge crossings because coincident-edge groups are
  not collapsed or reclassified;
- the current SVG projection has no hidden-line removal;
- equal-edge normalization makes small solids occupy less frame area than the
  geodesic and IVM demonstrations;
- tensegrity is numerically tested but not yet included in the SVG demo;
- great circles and A/B/T/E modules are not implemented.

## Release rule

The package is a valid foundation pack.

It is not a complete claim that every component of Synergetics has been
implemented. Roadmapped systems remain visibly marked as future work.
