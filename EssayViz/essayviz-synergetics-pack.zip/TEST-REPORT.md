# Test Report

Executed:

```bash
npm test
npm run validate
npm run demo
```

## Automated result

```text
11 tests passed
4 canonical meshes valid
IVM origin has 12 equal neighbors
geodesic F3 has 180 triangular faces
tetrahelix boundary mesh valid
jitterbug sampled at 11 phases
jitterbug maximum tested edge error < 0.002
left/right jitterbug states differ
Fuller VE tetravolume test passed
tensegrity solver returns finite force state
```

## Validation metrics

Unit-edge conventional volumes:

```text
tetrahedron        0.1178511302
octahedron         0.4714045208
icosahedron        2.1816949906
vector equilibrium 2.3570226040
```

Fuller-defined VE tetravolume at frequency 1:

```text
20
```

These numbers are intentionally reported in separate systems.

## Tensegrity status

The example solver returns:

- struts in compression;
- cables in tension;
- finite residual.

The default run did not reach the strict convergence tolerance. It is a
functional relaxation scaffold, not engineering certification.
