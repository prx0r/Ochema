---
name: synergetics-geometry-director
description: Convert a Fuller/Synergetics passage into source-linked, constraint-preserving geometry rather than decorative polyhedron footage.
version: 1.0
---

# Synergetics Geometry Director

## Prime rule

Never illustrate a Synergetics noun when the source specifies a geometric
operation.

## Required source contract

For every passage produce:

```json
{
  "sourceClaim": "",
  "sourceSection": "",
  "epistemicStatus": "conventional-mathematics|fuller-defined-formalism|physical-model-observation|engineering-application|metaphorical-extension|speculative-physical-claim",
  "geometricOperation": "",
  "canonicalObjects": [],
  "normalization": "",
  "constraints": [],
  "invariants": [],
  "changingParameters": [],
  "requiredMeasurements": [],
  "cameraStrategy": "",
  "annotationStrategy": "",
  "transitionLaw": "",
  "forbiddenVisualInference": ""
}
```

## Object selection

Use exact generated objects:

- tetrahedron;
- octahedron;
- icosahedron;
- vector equilibrium;
- local IVM neighborhood;
- geodesic subdivision;
- tetrahelix;
- tensegrity system.

Do not trace screenshots.

## Normalization

Always declare one:

- common edge;
- common circumradius;
- common center;
- closest-packing sphere radius;
- Fuller tetravolume.

Concentric appearance without a normalization is not an explanation.

## Jitterbug

Require:

- rigid triangular edge constraints;
- hinge connectivity;
- handedness;
- phase parameter;
- edge-error report;
- volume report.

Do not call a linear coordinate interpolation “the jitterbug.”

The included implementation is a numerical mechanism prototype. Canonical
icosahedral, octahedral and tetrahedral phase labels require source-calibrated
conditions before publication.

## Measurements

Every scene should expose whichever are relevant:

- vertex/edge/face counts;
- Euler characteristic;
- edge error;
- face planarity;
- radius;
- Euclidean volume;
- Fuller-defined tetravolume;
- frequency;
- coordination number;
- residual force.

## Epistemic restraint

Show Fuller’s formal accounting alongside conventional mathematics rather than
silently replacing it.

Do not infer cosmology, consciousness or physical law from geometric elegance.

## Review gates

- exact coordinates;
- deterministic output;
- uniform edges within tolerance;
- transformations preserve declared constraints;
- camera does not hide the operation;
- source claim and mathematical result remain distinguished;
- labels name changing quantities only;
- no arbitrary spinning solid substitutes for a construction.
