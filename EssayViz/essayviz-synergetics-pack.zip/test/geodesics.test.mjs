import test from "node:test";
import assert from "node:assert/strict";
import { createGeodesicIcosahedron,createTetrahelix,validateMesh } from "../src/index.mjs";

test("frequency three geodesic is watertight",()=>{
  const mesh=createGeodesicIcosahedron({frequency:3,radius:1});
  const r=validateMesh(mesh);
  assert.equal(r.valid,true,r.errors.join("\n"));
  assert.equal(r.metrics.F,20*9);
});
test("tetrahelix boundary is a valid closed mesh",()=>{
  const mesh=createTetrahelix({count:8});
  const r=validateMesh(mesh);
  assert.equal(r.valid,true,r.errors.join("\n"));
});
