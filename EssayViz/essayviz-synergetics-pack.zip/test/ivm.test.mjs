import test from "node:test";
import assert from "node:assert/strict";
import { createIVM,localVectorEquilibrium } from "../src/index.mjs";

test("interior IVM node has twelve equal neighbors",()=>{
  const ivm=createIVM({radius:3,edgeLength:1});
  const origin=ivm.nodes.find(n=>n.lattice.every(x=>x===0));
  const local=localVectorEquilibrium(ivm,origin.id);
  assert.equal(local.valid,true);
  assert.equal(local.neighbors.length,12);
  for(const d of local.distances)assert.ok(Math.abs(d-1)<1e-9);
});
