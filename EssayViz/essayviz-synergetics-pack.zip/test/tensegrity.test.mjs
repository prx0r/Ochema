import test from "node:test";
import assert from "node:assert/strict";
import { createSimplexTensegrity,solveTensegrity,memberForces } from "../src/index.mjs";
test("simplex tensegrity solver returns finite state",()=>{
  const system=createSimplexTensegrity(),result=solveTensegrity(system,{iterations:500});
  assert.ok(Number.isFinite(result.residual));
  for(const p of result.positions)for(const v of [p.x,p.y,p.z])assert.ok(Number.isFinite(v));
  const forces=memberForces(system,result.positions);
  assert.equal(forces.length,system.members.length);
});
