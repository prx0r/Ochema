import test from "node:test";
import assert from "node:assert/strict";
import { fullerVectorEquilibriumTetravolume } from "../src/index.mjs";
test("Fuller VE tetravolume follows 20F cubed",()=>{
  assert.equal(fullerVectorEquilibriumTetravolume(1),20);
  assert.equal(fullerVectorEquilibriumTetravolume(3),540);
});
