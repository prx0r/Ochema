import test from "node:test";
import assert from "node:assert/strict";
import { createTetrahedron,createOctahedron,createIcosahedron,createVectorEquilibrium,validateMesh } from "../src/index.mjs";

for(const [name,make,counts] of [
  ["tetrahedron",createTetrahedron,[4,6,4]],
  ["octahedron",createOctahedron,[6,12,8]],
  ["icosahedron",createIcosahedron,[12,30,20]],
  ["vector equilibrium",createVectorEquilibrium,[12,24,14]]
]){
  test(`${name} exact topology and uniform edges`,()=>{
    const mesh=make({edgeLength:1}),r=validateMesh(mesh,{requireUniformEdges:true,edgeTolerance:1e-7});
    assert.equal(r.valid,true,r.errors.join("\n"));
    assert.deepEqual([r.metrics.V,r.metrics.E,r.metrics.F],counts);
    assert.equal(r.metrics.chi,2);
    assert.ok(Math.abs(r.metrics.edgeMin-1)<1e-7);
    assert.ok(Math.abs(r.metrics.edgeMax-1)<1e-7);
  });
}
