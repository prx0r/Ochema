import test from "node:test";
import assert from "node:assert/strict";
import { createJitterbug } from "../src/index.mjs";

test("numerical jitterbug preserves triangle edges within tolerance",()=>{
  const j=createJitterbug({edgeLength:1,handedness:"right"});
  const samples=j.sample(11);
  for(const s of samples)assert.ok(s.maxEdgeError<2e-3,`phase ${s.phase}: ${s.maxEdgeError}`);
  assert.ok(samples.at(-1).volume<samples[0].volume);
});
test("left and right contractions diverge in orientation",()=>{
  const l=createJitterbug({handedness:"left"}).solvePhase(.6);
  const r=createJitterbug({handedness:"right"}).solvePhase(.6);
  assert.notDeepEqual(l.mesh.vertices,r.mesh.vertices);
});
