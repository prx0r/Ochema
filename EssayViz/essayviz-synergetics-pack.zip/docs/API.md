# API Examples

```js
import {
  createVectorEquilibrium,
  createIVM,
  localVectorEquilibrium,
  createJitterbug,
  createGeodesicIcosahedron,
  createTetrahelix,
  validateMesh,
  meshToSvg
} from "@prx0r/essayviz-synergetics";

const ve=createVectorEquilibrium({edgeLength:1});
console.log(validateMesh(ve,{requireUniformEdges:true}));

const ivm=createIVM({radius:3});
console.log(localVectorEquilibrium(ivm, ivm.nodes.find(n=>n.lattice.join(",")==="0,0,0").id));

const jitterbug=createJitterbug({handedness:"right"});
const phase=jitterbug.solvePhase(.55);
console.log(phase.maxEdgeError,phase.volume);

const geo=createGeodesicIcosahedron({frequency:4,radius:1});
const helix=createTetrahelix({count:20});

const svg=meshToSvg(ve,{radials:true});
```
