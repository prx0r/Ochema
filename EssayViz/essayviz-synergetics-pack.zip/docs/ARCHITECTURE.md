# Architecture

```text
EssayViz rhetorical operation
→ Synergetics source contract
→ canonical geometry object
→ normalization
→ constraints and invariants
→ numerical or analytic transformation
→ measurement report
→ 3D/SVG geometry layer
→ Skia annotation layer
→ review frames
```

## Implemented

- vector and matrix math;
- mesh topology and validation;
- regular tetrahedron, octahedron, icosahedron, cube and vector equilibrium;
- Euclidean area and volume;
- Fuller vector-equilibrium tetravolume accounting;
- FCC/IVM lattice generation;
- local twelve-neighbor vector equilibrium;
- triangular frequency subdivision;
- geodesic icosahedron;
- tetrahelix;
- distance-constraint solver;
- numerical jitterbug mechanism prototype;
- tensegrity dynamic relaxation;
- SVG projection and demos.

## Explicitly scaffolded, not falsely completed

- source-calibrated canonical jitterbug phase detection;
- complete A/B/T/E module coordinate library;
- full great-circle family registry;
- class I/II/III geodesic strut taxonomy;
- production WebGPU renderer;
- industrial tensegrity solver and engineering certification.
