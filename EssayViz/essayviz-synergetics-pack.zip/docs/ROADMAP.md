# Roadmap

## Phase 1 complete

Certified base solids, topology validation, IVM, frequency subdivision,
tetrahelix, SVG demos and numerical mechanism infrastructure.

## Phase 2

- calibrate jitterbug canonical phases from explicit geometric conditions;
- preserve face/edge identity through coincidence;
- plot volume and diagonals through phase;
- add left/right phase comparison.

## Phase 3

- exact A/B/T/E module coordinates;
- module fold nets;
- all-space filling assembly;
- mite and syte compounds.

## Phase 4

- great-circle families;
- spherical projection;
- symmetry-axis registry;
- railroad-track unfolding.

## Phase 5

- class I/II/III geodesics;
- chord factors;
- strut classes;
- dome cuts and assembly instructions.

## Phase 6

- WebGPU/Three backend;
- rigid-body hinge solver;
- force-density and nonlinear tensegrity solvers;
- Skia annotation compositor;
- source-linked film exemplars.
