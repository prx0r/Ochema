import { createVectorEquilibrium } from "../geometry/polyhedra.mjs";
import { deriveEdges, makeMesh, volume } from "../geometry/mesh.mjs";
import { rotateZ, scale, v3 } from "../math/vec3.mjs";
import { projectDistanceConstraints, maxConstraintError } from "./constraints.mjs";

function triangularFaces(mesh){ return mesh.faces.filter(f=>f.length===3); }
function triangleEdgeConstraints(mesh){
  const edges=deriveEdges(triangularFaces(mesh));
  return edges.map(([a,b])=>({a,b,length:mesh.metadata.edgeLength??1}));
}
function vertexBands(vertices){
  const sorted=[...vertices.keys()].sort((a,b)=>vertices[a].z-vertices[b].z);
  return {lower:new Set(sorted.slice(0,3)),upper:new Set(sorted.slice(-3)),equator:new Set(sorted.slice(3,-3))};
}
export function createJitterbug({edgeLength=1,handedness="right"}={}){
  const base=createVectorEquilibrium({edgeLength});
  base.metadata.edgeLength=edgeLength;
  const constraints=triangleEdgeConstraints(base),bands=vertexBands(base.vertices);
  return {
    id:`jitterbug-${handedness}`,
    handedness,edgeLength,base,constraints,bands,
    solvePhase(phase,{iterations=160,stiffness=.92}={}){
      const t=Math.max(0,Math.min(1,phase)),sign=handedness==="left"?-1:1;
      const target=base.vertices.map((p,i)=>{
        const polar=bands.upper.has(i)||bands.lower.has(i);
        const zScale=1-.70*t;
        const radialScale=1-.34*t;
        const twist=sign*(polar?0:.68*t);
        const q=rotateZ(v3(p.x*radialScale,p.y*radialScale,p.z*zScale),twist);
        return q;
      });
      const points=projectDistanceConstraints(target,constraints,{iterations,stiffness});
      const mesh=makeMesh({id:`jitterbug-phase-${t.toFixed(3)}`,name:"Numerical Jitterbug Phase",vertices:points,faces:triangularFaces(base),metadata:{
        phase:t,handedness,epistemicStatus:"numerical constraint-preserving mechanism prototype",
        warning:"Canonical phase identities require source-specific calibration."
      }});
      return {mesh,phase:t,maxEdgeError:maxConstraintError(points,constraints),volume:volume(mesh)};
    },
    sample(count=21){return Array.from({length:count},(_,i)=>this.solvePhase(i/(count-1)));}
  };
}
