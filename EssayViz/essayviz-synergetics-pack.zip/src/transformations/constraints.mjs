import { add, sub, scale, distance } from "../math/vec3.mjs";

export function projectDistanceConstraints(points,constraints,{iterations=80,stiffness=.85,pinned=new Set()}={}){
  const out=points.map(p=>({...p}));
  for(let it=0;it<iterations;it++){
    for(const c of constraints){
      const a=out[c.a],b=out[c.b],d=distance(a,b)||1e-12;
      const error=(d-c.length)/d;
      const corr=scale(sub(b,a),.5*stiffness*error);
      if(!pinned.has(c.a))out[c.a]=add(out[c.a],corr);
      if(!pinned.has(c.b))out[c.b]=sub(out[c.b],corr);
    }
  }
  return out;
}
export function maxConstraintError(points,constraints){
  return Math.max(0,...constraints.map(c=>Math.abs(distance(points[c.a],points[c.b])-c.length)));
}
