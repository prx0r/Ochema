import { add, scale, normalize } from "../math/vec3.mjs";
import { makeMesh, orientFacesOutward } from "../geometry/mesh.mjs";
import { createIcosahedron } from "../geometry/polyhedra.mjs";

export function subdivideTriangle(a,b,c,frequency){
  if(!Number.isInteger(frequency)||frequency<1)throw new Error("frequency must be positive integer");
  const points=[],index=new Map(),faces=[];
  const key=(i,j)=>`${i},${j}`;
  for(let i=0;i<=frequency;i++)for(let j=0;j<=frequency-i;j++){
    const k=frequency-i-j;
    const p=scale(add(add(scale(a,i),scale(b,j)),scale(c,k)),1/frequency);
    index.set(key(i,j),points.length);points.push(p);
  }
  for(let i=0;i<frequency;i++)for(let j=0;j<frequency-i;j++){
    const p0=index.get(key(i,j)),p1=index.get(key(i+1,j)),p2=index.get(key(i,j+1));
    faces.push([p0,p1,p2]);
    if(j<frequency-i-1){
      const p3=index.get(key(i+1,j+1));
      faces.push([p1,p3,p2]);
    }
  }
  return {points,faces};
}
export function createGeodesicIcosahedron({frequency=2,radius=1}={}){
  const base=createIcosahedron({edgeLength:1}),vertices=[],faces=[],dedup=new Map();
  const quant=p=>`${Math.round(p.x*1e9)},${Math.round(p.y*1e9)},${Math.round(p.z*1e9)}`;
  for(const face of base.faces){
    const sub=subdivideTriangle(base.vertices[face[0]],base.vertices[face[1]],base.vertices[face[2]],frequency);
    const map=[];
    for(const p of sub.points){
      const q=scale(normalize(p),radius),k=quant(q);
      if(!dedup.has(k)){dedup.set(k,vertices.length);vertices.push(q);}
      map.push(dedup.get(k));
    }
    for(const f of sub.faces)faces.push(f.map(i=>map[i]));
  }
  return orientFacesOutward(makeMesh({id:`geodesic-icosahedron-f${frequency}`,name:`Frequency ${frequency} Geodesic Icosahedron`,vertices,faces,metadata:{frequency,radius,epistemicStatus:"conventional geodesic subdivision"}}));
}
