import { v3, add, sub, scale, dot, cross, normalize } from "../math/vec3.mjs";
import { makeMesh } from "../geometry/mesh.mjs";
import { createTetrahedron } from "../geometry/polyhedra.mjs";

function reflectAcrossFace(p,a,b,c){
  const n=normalize(cross(sub(b,a),sub(c,a)));
  const d=dot(sub(p,a),n);
  return sub(p,scale(n,2*d));
}
export function createTetrahelix({count=8,edgeLength=1}={}){
  if(count<1)throw new Error("count must be >=1");
  const tetra=createTetrahedron({edgeLength}),vertices=tetra.vertices.map(p=>({...p})),cells=[[0,1,2,3]];
  let face=[1,2,3],opposite=0;
  for(let t=1;t<count;t++){
    const newPoint=reflectAcrossFace(vertices[opposite],vertices[face[0]],vertices[face[1]],vertices[face[2]]);
    const ni=vertices.length;vertices.push(newPoint);cells.push([...face,ni]);
    opposite=face[0];face=[face[1],face[2],ni];
  }
  const faces=[];
  for(const cell of cells){
    const fs=[[cell[0],cell[1],cell[2]],[cell[0],cell[3],cell[1]],[cell[0],cell[2],cell[3]],[cell[1],cell[3],cell[2]]];
    for(const f of fs){
      const key=[...f].sort((a,b)=>a-b).join(":");
      const existing=faces.findIndex(x=>x.key===key);
      if(existing>=0)faces.splice(existing,1);else faces.push({key,face:f});
    }
  }
  return makeMesh({id:`tetrahelix-${count}`,name:`Tetrahelix ${count}`,vertices,faces:faces.map(x=>x.face),metadata:{count,edgeLength,epistemicStatus:"conventional Boerdijk-Coxeter tetrahelix"}});
}
