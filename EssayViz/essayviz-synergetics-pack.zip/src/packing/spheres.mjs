import { createVectorEquilibrium } from "../geometry/polyhedra.mjs";
export function twelveAroundOne({sphereRadius=.5}={}){
  const ve=createVectorEquilibrium({edgeLength:2*sphereRadius});
  return {
    center:{id:"center",position:{x:0,y:0,z:0},radius:sphereRadius},
    neighbors:ve.vertices.map((position,id)=>({id:`n${id}`,position,radius:sphereRadius})),
    hull:ve,
    metadata:{epistemicStatus:"conventional closest-packing local configuration + Fuller interpretation"}
  };
}
