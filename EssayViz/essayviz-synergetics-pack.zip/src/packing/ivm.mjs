import { v3, distance } from "../math/vec3.mjs";

export const IVM_NEIGHBOR_OFFSETS=[
  [1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0],
  [1,0,1],[1,0,-1],[-1,0,1],[-1,0,-1],
  [0,1,1],[0,1,-1],[0,-1,1],[0,-1,-1]
];

export function createIVM({radius=2,edgeLength=1,crop="sphere"}={}){
  const scale=edgeLength/Math.sqrt(2),nodes=[],index=new Map();
  for(let i=-radius;i<=radius;i++)for(let j=-radius;j<=radius;j++)for(let k=-radius;k<=radius;k++){
    if((i+j+k)%2!==0)continue;
    if(crop==="sphere"&&Math.hypot(i,j,k)>radius*Math.sqrt(2)+1e-9)continue;
    if(crop==="tetrahedral"&&(i+j+k<0||i<0||j<0||k<0))continue;
    const id=nodes.length,key=`${i},${j},${k}`;
    nodes.push({id,lattice:[i,j,k],position:v3(i*scale,j*scale,k*scale),shell:Math.max(Math.abs(i),Math.abs(j),Math.abs(k))});
    index.set(key,id);
  }
  for(const node of nodes){
    node.neighbors=[];
    for(const d of IVM_NEIGHBOR_OFFSETS){
      const key=`${node.lattice[0]+d[0]},${node.lattice[1]+d[1]},${node.lattice[2]+d[2]}`;
      if(index.has(key))node.neighbors.push(index.get(key));
    }
    node.coordinationNumber=node.neighbors.length;
  }
  const edges=[];
  for(const n of nodes)for(const m of n.neighbors)if(n.id<m)edges.push([n.id,m]);
  return {id:"ivm",nodes,edges,edgeLength,crop,radius,metadata:{epistemicStatus:"conventional FCC lattice interpreted as Fuller IVM"}};
}
export function localVectorEquilibrium(ivm,nodeId=0){
  const center=ivm.nodes[nodeId];
  const neighbors=center.neighbors.map(i=>ivm.nodes[i]);
  return {center,neighbors,valid:neighbors.length===12,distances:neighbors.map(n=>distance(center.position,n.position))};
}
