import { projectOrthographic } from "./project.mjs";
import { faceNormal } from "../geometry/mesh.mjs";

function esc(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));}
export function meshToSvg(mesh,{width=900,height=700,rotation,scale=220,showFaces=true,showEdges=true,showVertices=true,title=mesh.name,radials=false}={}){
  const pts=projectOrthographic(mesh.vertices,{width,height,rotation,scale});
  const faces=mesh.faces.map((face,i)=>({face,i,z:face.reduce((s,v)=>s+pts[v].z,0)/face.length})).sort((a,b)=>a.z-b.z);
  const parts=[`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`,
    `<rect width="100%" height="100%" fill="#fbfaf6"/>`,
    `<text x="36" y="48" font-family="serif" font-size="24" fill="#15191e">${esc(title)}</text>`,
    `<text x="36" y="76" font-family="serif" font-size="13" fill="#68717a">${esc(mesh.metadata?.epistemicStatus??"")}</text>`];
  if(showFaces)for(const {face,i} of faces){
    const d=face.map((v,j)=>`${j?"L":"M"} ${pts[v].x.toFixed(2)} ${pts[v].y.toFixed(2)}`).join(" ")+" Z";
    const color=face.length===3?"#d9e5ec":face.length===4?"#eee2c8":"#e3dce9";
    parts.push(`<path d="${d}" fill="${color}" fill-opacity=".42" stroke="none"/>`);
  }
  if(radials){
    const cx=width/2,cy=height/2;
    for(const p of pts)parts.push(`<line x1="${cx}" y1="${cy}" x2="${p.x}" y2="${p.y}" stroke="#aa7c2e" stroke-opacity=".35" stroke-width="1"/>`);
  }
  if(showEdges)for(const [a,b] of mesh.edges)parts.push(`<line x1="${pts[a].x}" y1="${pts[a].y}" x2="${pts[b].x}" y2="${pts[b].y}" stroke="#27313a" stroke-opacity=".72" stroke-width="1.2"/>`);
  if(showVertices)for(const p of pts)parts.push(`<circle cx="${p.x}" cy="${p.y}" r="3.2" fill="#a6434a"/>`);
  parts.push(`<text x="36" y="${height-30}" font-family="serif" font-size="13" fill="#68717a">V=${mesh.vertices.length} · E=${mesh.edges.length} · F=${mesh.faces.length}</text>`,`</svg>`);
  return parts.join("\n");
}
export function latticeToSvg(ivm,{width=900,height=700,rotation,scale=95,title="Isotropic Vector Matrix"}={}){
  const points=ivm.nodes.map(n=>n.position),pts=projectOrthographic(points,{width,height,rotation,scale});
  const parts=[`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><rect width="100%" height="100%" fill="#fbfaf6"/>`,
  `<text x="36" y="48" font-family="serif" font-size="24">${esc(title)}</text>`];
  for(const [a,b] of ivm.edges)parts.push(`<line x1="${pts[a].x}" y1="${pts[a].y}" x2="${pts[b].x}" y2="${pts[b].y}" stroke="#3f6f94" stroke-opacity=".24" stroke-width=".8"/>`);
  for(const p of pts)parts.push(`<circle cx="${p.x}" cy="${p.y}" r="2" fill="#aa7c2e" fill-opacity=".7"/>`);
  parts.push(`</svg>`);return parts.join("\n");
}
