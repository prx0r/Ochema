import { mat3MulVec, rotationMatrixXYZ } from "../math/matrix.mjs";

export function projectOrthographic(points,{width=900,height=700,scale=220,rotation=[-.55,.62,.12],center=[width/2,height/2]}={}){
  const m=rotationMatrixXYZ(...rotation);
  return points.map(p=>{
    const q=mat3MulVec(m,p);
    return {x:center[0]+q.x*scale,y:center[1]-q.y*scale,z:q.z};
  });
}
