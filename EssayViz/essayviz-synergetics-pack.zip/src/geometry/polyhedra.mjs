import { v3 } from "../math/vec3.mjs";
import { makeMesh, normalizeEdgeLength, orientFacesOutward } from "./mesh.mjs";

function hullFacesByPlane(vertices,faceSize,tol=1e-7){
  const candidates=new Map(),n=vertices.length;
  for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)for(let k=j+1;k<n;k++){
    const a=vertices[i],b=vertices[j],c=vertices[k];
    const nx=(b.y-a.y)*(c.z-a.z)-(b.z-a.z)*(c.y-a.y);
    const ny=(b.z-a.z)*(c.x-a.x)-(b.x-a.x)*(c.z-a.z);
    const nz=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
    const nn=Math.hypot(nx,ny,nz);if(nn<tol)continue;
    const d=nx*a.x+ny*a.y+nz*a.z;
    const signs=vertices.map(p=>nx*p.x+ny*p.y+nz*p.z-d);
    const pos=signs.some(s=>s>tol),neg=signs.some(s=>s<-tol);
    if(pos&&neg)continue;
    const on=signs.map((s,idx)=>Math.abs(s)<=tol?idx:-1).filter(x=>x>=0);
    if(on.length!==faceSize)continue;
    const key=[...on].sort((x,y)=>x-y).join(":");
    candidates.set(key,on);
  }
  return [...candidates.values()].map(indices=>{
    const pts=indices.map(i=>vertices[i]);
    const center=pts.reduce((s,p)=>v3(s.x+p.x,s.y+p.y,s.z+p.z),v3());
    center.x/=pts.length;center.y/=pts.length;center.z/=pts.length;
    let normal=v3();
    const p0=pts[0],p1=pts[1],p2=pts[2];
    normal=v3((p1.y-p0.y)*(p2.z-p0.z)-(p1.z-p0.z)*(p2.y-p0.y),(p1.z-p0.z)*(p2.x-p0.x)-(p1.x-p0.x)*(p2.z-p0.z),(p1.x-p0.x)*(p2.y-p0.y)-(p1.y-p0.y)*(p2.x-p0.x));
    const axis=Math.abs(normal.x)<.8*Math.hypot(normal.x,normal.y,normal.z)?v3(1,0,0):v3(0,1,0);
    const ux=v3(normal.y*axis.z-normal.z*axis.y,normal.z*axis.x-normal.x*axis.z,normal.x*axis.y-normal.y*axis.x);
    const un=Math.hypot(ux.x,ux.y,ux.z);ux.x/=un;ux.y/=un;ux.z/=un;
    const uy=v3(normal.y*ux.z-normal.z*ux.y,normal.z*ux.x-normal.x*ux.z,normal.x*ux.y-normal.y*ux.x);
    return indices.sort((ia,ib)=>{
      const pa=vertices[ia],pb=vertices[ib];
      const aa=Math.atan2((pa.x-center.x)*uy.x+(pa.y-center.y)*uy.y+(pa.z-center.z)*uy.z,(pa.x-center.x)*ux.x+(pa.y-center.y)*ux.y+(pa.z-center.z)*ux.z);
      const ab=Math.atan2((pb.x-center.x)*uy.x+(pb.y-center.y)*uy.y+(pb.z-center.z)*uy.z,(pb.x-center.x)*ux.x+(pb.y-center.y)*ux.y+(pb.z-center.z)*ux.z);
      return aa-ab;
    });
  });
}

export function createTetrahedron({edgeLength=1}={}){
  const vertices=[v3(1,1,1),v3(1,-1,-1),v3(-1,1,-1),v3(-1,-1,1)];
  const faces=[[0,2,1],[0,1,3],[0,3,2],[1,2,3]];
  return normalizeEdgeLength(orientFacesOutward(makeMesh({id:"tetrahedron",name:"Regular Tetrahedron",vertices,faces,metadata:{epistemicStatus:"conventional-mathematics"}})),edgeLength);
}
export function createOctahedron({edgeLength=1}={}){
  const vertices=[v3(1,0,0),v3(-1,0,0),v3(0,1,0),v3(0,-1,0),v3(0,0,1),v3(0,0,-1)];
  const faces=hullFacesByPlane(vertices,3);
  return normalizeEdgeLength(orientFacesOutward(makeMesh({id:"octahedron",name:"Regular Octahedron",vertices,faces,metadata:{epistemicStatus:"conventional-mathematics"}})),edgeLength);
}
export function createVectorEquilibrium({edgeLength=1,includeRadials=true}={}){
  const vertices=[];
  for(const zero of [0,1,2]){
    const other=[0,1,2].filter(i=>i!==zero);
    for(const a of [-1,1])for(const b of [-1,1]){
      const c=[0,0,0];c[other[0]]=a;c[other[1]]=b;vertices.push(v3(...c));
    }
  }
  const faces=[...hullFacesByPlane(vertices,3),...hullFacesByPlane(vertices,4)];
  const mesh=normalizeEdgeLength(orientFacesOutward(makeMesh({id:"vector-equilibrium",name:"Vector Equilibrium / Cuboctahedron",vertices,faces,metadata:{epistemicStatus:"conventional geometry + Fuller-defined interpretation",fullerTetravolumeAtFrequency1:20}})),edgeLength);
  mesh.radials=includeRadials?mesh.vertices.map((_,i)=>["center",i]):[];
  return mesh;
}
export function createIcosahedron({edgeLength=1}={}){
  const phi=(1+Math.sqrt(5))/2,vertices=[];
  for(const a of [-1,1])for(const b of [-phi,phi])vertices.push(v3(0,a,b));
  for(const a of [-1,1])for(const b of [-phi,phi])vertices.push(v3(a,b,0));
  for(const a of [-phi,phi])for(const b of [-1,1])vertices.push(v3(a,0,b));
  const faces=hullFacesByPlane(vertices,3);
  return normalizeEdgeLength(orientFacesOutward(makeMesh({id:"icosahedron",name:"Regular Icosahedron",vertices,faces,metadata:{epistemicStatus:"conventional-mathematics"}})),edgeLength);
}
export function createCube({edgeLength=1}={}){
  const s=.5*edgeLength,vertices=[];
  for(const x of [-s,s])for(const y of [-s,s])for(const z of [-s,s])vertices.push(v3(x,y,z));
  const faces=hullFacesByPlane(vertices,4);
  return orientFacesOutward(makeMesh({id:"cube",name:"Cube",vertices,faces,metadata:{epistemicStatus:"conventional-mathematics"}}));
}
