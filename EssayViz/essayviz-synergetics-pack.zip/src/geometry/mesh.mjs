import { centroid, cross, dot, norm, normalize, sub, distance, scale, add } from "../math/vec3.mjs";

export function makeMesh({id,name,vertices,faces,metadata={}}){
  const mesh={id,name,vertices:vertices.map(v=>({...v})),faces:faces.map(f=>[...f]),metadata:{...metadata}};
  mesh.edges=deriveEdges(mesh.faces);
  mesh.center=centroid(mesh.vertices);
  return mesh;
}
export function deriveEdges(faces){
  const map=new Map();
  for(const face of faces){
    for(let i=0;i<face.length;i++){
      const a=face[i],b=face[(i+1)%face.length],key=a<b?`${a}:${b}`:`${b}:${a}`;
      if(!map.has(key))map.set(key,[Math.min(a,b),Math.max(a,b)]);
    }
  }
  return [...map.values()];
}
export function edgeLengths(mesh){ return mesh.edges.map(([a,b])=>distance(mesh.vertices[a],mesh.vertices[b])); }
export function faceNormal(mesh,face){
  if(face.length<3)return {x:0,y:0,z:0};
  return normalize(cross(sub(mesh.vertices[face[1]],mesh.vertices[face[0]]),sub(mesh.vertices[face[2]],mesh.vertices[face[0]])));
}
export function orientFacesOutward(mesh){
  const center=centroid(mesh.vertices);
  mesh.faces=mesh.faces.map(face=>{
    const fc=centroid(face.map(i=>mesh.vertices[i]));
    const n=faceNormal(mesh,face);
    return dot(n,sub(fc,center))<0?[...face].reverse():face;
  });
  mesh.edges=deriveEdges(mesh.faces);
  return mesh;
}
export function surfaceArea(mesh){
  let area=0;
  for(const face of mesh.faces){
    const p0=mesh.vertices[face[0]];
    for(let i=1;i<face.length-1;i++)area+=norm(cross(sub(mesh.vertices[face[i]],p0),sub(mesh.vertices[face[i+1]],p0)))/2;
  }
  return area;
}
export function signedVolume(mesh){
  let volume=0;
  for(const face of mesh.faces){
    const p0=mesh.vertices[face[0]];
    for(let i=1;i<face.length-1;i++){
      const p1=mesh.vertices[face[i]],p2=mesh.vertices[face[i+1]];
      volume+=dot(p0,cross(p1,p2))/6;
    }
  }
  return volume;
}
export function volume(mesh){ return Math.abs(signedVolume(mesh)); }
export function eulerCharacteristic(mesh){ return mesh.vertices.length-mesh.edges.length+mesh.faces.length; }
export function scaleMesh(mesh,s){
  return makeMesh({...mesh,vertices:mesh.vertices.map(p=>scale(p,s)),metadata:{...mesh.metadata,scale:(mesh.metadata.scale??1)*s}});
}
export function translateMesh(mesh,t){
  return makeMesh({...mesh,vertices:mesh.vertices.map(p=>add(p,t)),metadata:{...mesh.metadata}});
}
export function normalizeEdgeLength(mesh,target=1){
  const lengths=edgeLengths(mesh);
  const mean=lengths.reduce((a,b)=>a+b,0)/Math.max(1,lengths.length);
  return scaleMesh(mesh,target/mean);
}
export function adjacency(mesh){
  const out=Array.from({length:mesh.vertices.length},()=>new Set());
  for(const [a,b] of mesh.edges){out[a].add(b);out[b].add(a);}
  return out.map(s=>[...s]);
}
export function validateMesh(mesh,{edgeTolerance=1e-8,requireUniformEdges=false}={}){
  const errors=[];
  const lengths=edgeLengths(mesh);
  if(eulerCharacteristic(mesh)!==2)errors.push(`Euler characteristic ${eulerCharacteristic(mesh)} != 2`);
  if(requireUniformEdges&&lengths.length){
    const mean=lengths.reduce((a,b)=>a+b,0)/lengths.length;
    const max=Math.max(...lengths.map(x=>Math.abs(x-mean)));
    if(max>edgeTolerance)errors.push(`edge deviation ${max} > ${edgeTolerance}`);
  }
  for(const face of mesh.faces){
    if(new Set(face).size!==face.length)errors.push("face contains repeated vertex");
    if(face.some(i=>i<0||i>=mesh.vertices.length))errors.push("face index out of range");
  }
  return {valid:errors.length===0,errors,metrics:{V:mesh.vertices.length,E:mesh.edges.length,F:mesh.faces.length,chi:eulerCharacteristic(mesh),surfaceArea:surfaceArea(mesh),volume:volume(mesh),edgeMin:Math.min(...lengths),edgeMax:Math.max(...lengths)}};
}
