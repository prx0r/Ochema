import { centroid, norm, scale, sub } from "../math/vec3.mjs";
import { scaleMesh } from "./mesh.mjs";

function radius(mesh,type){
  const c=centroid(mesh.vertices);
  if(type==="circumradius")return Math.max(...mesh.vertices.map(p=>norm(sub(p,c))));
  if(type==="mean-radius")return mesh.vertices.reduce((s,p)=>s+norm(sub(p,c)),0)/mesh.vertices.length;
  throw new Error(`unsupported normalization ${type}`);
}
export function normalizeHierarchy(meshes,{normalization="circumradius",target=1}={}){
  return meshes.map(mesh=>{
    const r=radius(mesh,normalization);
    return scaleMesh(mesh,target/r);
  });
}
export function createHierarchyRelation(from,to,{relation,invariant,normalization="circumradius",sourceRefs=[]}={}){
  return {from:from.id,to:to.id,relation,invariant,normalization,sourceRefs};
}
