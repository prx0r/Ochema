import { v3 } from "./vec3.mjs";

export function mat3Identity(){ return [1,0,0,0,1,0,0,0,1]; }
export function mat3MulVec(m,p){
  return v3(
    m[0]*p.x+m[1]*p.y+m[2]*p.z,
    m[3]*p.x+m[4]*p.y+m[5]*p.z,
    m[6]*p.x+m[7]*p.y+m[8]*p.z
  );
}
export function mat3Mul(a,b){
  const out=Array(9).fill(0);
  for(let r=0;r<3;r++)for(let c=0;c<3;c++)for(let k=0;k<3;k++)out[r*3+c]+=a[r*3+k]*b[k*3+c];
  return out;
}
export function rotationMatrixXYZ(ax=0,ay=0,az=0){
  const [cx,sx,cy,sy,cz,sz]=[Math.cos(ax),Math.sin(ax),Math.cos(ay),Math.sin(ay),Math.cos(az),Math.sin(az)];
  const rx=[1,0,0,0,cx,-sx,0,sx,cx];
  const ry=[cy,0,sy,0,1,0,-sy,0,cy];
  const rz=[cz,-sz,0,sz,cz,0,0,0,1];
  return mat3Mul(rz,mat3Mul(ry,rx));
}
