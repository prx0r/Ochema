export const EPS = 1e-9;

export function v3(x=0,y=0,z=0){ return {x,y,z}; }
export function add(a,b){ return v3(a.x+b.x,a.y+b.y,a.z+b.z); }
export function sub(a,b){ return v3(a.x-b.x,a.y-b.y,a.z-b.z); }
export function scale(a,s){ return v3(a.x*s,a.y*s,a.z*s); }
export function dot(a,b){ return a.x*b.x+a.y*b.y+a.z*b.z; }
export function cross(a,b){ return v3(a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x); }
export function norm2(a){ return dot(a,a); }
export function norm(a){ return Math.sqrt(norm2(a)); }
export function normalize(a){
  const n=norm(a);
  return n<EPS?v3():scale(a,1/n);
}
export function distance(a,b){ return norm(sub(a,b)); }
export function lerp(a,b,t){ return add(scale(a,1-t),scale(b,t)); }
export function centroid(points){
  if(!points.length)return v3();
  return scale(points.reduce((s,p)=>add(s,p),v3()),1/points.length);
}
export function rotateZ(p,a){
  const c=Math.cos(a),s=Math.sin(a);
  return v3(c*p.x-s*p.y,s*p.x+c*p.y,p.z);
}
export function rotateX(p,a){
  const c=Math.cos(a),s=Math.sin(a);
  return v3(p.x,c*p.y-s*p.z,s*p.y+c*p.z);
}
export function rotateY(p,a){
  const c=Math.cos(a),s=Math.sin(a);
  return v3(c*p.x+s*p.z,p.y,-s*p.x+c*p.z);
}
export function approx(a,b,tol=1e-8){ return distance(a,b)<=tol; }
export function toArray(p){ return [p.x,p.y,p.z]; }
export function fromArray(a){ return v3(a[0]??0,a[1]??0,a[2]??0); }
