export const dynamic_relaxation = "dynamic-relaxation";
export const simplex_tensegrity = "simplex-tensegrity";
export const member_force_visualization = "member-force-visualization";
