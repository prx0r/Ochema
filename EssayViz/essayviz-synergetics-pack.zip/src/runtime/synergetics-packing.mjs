export const twelve_around_one = "twelve-around-one";
export const ivm = "ivm";
export const local_vector_equilibrium = "local-vector-equilibrium";
