export const minimum_system = "minimum-system";
export const closest_packing = "closest-packing";
export const jitterbug_explanation = "jitterbug-explanation";
export const frequency_growth = "frequency-growth";
export const concentric_hierarchy = "concentric-hierarchy";
export const tensegrity_load = "tensegrity-load";
