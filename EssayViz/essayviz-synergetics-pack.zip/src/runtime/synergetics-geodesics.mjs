export const triangle_frequency = "triangle-frequency";
export const geodesic_icosahedron = "geodesic-icosahedron";
export const tetrahelix = "tetrahelix";
