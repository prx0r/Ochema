export const tetrahedron = "tetrahedron";
export const octahedron = "octahedron";
export const icosahedron = "icosahedron";
export const vector_equilibrium = "vector-equilibrium";
export const cube = "cube";
