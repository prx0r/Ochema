export const euclidean_mensuration = "euclidean-mensuration";
export const fuller_tetravolume = "fuller-tetravolume";
