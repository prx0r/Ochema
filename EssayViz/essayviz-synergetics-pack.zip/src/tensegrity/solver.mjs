import { add, sub, scale, norm, normalize } from "../math/vec3.mjs";

export function solveTensegrity(system,{iterations=2000,dt=.01,damping=.985,tolerance=1e-5}={}){
  const positions=system.nodes.map(n=>({...n.position}));
  const velocity=system.nodes.map(()=>({x:0,y:0,z:0}));
  let residual=Infinity;
  for(let it=0;it<iterations;it++){
    const forces=system.nodes.map(()=>({x:0,y:0,z:0}));
    for(const m of system.members){
      const d=sub(positions[m.b],positions[m.a]),L=norm(d)||1e-12,dir=scale(d,1/L);
      let extension=L-m.restLength;
      if(m.type==="cable"&&extension<0)extension=0;
      if(m.type==="strut"&&extension>0&&m.compressionOnly)extension=0;
      const f=scale(dir,(m.stiffness??1)*extension);
      forces[m.a]=add(forces[m.a],f);forces[m.b]=sub(forces[m.b],f);
    }
    for(const load of system.externalLoads??[])forces[load.node]=add(forces[load.node],load.force);
    residual=Math.max(...forces.map(norm));
    if(residual<tolerance)break;
    for(let i=0;i<positions.length;i++){
      if(system.nodes[i].fixed)continue;
      velocity[i]=scale(add(velocity[i],scale(forces[i],dt/(system.nodes[i].mass??1))),damping);
      positions[i]=add(positions[i],scale(velocity[i],dt));
    }
  }
  return {positions,residual,converged:residual<tolerance};
}
export function memberForces(system,positions){
  return system.members.map(m=>{
    const L=norm(sub(positions[m.b],positions[m.a])),force=(m.stiffness??1)*(L-m.restLength);
    return {...m,length:L,force,state:force>=0?"tension":"compression"};
  });
}
