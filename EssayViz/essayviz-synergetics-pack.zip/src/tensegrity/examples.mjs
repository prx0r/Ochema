import { v3 } from "../math/vec3.mjs";
export function createSimplexTensegrity({height=1.4,radius=1,prestress=.12}={}){
  const nodes=[];
  for(let layer=0;layer<2;layer++)for(let i=0;i<3;i++){
    const a=i*2*Math.PI/3+(layer?Math.PI/3:0);
    nodes.push({position:v3(Math.cos(a)*radius,Math.sin(a)*radius,(layer-.5)*height),mass:1});
  }
  const members=[];
  for(let i=0;i<3;i++)members.push({type:"strut",a:i,b:3+((i+1)%3),restLength:Math.hypot(height,2*radius*Math.sin(Math.PI/3))*0.98,stiffness:1.5});
  for(let layer=0;layer<2;layer++)for(let i=0;i<3;i++)members.push({type:"cable",a:layer*3+i,b:layer*3+(i+1)%3,restLength:Math.sqrt(3)*radius*(1-prestress),stiffness:1});
  for(let i=0;i<3;i++)members.push({type:"cable",a:i,b:3+i,restLength:height*(1-prestress),stiffness:1});
  return {id:"simplex-tensegrity",nodes,members,externalLoads:[]};
}
