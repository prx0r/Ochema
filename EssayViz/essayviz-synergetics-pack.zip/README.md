# EssayViz Synergetics Pack

A source-linked JavaScript geometry and capability family for Buckminster
Fuller's Synergetics.

## What works now

- exact canonical tetrahedron, octahedron, icosahedron, cube and vector equilibrium;
- topology, edge, Euler, surface-area and Euclidean-volume validation;
- Fuller vector-equilibrium tetravolume accounting kept separate from Euclidean volume;
- FCC/IVM lattice and local twelve-neighbor vector equilibrium;
- closest-packed twelve-around-one sphere system;
- arbitrary-frequency triangular subdivision;
- geodesic icosahedra;
- tetrahelix generation;
- numerical distance-constrained jitterbug prototype with handedness, phase,
  volume and edge-error reports;
- dynamic-relaxation tensegrity scaffold;
- SVG projection renderer;
- EssayViz capability-pack hierarchy;
- Synergetics geometry-director skill;
- tests and generated demo assets.

## Important precision statement

The jitterbug implementation is a constraint-preserving numerical mechanism
prototype. It preserves the declared triangular edge constraints to measured
tolerance and produces a continuous contraction. It does **not** yet label
intermediate states as canonical icosahedron, octahedron or tetrahedron without
source-calibrated phase conditions.

The A/B/T/E module library and complete great-circle families are scaffolded in
the roadmap, not falsely represented as complete.

## Install and test

```bash
npm install
npm test
npm run validate
npm run demo
```

## CLI

```bash
synergetics validate
synergetics demo --out build/demo
```

## Primary API

```js
import {
  createVectorEquilibrium,
  createIVM,
  createJitterbug,
  createGeodesicIcosahedron,
  createTetrahelix,
  createSimplexTensegrity,
  meshToSvg
} from "@prx0r/essayviz-synergetics";
```

## Capability packs

```text
synergetics-core
synergetics-polyhedra
synergetics-packing
synergetics-transformations
synergetics-geodesics
synergetics-mensuration
synergetics-tensegrity
synergetics-essay-composition
```

Read `skills/SYNERGETICS-GEOMETRY-DIRECTOR.md` before asking an agent to map an
essay into these capabilities.
