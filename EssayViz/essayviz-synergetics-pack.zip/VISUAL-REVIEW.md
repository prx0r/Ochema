# Visual Review

Review artifact:

```text
build/demo/contact-sheet.png
```

## Quality notes

The white scientific presentation is suitable for EssayViz explanation:
hairline edges, restrained face tinting, red vertices, and small provenance
labels.

The most successful examples are:

- frequency-three geodesic;
- IVM;
- vector equilibrium with radials;
- tetrahelix;
- jitterbug phases 0.00 through 0.75.

Phase 1.00 of the jitterbug should be treated as diagnostic only. It is not a
publishable tetrahedral endpoint.

## Next visual upgrades

- depth-sorted hidden-line removal;
- face identity colors during jitterbug contraction;
- coincident-edge grouping;
- polar/equatorial annotations;
- volume and diagonal plots beside the 3D view;
- common-circumradius comparison layouts;
- WebGPU orbit and hinge animation;
- Skia mathematical overlay.
