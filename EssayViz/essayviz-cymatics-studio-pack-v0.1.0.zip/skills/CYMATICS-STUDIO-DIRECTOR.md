---
name: cymatics-studio-director
description: Convert audio, Sanskrit phonemes, musical structures, or experimental hypotheses into apparatus-grounded cymatic and generative visual scenes.
version: 1.0
---

# Cymatics Studio Director

## Prime distinction

Always identify which layer is being rendered:

1. **signal analysis** — measurable properties of the recording;
2. **apparatus response** — the response of a declared plate, membrane, or fluid model;
3. **generative mapping** — artistic geometry driven by signal features;
4. **interpretive hypothesis** — an explicitly labelled experimental proposal.

Never present layer 3 or 4 as if it were layer 2.

## Required scene contract

```json
{
  "sourceClaim": "",
  "signalSource": "",
  "signalFeatures": [],
  "apparatus": null,
  "equationOrGenerator": "",
  "parameters": {},
  "invariants": [],
  "measurements": [],
  "artisticMapping": {},
  "epistemicStatus": "measurement|simulation|generative-art|hypothesis",
  "audioRoutes": [],
  "forbiddenInference": ""
}
```

## Sanskrit phonemes

Record or import:

- grapheme;
- IAST;
- IPA where known;
- speaker;
- context;
- pitch;
- duration;
- RMS;
- microphone and distance.

Compare repeated tokens and multiple speakers before claiming stable patterns.

Acceptable conclusion:

> In this apparatus and recording, ā excited these modes more strongly than ī.

Forbidden conclusion:

> ā intrinsically possesses this universal sacred shape.

## Apparatus scenes

Specify:

- shape;
- dimensions;
- material;
- thickness or depth;
- boundary condition;
- exciter location;
- damping;
- frequency range.

## Generative scenes

Color and shape mappings must have legends.

Examples:

- spectral centroid → hue;
- RMS → lightness or radius;
- spectral noise → saturation;
- onset → transition emphasis.

## Valence children

QRI-inspired symmetry and valence mappings are hypotheses.

The agent must include:

```json
{
  "epistemicStatus": "hypothesis",
  "forbiddenClaims": [
    "the score measures felt pleasure",
    "symmetry alone establishes consciousness",
    "visual beauty validates the theory"
  ]
}
```

## Review

Reject a scene when:

- apparatus parameters are missing;
- a phoneme is reduced to one frequency;
- artistic geometry is called a cymatic measurement;
- audio alters an invariant or equation;
- color has no declared meaning;
- the QRI child claims measured subjective valence;
- results from one token are generalized to Sanskrit as a whole.
