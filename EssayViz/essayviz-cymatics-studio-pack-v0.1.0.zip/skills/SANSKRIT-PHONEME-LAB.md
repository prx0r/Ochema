---
name: sanskrit-phoneme-lab
description: Design controlled Sanskrit acoustic and cymatic comparisons without claiming universal sacred geometry.
version: 1.0
---

# Sanskrit Phoneme Laboratory

## Minimum token metadata

```json
{
  "grapheme": "आ",
  "transliteration": "ā",
  "ipa": "aː",
  "speakerId": "S01",
  "context": "isolated",
  "sampleRate": 44100,
  "microphone": "",
  "distanceCm": 15,
  "pitchTargetHz": 132,
  "durationTargetSeconds": 2
}
```

## Comparison controls

Prefer:

- same speaker;
- same pitch;
- same RMS;
- same duration;
- repeated trials;
- same apparatus;
- randomized presentation order.

Then repeat across speakers.

## Outputs

- waveform;
- spectrum;
- fundamental estimate;
- spectral moments;
- band energies;
- apparatus transfer;
- modal weights;
- time-varying nodal pattern;
- repeatability score.
