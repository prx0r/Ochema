---
name: cymatics-child-pack-author
description: Generate a new Cymatics Studio child configuration without modifying the scientific core.
version: 1.0
---

# Cymatics Child Pack Author

## Input

Receive:

- intended use;
- source signal;
- scientific or artistic status;
- desired visual mechanism;
- equations or references;
- required controls;
- forbidden claims.

## Procedure

1. Copy `examples/child-seed.json`.
2. Give the child a unique `id`.
3. Select one `type`.
4. Declare inherited packs.
5. Complete `scientificCore`.
6. Complete `artisticLayer`.
7. Add agent review tests.
8. Run `validateChildSeed`.
9. Produce three diagnostic scenes.
10. Render static checkpoints before adding polish.

## Never modify

- normalization rules;
- apparatus equations;
- topology;
- phoneme metadata;
- source provenance;
- experimental measurements.

## Child types

```text
apparatus
phoneme-atlas
generative-art
music-geometry
color-mapping
valence-hypothesis
experimental-capture
```

## Quality rule

A child configuration changes policy and parameters. A new mathematical solver
belongs in a versioned engine module with its own tests.
