# Creating Expansion Children

## 1. Start from the seed

```bash
node tools/create-child.mjs examples/child-seed.json build/my-child.json
```

## 2. Pick one child type

- `apparatus`: new physical setup preset;
- `phoneme-atlas`: controlled speech comparison;
- `generative-art`: feature-driven abstract geometry;
- `music-geometry`: chord, rhythm, or tonal-space mapping;
- `color-mapping`: a documented color semantics policy;
- `valence-hypothesis`: exploratory affective feature mapping;
- `experimental-capture`: real apparatus metadata and extracted patterns.

## 3. Fill the scientific core

Declare:

```json
{
  "sourceSignal": "",
  "apparatus": null,
  "equation": "",
  "parameters": {},
  "invariants": [],
  "measurements": [],
  "epistemicStatus": ""
}
```

## 4. Fill the artistic layer

Declare exactly what each visual channel means.

```json
{
  "mechanism": "spectral-morph",
  "style": "fluidNight",
  "colorMapping": {
    "hue": "spectralCentroid",
    "saturation": "high",
    "lightness": "rms"
  },
  "audioRoutes": []
}
```

## 5. Write forbidden claims

This is mandatory.

Examples:

- “This is the universal form of the phoneme.”
- “The hypothesis score measures happiness.”
- “The generated geometry proves a metaphysical interpretation.”

## 6. Render diagnostics

Every child should include:

1. zero input;
2. simple sine input;
3. broadband/noisy input;
4. real target audio;
5. parameter extremes.

## 7. Promotion rule

A child becomes part of the core only after:

- mathematical tests;
- deterministic output;
- visual review;
- source documentation;
- explicit failure modes.
