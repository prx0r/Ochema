# Research Basis

## Cymatics and modal analysis

- Kumar, Chary & Wani, “Modal Analysis of Chladni Plate Using Cymatics,”
  SAE Technical Paper 2020-28-0320.
- Thomas Müller, “Numerical Chladni figures,” arXiv:1308.5523.

## Faraday waves

- Binks & van de Water, “Nonlinear Pattern Formation of Faraday Waves,”
  Physical Review Letters 78, 4043.
- Zhang & Viñals, pattern-formation work on weakly damped Faraday waves.
- Perlin & Schultz, “Capillary Effects on Surface Waves,” Annual Review of
  Fluid Mechanics 32.

## Music geometry

- Dmitri Tymoczko, “The Geometry of Musical Chords,” Science 313, 72–74.
- Dmitri Tymoczko, “Scale Theory, Serial Theory and Voice Leading.”

## Valence hypothesis

- Qualia Research Institute, “The Symmetry Theory of Valence 2020 Overview.”
- QRI Research Approach and glossary.

These sources motivate the architecture. Their hypotheses are not silently
promoted to established facts by this package.
