# Scientific Boundaries

## Chladni figures

Chladni patterns depend on excitation frequency and on plate geometry, material,
thickness, mounting, and forcing arrangement. The analytic square and circular
modes in this package are reference approximations.

## Faraday patterns

The Faraday module is a modal pattern generator. It does not solve the complete
nonlinear free-surface Navier–Stokes problem. Pattern regime labels are
illustrative experimental presets.

## Sanskrit sounds

A phoneme is represented by a time-varying spectrum, not one frequency.
Patterns must be described as the response of a specified apparatus to a
specified recording.

## Music geometry

The voice-leading child uses pitch-class normalization and minimal Euclidean
voice displacement. It is inspired by geometrical music theory, but the current
renderer is a compact implementation, not a complete N-dimensional orbifold
atlas.

## Valence

The optional valence child exposes symmetry, consonance, roughness, and noise
features. It is not a measurement of subjective pleasantness or suffering.

## Coherent-water and subtle-body claims

The package does not assume that cymatic order establishes a coherent-water
subtle body, consciousness, cakra geometry, kundalinī, tukdam, or rebirth.
Those are separate empirical or metaphysical claims requiring independent
evidence.
