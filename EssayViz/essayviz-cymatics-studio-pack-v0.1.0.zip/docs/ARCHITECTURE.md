# Cymatics Studio Architecture

```text
audio or phoneme recording
→ reference spectrum / richer external analyser
→ normalized acoustic features
→ one of two paths:

A. apparatus path
   → declared plate, membrane, or fluid model
   → modal transfer function
   → displacement field
   → nodal geometry
   → particle or surface visualization

B. artistic path
   → declared feature mapping
   → morphing geometry, color, camera, typography
```

The two paths may be composed, but they remain labelled.

## Compatibility with EssayViz Mathematics

Cymatics Studio is a peer package of `@prx0r/essayviz-mathematics`.

It inherits or interoperates with:

- scalar and vector fields;
- toroidal topology;
- complex dynamics;
- differential geometry;
- symmetry groups;
- normalized audio feature manifests;
- Skia-compatible Canvas 2D renderers.

## Stable extension boundary

The core engine owns:

- acoustic analysis contracts;
- modal equations;
- apparatus metadata;
- particle transport;
- measurement definitions;
- epistemic status.

Child configs own:

- parameter presets;
- aesthetic style;
- feature-to-color mapping;
- permitted audio routes;
- camera policy;
- agent usage rules.

## Child pack rule

A JSON child changes configuration.

A new differential equation, solver, physical model, or measurement algorithm
must be introduced as a tested engine module, not hidden in a child JSON file.
