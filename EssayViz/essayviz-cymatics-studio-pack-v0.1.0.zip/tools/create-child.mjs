#!/usr/bin/env node
import {readFile,writeFile,mkdir} from "node:fs/promises";
import {resolve,dirname} from "node:path";
import {createChildSeed,validateChildSeed} from "../src/index.mjs";

const input=resolve(process.argv[2]??"examples/child-seed.json");
const output=resolve(process.argv[3]??"build/generated-child.json");
const overrides=JSON.parse(await readFile(input,"utf8"));
const seed=createChildSeed(overrides);
const result=validateChildSeed(seed);
if(!result.valid)throw new Error(result.errors.join("\n"));
await mkdir(dirname(output),{recursive:true});
await writeFile(output,JSON.stringify(seed,null,2));
console.log(output);
