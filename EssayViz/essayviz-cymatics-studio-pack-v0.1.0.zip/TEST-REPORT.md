# Test Report

## Automated tests

```text
14 tests passed
0 failed
```

Covered:

- DFT frequency recovery;
- acoustic feature extraction;
- square and circular modal fields;
- nodal masks;
- particle convergence toward low-displacement regions;
- deterministic audio-derived geometry;
- point-set morphing;
- voice-leading distance;
- rhythmic symmetry;
- bounded exploratory valence features;
- child-config validation;
- CLI validation.

## End-to-end render

```text
build/e2e/morphing-geometry.mp4
duration: 4.000 seconds
resolution: 1280×720
frame rate: 12 fps
codec: H.264
```

The test generates time-varying audio features, maps them into a spectral
superformula shape and semantic color, writes 48 SVG frames, rasterizes them,
and encodes the resulting animation.

## Clean installation

The packed Cymatics Studio tarball was installed beside:

```text
@prx0r/essayviz-mathematics 0.2.0
```

Verified:

- package import;
- 360-point spectral geometry generation;
- installed CLI execution;
- installed CLI validation.

## Visual review

Inspected:

```text
build/demo/contact-sheet.png
```

Passed:

- Chladni nodal structure is legible;
- particle migration differs visibly from the direct field;
- generative geometry is visually distinct from apparatus simulation;
- voice-leading geometry presents pitch-class movement;
- the valence panel remains explicitly hypothetical.

Known limitations remain documented in `README.md` and
`docs/SCIENTIFIC-BOUNDARIES.md`.
