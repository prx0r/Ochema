import test from "node:test";
import assert from "node:assert/strict";
import {generateModeBank,buildDrivenField,createParticles,stepParticles,particleNodalScore} from "../src/index.mjs";

test("particles move toward lower displacement on average",()=>{
  const mode=generateModeBank({geometry:"square",maxOrder:5})[7];
  const field=buildDrivenField([{...mode,amplitude:1}],{resolution:100,time:.1});
  let particles=createParticles({count:1000,seed:11});
  const before=particleNodalScore(particles,field);
  for(let i=0;i<140;i++)particles=stepParticles(particles,field,{dt:.03,seed:11+i});
  const after=particleNodalScore(particles,field);
  assert.ok(after<before,`${after} should be below ${before}`);
});
