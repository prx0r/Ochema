import test from "node:test";
import assert from "node:assert/strict";
import {experimentalValenceFeatures,createChildSeed,validateChildSeed,validateValenceConfig} from "../src/index.mjs";

test("valence feature vector is bounded and explicitly hypothetical",()=>{
  const f=experimentalValenceFeatures({points:[{x:1,y:0},{x:0,y:1},{x:-1,y:0},{x:0,y:-1}],frequencies:[220,330,440],onsets:[0,.25,.5,.75]});
  assert.ok(f.hypothesisScore>=0&&f.hypothesisScore<=1);
  assert.match(f.epistemicStatus,/not a valence measurement/);
});
test("child seed validates and valence overclaim is rejected",()=>{
  const seed=createChildSeed({id:"demo",title:"Demo",type:"generative-art"});
  assert.equal(validateChildSeed(seed).valid,true);
  assert.equal(validateValenceConfig({epistemicStatus:"hypothesis",claimsMeasuredValence:false}).valid,true);
  assert.equal(validateValenceConfig({epistemicStatus:"hypothesis",claimsMeasuredValence:true}).valid,false);
});
