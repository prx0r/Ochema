import test from "node:test";
import assert from "node:assert/strict";
import {createSpectralShape,spectrumToShapeParameters,morphPointSets} from "../src/index.mjs";

test("spectral shape is deterministic and finite",()=>{
  const f={rms:.5,low:.3,mid:.7,high:.2,spectralCentroid:.6};
  const a=createSpectralShape(f,{samples:200,time:.3});
  const b=createSpectralShape(f,{samples:200,time:.3});
  assert.deepEqual(a,b);
  assert.ok(a.points.flatMap(p=>[p.x,p.y]).every(Number.isFinite));
});
test("point-set morph preserves requested maximum cardinality",()=>{
  const a=createSpectralShape({}, {samples:80}).points;
  const b=createSpectralShape({spectralCentroid:1},{samples:120}).points;
  assert.equal(morphPointSets(a,b,.5).length,120);
});
