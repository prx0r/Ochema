import test from "node:test";
import assert from "node:assert/strict";
import {dftReal,analyzeFrame,spectralMoments} from "../src/index.mjs";

test("reference DFT peaks near the input sine frequency",()=>{
  const sampleRate=4096,N=1024,f=256;
  const samples=Array.from({length:N},(_,n)=>Math.sin(2*Math.PI*f*n/sampleRate));
  const spectrum=dftReal(samples,{sampleRate,bins:512});
  const peak=spectrum.reduce((a,b)=>a.magnitude>b.magnitude?a:b);
  assert.ok(Math.abs(peak.frequency-f)<=sampleRate/N);
});
test("frame analysis returns finite normalized bands",()=>{
  const samples=Array.from({length:1024},(_,n)=>.6*Math.sin(2*Math.PI*128*n/4096)+.2*Math.sin(2*Math.PI*900*n/4096));
  const a=analyzeFrame(samples,{sampleRate:4096,bins:512});
  assert.ok(Number.isFinite(a.moments.centroid));
  assert.ok(a.bands.low>=0&&a.bands.mid>=0&&a.bands.high>=0);
});
