import test from "node:test";
import assert from "node:assert/strict";
import {optimalVoiceLeading,voiceLeadingPath,rhythmicSymmetry} from "../src/index.mjs";

test("identical chords have zero voice-leading distance",()=>{
  assert.equal(optimalVoiceLeading([0,4,7],[0,4,7]).distance,0);
});
test("voice-leading path returns finite step distances",()=>{
  const result=voiceLeadingPath([[0,4,7],[0,3,7],[2,5,9]]);
  assert.equal(result.steps.length,2);
  assert.ok(result.steps.every(x=>Number.isFinite(x.distance)));
});
test("equally spaced rhythm has strong fourth-order symmetry",()=>{
  const r=rhythmicSymmetry([0,.25,.5,.75],{period:1,orders:8});
  assert.equal(r.order,4);
  assert.ok(r.score>.99);
});
