import test from "node:test";
import assert from "node:assert/strict";
import {spawnSync} from "node:child_process";

test("CLI validation succeeds",()=>{
  const r=spawnSync(process.execPath,["bin/cymatics-studio.mjs","validate"],{encoding:"utf8"});
  assert.equal(r.status,0,r.stderr);
  assert.equal(JSON.parse(r.stdout).valid,true);
});
