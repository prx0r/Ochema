import test from "node:test";
import assert from "node:assert/strict";
import {squarePlateMode,circularMembraneMode,sampleMode,nodalMask,generateModeBank} from "../src/index.mjs";

test("square plate modes are finite and ordered",()=>{
  const bank=generateModeBank({geometry:"square",maxOrder:4});
  assert.equal(bank.length,16);
  assert.ok(bank.every((m,i)=>i===0||m.frequency>=bank[i-1].frequency));
  assert.ok(bank.every(m=>Number.isFinite(m.frequency)&&m.frequency>0));
});
test("sampled fields and nodal masks have expected sizes",()=>{
  const field=sampleMode(squarePlateMode({m:2,n:3}),{resolution:64});
  const mask=nodalMask(field);
  assert.equal(field.values.length,4096);
  assert.equal(mask.values.length,4096);
  assert.ok([...mask.values].some(Boolean));
});
test("circular modes vanish outside the membrane",()=>{
  const mode=circularMembraneMode({angular:2,radial:1});
  assert.equal(mode.evaluate(2,0),0);
  assert.ok(Number.isFinite(mode.evaluate(.2,.3)));
});
