import {createPrimitives} from "./primitives.mjs";
import {generateModeBank,buildDrivenField,selectDrivenModes} from "../chladni/index.mjs";
import {modalForcing} from "../audio/index.mjs";
import {createParticles,stepParticles} from "../particles/index.mjs";
import {createSpectralShape} from "../morph/index.mjs";
import {acousticColor} from "../color/index.mjs";
import {voiceLeadingPath} from "../music-geometry/index.mjs";
import {experimentalValenceFeatures} from "../valence/index.mjs";

function fieldAt(field,i,j){return field.values[j*field.width+i];}
function mapFieldPoint(i,j,field,{x=210,y=110,size=500}={}){
  return {x:x+i/(field.width-1)*size,y:y+j/(field.height-1)*size};
}

export function renderChladni(ctx,t,scene,env={}){
  const P=createPrimitives(ctx,env);P.clear();
  const geometry=scene.params?.geometry??"square";
  const modes=generateModeBank({
    geometry,maxOrder:scene.params?.maxOrder??5,
    dimensions:scene.params?.dimensions??{width:1,height:1,radius:1},
    material:scene.params?.material??{}
  });
  const spectrum=env.spectrum??[];
  const forced=spectrum.length?selectDrivenModes(modalForcing(spectrum,modes),{maximumModes:scene.params?.maximumModes??6}):[
    {...modes[Math.floor(t*(modes.length-1))],amplitude:1}
  ];
  const field=buildDrivenField(forced,{resolution:scene.params?.resolution??90,time:t});
  const ox=170,oy=105,size=510,step=2;
  for(let j=0;j<field.height;j+=step)for(let i=0;i<field.width;i+=step){
    const v=Math.abs(fieldAt(field,i,j)),p=mapFieldPoint(i,j,field,{x:ox,y:oy,size});
    if(v<.055)P.circle(p.x,p.y,1.1,{color:P.palette.node,fill:P.palette.node,alpha:.78});
    else if(scene.params?.showDisplacement)P.circle(p.x,p.y,.6,{color:acousticColor({rms:v,spectralCentroid:.5}),fill:acousticColor({rms:v,spectralCentroid:.5}),alpha:.13});
  }
  P.text("CHLADNI / MODAL RESPONSE",64,46,{size:17,weight:700});
  P.text(`${geometry} · ${forced.length} active modes`,64,675,{size:13,color:P.palette.muted});
  const x0=770;
  forced.slice(0,6).forEach((m,i)=>{
    const y=160+i*72;
    P.text(m.id,x0,y,{size:14,weight:700});
    P.text(`${m.frequency.toFixed(1)} Hz`,x0+190,y,{size:13,color:P.palette.muted});
    P.line({x:x0,y:y+23},{x:x0+300*(m.amplitude??m.forcing??1),y:y+23},{color:P.palette.positive,lineWidth:8,alpha:.55});
  });
}

export function renderCymaticParticles(ctx,t,scene,env={}){
  const P=createPrimitives(ctx,env);P.clear();
  const mode=generateModeBank({geometry:scene.params?.geometry??"square",maxOrder:5})[scene.params?.modeIndex??7];
  const field=buildDrivenField([{...mode,amplitude:1}],{resolution:100,time:t});
  let particles=env.state?.particles??createParticles({count:scene.params?.count??2200,seed:scene.params?.seed??3,domain:scene.params?.geometry==="circle"?"circle":"square"});
  for(let i=0;i<3;i++)particles=stepParticles(particles,field,{dt:.04,seed:(scene.params?.seed??3)+Math.floor(t*1000),domain:scene.params?.geometry==="circle"?"circle":"square"});
  if(env.state)env.state.particles=particles;
  const cx=640,cy=375,s=260;
  for(const p of particles)P.circle(cx+p.x*s,cy+p.y*s,1.15,{color:P.palette.particle,fill:P.palette.particle,alpha:.52});
  P.text("PARTICLE MIGRATION TOWARD NODAL REGIONS",64,46,{size:17,weight:700});
  P.text(`${mode.id} · diagnostic simulation`,64,675,{size:13,color:P.palette.muted});
}

export function renderSpectralMorph(ctx,t,scene,env={}){
  const P=createPrimitives(ctx,env);P.clear();
  const features=env.audioFeatures??{rms:.5,low:.3,mid:.5,high:.2,spectralCentroid:.45};
  const shape=createSpectralShape(features,{time:t,samples:420});
  const pts=shape.points.map(p=>({x:640+p.x*235,y:365+p.y*235}));
  const color=acousticColor(features);
  P.path(pts,{color,alpha:.92,lineWidth:2.2,closed:true});
  for(let k=1;k<=5;k++){
    P.path(pts.map(p=>({x:640+(p.x-640)*(1-k*.11),y:365+(p.y-365)*(1-k*.11)})),{color,alpha:.13,lineWidth:1,closed:true});
  }
  P.text("AUDIO-DERIVED GENERATIVE GEOMETRY",64,46,{size:17,weight:700});
  P.text(`m=${shape.parameters.m} · color encodes spectrum`,64,675,{size:13,color:P.palette.muted});
}

export function renderVoiceLeading(ctx,t,scene,env={}){
  const P=createPrimitives(ctx,env);P.clear();
  const chords=scene.params?.chords??[[0,4,7],[0,3,7],[2,5,9],[0,4,7]];
  const path=voiceLeadingPath(chords),cx=650,cy=365,r=255;
  for(let pc=0;pc<12;pc++){
    const a=pc/12*Math.PI*2-Math.PI/2;
    const x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r;
    P.circle(x,y,5,{color:P.palette.grid,fill:P.palette.background});
    P.text(pc,x,y-18,{size:11,align:"center",color:P.palette.muted});
  }
  path.chords.forEach((chord,ci)=>{
    const alpha=ci===Math.floor(t*(path.chords.length-1))?.95:.18;
    const points=chord.map(pc=>{
      const a=pc/12*Math.PI*2-Math.PI/2;
      return {x:cx+Math.cos(a)*r,y:cy+Math.sin(a)*r};
    });
    P.path([...points,points[0]],{color:ci%2?P.palette.negative:P.palette.positive,alpha,lineWidth:2});
  });
  P.text("VOICE-LEADING GEOMETRY",64,46,{size:17,weight:700});
  P.text(`total path distance ${path.totalDistance.toFixed(3)}`,64,675,{size:13,color:P.palette.muted});
}

export function renderValenceHypothesis(ctx,t,scene,env={}){
  const P=createPrimitives(ctx,env);P.clear();
  const features=env.valenceFeatures??experimentalValenceFeatures({
    points:createSpectralShape(env.audioFeatures??{},{}).points,
    frequencies:env.frequencies??[220,330,440],
    onsets:env.onsets??[0,.25,.5,.75],
    roughness:env.roughness??.2,
    noise:env.audioFeatures?.high??.2
  });
  const entries=[
    ["spatial symmetry",features.spatialSymmetry],
    ["rhythmic symmetry",features.rhythmicSymmetry],
    ["consonance proxy",features.consonanceProxy],
    ["roughness",features.roughness],
    ["noise",features.noise],
    ["hypothesis score",features.hypothesisScore]
  ];
  entries.forEach(([label,value],i)=>{
    const y=145+i*78;
    P.text(label,190,y,{size:16});
    P.line({x:440,y},{x:440+520*value,y},{color:i===5?P.palette.node:P.palette.positive,lineWidth:18,alpha:.5});
    P.text(value.toFixed(3),1000,y,{size:15,align:"right",weight:700});
  });
  P.text("EXPERIMENTAL SYMMETRY / VALENCE FEATURE VECTOR",64,46,{size:17,weight:700});
  P.text("hypothesis visualization — not a subjective-valence measurement",64,675,{size:13,color:P.palette.negative});
}

export const mechanismImplementations=Object.freeze({
  "chladni-response":renderChladni,
  "cymatic-particles":renderCymaticParticles,
  "spectral-morph":renderSpectralMorph,
  "voice-leading-geometry":renderVoiceLeading,
  "valence-hypothesis":renderValenceHypothesis
});
