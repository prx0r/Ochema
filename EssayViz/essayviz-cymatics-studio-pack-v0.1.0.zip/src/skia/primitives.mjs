import {CYMATICS_PALETTES} from "../color/index.mjs";

export function createPrimitives(ctx,{width=1280,height=720,palette="scientificWhite"}={}){
  const P=typeof palette==="string"?CYMATICS_PALETTES[palette]:palette;
  return {
    width,height,palette:P,
    clear(){
      ctx.fillStyle=P.background;ctx.fillRect(0,0,width,height);
    },
    line(a,b,{color=P.ink,alpha=1,lineWidth=1,dash=[]}={}){
      ctx.save();ctx.globalAlpha=alpha;ctx.strokeStyle=color;ctx.lineWidth=lineWidth;ctx.setLineDash(dash);
      ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.restore();
    },
    path(points,{color=P.ink,alpha=1,lineWidth=1,closed=false,fill=null}={}){
      if(!points.length)return;
      ctx.save();ctx.globalAlpha=alpha;ctx.strokeStyle=color;ctx.lineWidth=lineWidth;
      ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);
      for(let i=1;i<points.length;i++)ctx.lineTo(points[i].x,points[i].y);
      if(closed)ctx.closePath();
      if(fill){ctx.fillStyle=fill;ctx.fill();}
      ctx.stroke();ctx.restore();
    },
    circle(x,y,r,{color=P.ink,fill=null,alpha=1,lineWidth=1}={}){
      ctx.save();ctx.globalAlpha=alpha;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);
      if(fill){ctx.fillStyle=fill;ctx.fill();}
      ctx.strokeStyle=color;ctx.lineWidth=lineWidth;ctx.stroke();ctx.restore();
    },
    text(value,x,y,{size=16,color=P.ink,alpha=1,align="left",weight=400,font='"Source Serif 4", serif'}={}){
      ctx.save();ctx.globalAlpha=alpha;ctx.fillStyle=color;ctx.textAlign=align;ctx.textBaseline="middle";
      ctx.font=`${weight} ${size}px ${font}`;ctx.fillText(String(value),x,y);ctx.restore();
    }
  };
}
