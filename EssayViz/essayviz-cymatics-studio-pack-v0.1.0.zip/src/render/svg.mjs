import {generateModeBank,buildDrivenField} from "../chladni/index.mjs";
import {createParticles,stepParticles} from "../particles/index.mjs";
import {createSpectralShape} from "../morph/index.mjs";
import {voiceLeadingPath} from "../music-geometry/index.mjs";
import {experimentalValenceFeatures} from "../valence/index.mjs";
import {CYMATICS_PALETTES,acousticColor} from "../color/index.mjs";

const esc=s=>String(s).replace(/[&<>\"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const text=(x,y,s,size=16,c="#15191e",anchor="start",weight=400)=>`<text x="${x}" y="${y}" font-family="Georgia,serif" font-size="${size}" fill="${c}" text-anchor="${anchor}" font-weight="${weight}">${esc(s)}</text>`;
const line=(x1,y1,x2,y2,c,w=1,o=.7)=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${c}" stroke-width="${w}" stroke-opacity="${o}"/>`;
const circle=(x,y,r,c,o=1)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${c}" fill-opacity="${o}"/>`;
function shell(body,{title,subtitle,palette=CYMATICS_PALETTES.scientificWhite,width=1280,height=720}={}){
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}"><rect width="100%" height="100%" fill="${palette.background}"/>${text(46,48,title,23,palette.ink,"start",700)}${text(46,74,subtitle,13,palette.muted)}${body}</svg>`;
}

export function chladniSvg({modeIndex=7,time=.18,geometry="square",palette=CYMATICS_PALETTES.scientificWhite}={}){
  const modes=generateModeBank({geometry,maxOrder:6});
  const mode=modes[Math.min(modeIndex,modes.length-1)];
  const field=buildDrivenField([{...mode,amplitude:1}],{resolution:150,time});
  let body="";
  const x0=165,y0=110,size=500;
  for(let j=0;j<field.height;j+=2)for(let i=0;i<field.width;i+=2){
    const v=Math.abs(field.values[j*field.width+i]);
    const x=x0+i/(field.width-1)*size,y=y0+j/(field.height-1)*size;
    if(v<.04)body+=circle(x,y,1.35,palette.node,.8);
    else if(v>.82)body+=circle(x,y,.55,palette.positive,.12);
  }
  body+=`<rect x="${x0}" y="${y0}" width="${size}" height="${size}" fill="none" stroke="${palette.grid}"/>`;
  body+=text(765,170,mode.id,24,palette.ink,"start",700);
  body+=text(765,207,`${mode.frequency.toFixed(2)} Hz`,17,palette.positive);
  body+=text(765,260,"Nodal regions",14,palette.muted);
  body+=line(765,282,1090,282,palette.node,8,.65);
  body+=text(765,345,"Status",14,palette.muted);
  body+=text(765,374,mode.status,14,palette.ink);
  return shell(body,{title:"CHLADNI PLATE / MODAL GEOMETRY",subtitle:"Particles accumulate near low-displacement nodal regions; apparatus parameters determine the pattern.",palette});
}

export function particleSvg({steps=80,palette=CYMATICS_PALETTES.scientificWhite}={}){
  const mode=generateModeBank({geometry:"square",maxOrder:5})[7];
  const field=buildDrivenField([{...mode,amplitude:1}],{resolution:100,time:.1});
  let particles=createParticles({count:2500,seed:9});
  for(let i=0;i<steps;i++)particles=stepParticles(particles,field,{dt:.035,seed:9+i});
  let body=`<rect x="280" y="100" width="600" height="520" fill="none" stroke="${palette.grid}"/>`;
  for(const p of particles)body+=circle(580+p.x*245,360+p.y*245,1.05,palette.particle,.58);
  body+=text(930,220,"Particle migration",18,palette.ink,"start",700);
  body+=text(930,253,"gradient descent on",14,palette.muted);
  body+=text(930,277,"|displacement|",14,palette.muted);
  return shell(body,{title:"CYMATIC PARTICLE TRANSPORT",subtitle:"A diagnostic particle model exposes nodal organization without claiming full granular-material physics.",palette});
}

export function spectralMorphSvg({features={rms:.65,low:.58,mid:.35,high:.42,spectralCentroid:.57},time=.35,palette=CYMATICS_PALETTES.fluidNight}={}){
  const shape=createSpectralShape(features,{samples:480,time});
  const pts=shape.points.map(p=>({x:640+p.x*235,y:365+p.y*235}));
  const d=pts.map((p,i)=>`${i?"L":"M"} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(" ")+" Z";
  let body="";
  const color=acousticColor(features);
  for(let k=5;k>=0;k--){
    const s=1-k*.09;
    const dd=pts.map((p,i)=>`${i?"L":"M"} ${(640+(p.x-640)*s).toFixed(2)} ${(365+(p.y-365)*s).toFixed(2)}`).join(" ")+" Z";
    body+=`<path d="${dd}" fill="none" stroke="${color}" stroke-width="${k?1:2.5}" stroke-opacity="${k?.14:.95}"/>`;
  }
  body+=text(55,660,`m=${shape.parameters.m} · n₁=${shape.parameters.n1.toFixed(2)} · color=spectrum`,14,palette.muted);
  return shell(body,{title:"AUDIO-DERIVED MORPHING GEOMETRY",subtitle:"Generative art layer: shape and color respond to features but remain distinct from physical cymatic simulation.",palette});
}

export function voiceLeadingSvg({palette=CYMATICS_PALETTES.tantricManuscript}={}){
  const chords=[[0,4,7],[0,3,7],[2,5,9],[0,4,7]];
  const result=voiceLeadingPath(chords),cx=570,cy=370,r=245;
  let body="";
  for(let pc=0;pc<12;pc++){
    const a=pc/12*Math.PI*2-Math.PI/2,x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r;
    body+=circle(x,y,4,palette.node,.9)+text(x,y-15,pc,11,palette.muted,"middle");
  }
  result.chords.forEach((chord,i)=>{
    const pts=chord.map(pc=>{const a=pc/12*Math.PI*2-Math.PI/2;return{x:cx+Math.cos(a)*r,y:cy+Math.sin(a)*r};});
    const d=[...pts,pts[0]].map((p,j)=>`${j?"L":"M"} ${p.x} ${p.y}`).join(" ");
    body+=`<path d="${d}" fill="none" stroke="${i%2?palette.negative:palette.positive}" stroke-width="2" stroke-opacity="${.2+i*.18}"/>`;
  });
  body+=text(890,210,"Chord path",17,palette.ink,"start",700);
  result.steps.forEach((s,i)=>body+=text(890,255+i*50,`${i+1}: ${s.distance.toFixed(3)}`,15,palette.muted));
  body+=text(890,470,`Total ${result.totalDistance.toFixed(3)}`,19,palette.node,"start",700);
  return shell(body,{title:"TYMOCZKO-INSPIRED VOICE-LEADING GEOMETRY",subtitle:"Chords are normalized pitch-class sets; paths show efficient voice motion, not emotional meaning.",palette});
}

export function valenceSvg({palette=CYMATICS_PALETTES.scientificWhite}={}){
  const features=experimentalValenceFeatures({
    points:createSpectralShape({low:.4,mid:.7,high:.2,spectralCentroid:.45}).points,
    frequencies:[220,330,440,550],
    onsets:[0,.25,.5,.75],
    roughness:.18,noise:.22
  });
  const rows=[
    ["Spatial symmetry",features.spatialSymmetry],
    ["Rhythmic symmetry",features.rhythmicSymmetry],
    ["Consonance proxy",features.consonanceProxy],
    ["Roughness",features.roughness],
    ["Noise",features.noise],
    ["Hypothesis score",features.hypothesisScore]
  ];
  let body="";
  rows.forEach(([label,v],i)=>{
    const y=145+i*78;
    body+=text(170,y,label,16,palette.ink);
    body+=line(450,y,450+540*v,y,i===5?palette.node:palette.positive,18,.55);
    body+=text(1060,y,v.toFixed(3),15,palette.ink,"end",700);
  });
  body+=text(170,650,"Exploratory structural features — not a measure of felt pleasure or suffering.",14,palette.negative);
  return shell(body,{title:"QRI-INSPIRED SYMMETRY / VALENCE HYPOTHESIS",subtitle:"Optional child pack: symmetry, consonance, roughness and noise are exposed as testable features.",palette});
}
