import {TAU,clamp,lerp} from "../core/math.mjs";

export function superformulaRadius(theta,{
  m=6,n1=.3,n2=1.7,n3=1.7,a=1,b=1
}={}){
  const x=Math.pow(Math.abs(Math.cos(m*theta/4)/a),n2);
  const y=Math.pow(Math.abs(Math.sin(m*theta/4)/b),n3);
  return Math.pow(x+y,-1/n1);
}

export function spectrumToShapeParameters(features={}){
  const low=clamp(features.low??0),mid=clamp(features.mid??0),high=clamp(features.high??0);
  const centroid=clamp(features.spectralCentroid??features.centroid??.5);
  return {
    m:2+Math.round(10*centroid),
    n1:lerp(.24,1.4,1-mid),
    n2:lerp(.8,4.5,high),
    n3:lerp(.8,4.5,low),
    twist:lerp(-.5,.5,high-low),
    radialPulse:lerp(.02,.18,features.rms??0)
  };
}

export function createSpectralShape(features={},{
  samples=360,time=0,baseRadius=1
}={}){
  const p=spectrumToShapeParameters(features),points=[];
  for(let i=0;i<samples;i++){
    const theta=i/samples*TAU;
    const radius=baseRadius*superformulaRadius(theta+time*p.twist,p)*(1+p.radialPulse*Math.sin(TAU*time+p.m*theta));
    points.push({x:radius*Math.cos(theta),y:radius*Math.sin(theta),theta,radius});
  }
  return {points,parameters:p,status:"generative audio geometry; not an apparatus response"};
}

export function morphPointSets(a,b,t){
  const n=Math.max(a.length,b.length),out=[];
  for(let i=0;i<n;i++){
    const pa=a[Math.floor(i*a.length/n)%a.length],pb=b[Math.floor(i*b.length/n)%b.length];
    out.push({x:lerp(pa.x,pb.x,t),y:lerp(pa.y,pb.y,t)});
  }
  return out;
}
