export const TAU=Math.PI*2;
export const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
export const lerp=(a,b,t)=>a+(b-a)*t;
export const smoothstep=(a,b,x)=>{
  const t=clamp((x-a)/(b-a||1));
  return t*t*(3-2*t);
};
export function linspace(a,b,n){
  return Array.from({length:n},(_,i)=>lerp(a,b,n===1?0:i/(n-1)));
}
export function mean(xs){return xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:0;}
export function rms(xs){return Math.sqrt(mean(xs.map(x=>x*x)));}
export function normalizeVector(xs){
  const n=Math.sqrt(xs.reduce((s,x)=>s+x*x,0))||1;
  return xs.map(x=>x/n);
}
export function seededRng(seed=1){
  let x=(seed>>>0)||1;
  return ()=>{
    x^=x<<13;x^=x>>>17;x^=x<<5;
    return (x>>>0)/4294967296;
  };
}
export function finite(x,label="value"){
  if(!Number.isFinite(x))throw new Error(`${label} must be finite`);
  return x;
}
