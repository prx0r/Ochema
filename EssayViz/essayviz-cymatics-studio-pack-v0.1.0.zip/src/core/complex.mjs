export const c=(re=0,im=0)=>({re,im});
export const cAdd=(a,b)=>c(a.re+b.re,a.im+b.im);
export const cMul=(a,b)=>c(a.re*b.re-a.im*b.im,a.re*b.im+a.im*b.re);
export const cScale=(a,s)=>c(a.re*s,a.im*s);
export const cAbs=a=>Math.hypot(a.re,a.im);
export const cExp=theta=>c(Math.cos(theta),Math.sin(theta));
