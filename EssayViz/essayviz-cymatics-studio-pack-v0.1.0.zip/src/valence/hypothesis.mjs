import {clamp} from "../core/math.mjs";
import {rhythmicSymmetry} from "../music-geometry/rhythm.mjs";

export function spatialSymmetry(points,{orders=16}={}){
  if(!points.length)return {order:1,score:0};
  const center=points.reduce((s,p)=>({x:s.x+p.x,y:s.y+p.y}),{x:0,y:0});
  center.x/=points.length;center.y/=points.length;
  let best={order:1,score:0};
  for(let order=1;order<=orders;order++){
    let re=0,im=0,total=0;
    for(const p of points){
      const x=p.x-center.x,y=p.y-center.y,a=Math.atan2(y,x),r=Math.hypot(x,y);
      re+=r*Math.cos(order*a);im+=r*Math.sin(order*a);total+=r;
    }
    const score=total?Math.hypot(re,im)/total:0;
    if(score>best.score)best={order,score};
  }
  return best;
}

export function consonanceProxy(frequencies,{tolerance=.025,maxDenominator=12}={}){
  if(frequencies.length<2)return 1;
  let score=0,count=0;
  for(let i=0;i<frequencies.length;i++)for(let j=i+1;j<frequencies.length;j++){
    const ratio=Math.max(frequencies[i],frequencies[j])/Math.min(frequencies[i],frequencies[j]);
    let best=0;
    for(let q=1;q<=maxDenominator;q++)for(let p=q;p<=2*q;p++){
      const target=p/q,error=Math.abs(ratio-target)/target;
      best=Math.max(best,Math.exp(-error/tolerance)/(p+q-1));
    }
    score+=best;count++;
  }
  return count?clamp(score/count*5):0;
}

export function experimentalValenceFeatures({
  points=[],frequencies=[],onsets=[],period=1,roughness=0,noise=0
}={}){
  const spatial=spatialSymmetry(points);
  const rhythm=rhythmicSymmetry(onsets,{period});
  const consonance=consonanceProxy(frequencies);
  return {
    spatialSymmetry:spatial.score,
    spatialOrder:spatial.order,
    rhythmicSymmetry:rhythm.score,
    rhythmicOrder:rhythm.order,
    consonanceProxy:consonance,
    roughness:clamp(roughness),
    noise:clamp(noise),
    hypothesisScore:clamp(
      .30*spatial.score+.25*rhythm.score+.30*consonance-.10*roughness-.05*noise
    ),
    epistemicStatus:"exploratory feature vector inspired by symmetry-valence hypotheses; not a valence measurement"
  };
}

export function validateValenceConfig(config={}){
  const errors=[];
  if(config.claimsMeasuredValence===true)errors.push("This pack may not claim measured subjective valence.");
  if(config.epistemicStatus!=="hypothesis"&&config.epistemicStatus!=="exploratory")errors.push("valence child must be hypothesis or exploratory");
  return {valid:errors.length===0,errors};
}
