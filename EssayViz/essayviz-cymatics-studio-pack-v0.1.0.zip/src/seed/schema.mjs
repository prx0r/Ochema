export const CHILD_PACK_TYPES=Object.freeze([
  "apparatus","phoneme-atlas","generative-art","music-geometry",
  "color-mapping","valence-hypothesis","experimental-capture"
]);

export const CYMATICS_CHILD_SEED=Object.freeze({
  version:"1.0",
  id:"child-pack-id",
  title:"Child Pack",
  type:"generative-art",
  extends:["cymatics-core"],
  scientificCore:{
    sourceSignal:"features.json",
    apparatus:null,
    equation:null,
    parameters:{},
    invariants:[],
    measurements:[],
    epistemicStatus:"simulation"
  },
  artisticLayer:{
    mechanism:"spectral-shape",
    style:"scientificWhite",
    colorMapping:{
      hue:"spectralCentroid",
      saturation:"high",
      lightness:"rms"
    },
    audioRoutes:[],
    camera:{},
    typography:{}
  },
  agentContract:{
    useCases:[],
    requiredInputs:[],
    forbiddenClaims:[],
    reviewTests:[]
  }
});

export function validateChildSeed(seed){
  const errors=[];
  for(const key of ["version","id","title","type","extends","scientificCore","artisticLayer","agentContract"])
    if(seed[key]===undefined)errors.push(`missing ${key}`);
  if(!CHILD_PACK_TYPES.includes(seed.type))errors.push(`unsupported type ${seed.type}`);
  if(!Array.isArray(seed.scientificCore?.invariants))errors.push("scientificCore.invariants must be array");
  if(!Array.isArray(seed.agentContract?.forbiddenClaims))errors.push("agentContract.forbiddenClaims must be array");
  if(seed.type==="valence-hypothesis"&&!["hypothesis","exploratory"].includes(seed.scientificCore?.epistemicStatus))
    errors.push("valence child must be marked hypothesis or exploratory");
  return {valid:errors.length===0,errors};
}

export function createChildSeed(overrides={}){
  const seed=structuredClone(CYMATICS_CHILD_SEED);
  const merge=(a,b)=>{
    for(const [k,v] of Object.entries(b??{})){
      if(v&&typeof v==="object"&&!Array.isArray(v)&&a[k]&&typeof a[k]==="object"&&!Array.isArray(a[k]))merge(a[k],v);
      else a[k]=structuredClone(v);
    }
    return a;
  };
  return merge(seed,overrides);
}
