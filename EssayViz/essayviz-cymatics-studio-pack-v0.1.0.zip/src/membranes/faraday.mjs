import {TAU,clamp} from "../core/math.mjs";

export function createFaradayPattern({
  symmetry=6,wavenumber=9,secondaryRatio=.35,
  phase=0,rotation=0,amplitude=1
}={}){
  const directions=Array.from({length:symmetry},(_,i)=>rotation+i*Math.PI/symmetry);
  return {
    id:`faraday-${symmetry}`,
    symmetry,wavenumber,phase,amplitude,
    evaluate:(x,y,time=0)=>{
      let z=0;
      for(let i=0;i<directions.length;i++){
        const a=directions[i];
        z+=Math.cos(wavenumber*(Math.cos(a)*x+Math.sin(a)*y)+phase+i*secondaryRatio+TAU*time);
      }
      return amplitude*z/directions.length;
    },
    status:"modal pattern generator; not a full Navier-Stokes solver"
  };
}

export function selectFaradaySymmetry({
  viscosity=.001,depth=.006,forcingFrequency=40,forcingAmplitude=.2
}={}){
  const capillaryBias=clamp((forcingFrequency-20)/80);
  const shallowBias=clamp((.012-depth)/.012);
  const damping=clamp(viscosity/.02);
  if(forcingAmplitude<.08)return {symmetry:0,regime:"below-threshold"};
  if(damping>.65)return {symmetry:2,regime:"stripes"};
  if(capillaryBias>.62)return {symmetry:4,regime:"square"};
  if(shallowBias>.55)return {symmetry:6,regime:"hexagonal"};
  return {symmetry:8,regime:"quasipattern-candidate"};
}
