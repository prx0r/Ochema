import {TAU} from "../core/math.mjs";
export function rhythmCircle(onsets,{period=1}={}){
  return onsets.map((time,i)=>{
    const phase=((time%period)+period)%period/period;
    return {id:i,time,phase,x:Math.cos(TAU*phase),y:Math.sin(TAU*phase)};
  });
}
export function rhythmicSymmetry(onsets,{period=1,orders=16}={}){
  const pts=rhythmCircle(onsets,{period});
  let best={order:1,score:0};
  for(let order=1;order<=orders;order++){
    let re=0,im=0;
    for(const p of pts){re+=Math.cos(TAU*order*p.phase);im+=Math.sin(TAU*order*p.phase);}
    const score=pts.length?Math.hypot(re,im)/pts.length:0;
    if(score>best.score)best={order,score};
  }
  return best;
}
