import {clamp,lerp} from "../core/math.mjs";

export const CYMATICS_PALETTES=Object.freeze({
  scientificWhite:{
    background:"#fbfaf6",ink:"#15191e",muted:"#68717a",grid:"#ddd8ce",
    negative:"#a6434a",positive:"#4b7795",node:"#aa7c2e",particle:"#232a31"
  },
  fluidNight:{
    background:"#080d18",ink:"#eef3f8",muted:"#91a0af",grid:"#24384a",
    negative:"#d36b82",positive:"#6ad5e8",node:"#f4ca64",particle:"#f6f7fb"
  },
  tantricManuscript:{
    background:"#f3ead7",ink:"#2a2118",muted:"#746557",grid:"#c8b89d",
    negative:"#9c3943",positive:"#39677a",node:"#b47b2a",particle:"#3b3024"
  }
});

export function hsl(h,s,l){return `hsl(${((h%360)+360)%360}, ${clamp(s,0,100)}%, ${clamp(l,0,100)}%)`;}

export function acousticColor(features={},{
  hueRange=[210,20],saturation=[35,88],lightness=[34,66]
}={}){
  const centroid=clamp(features.spectralCentroid??features.centroid??.5);
  const rms=clamp(features.rms??.4);
  const noisiness=clamp(features.noisiness??features.high??.2);
  let h=lerp(hueRange[0],hueRange[1],centroid);
  if(hueRange[0]>hueRange[1])h=lerp(hueRange[0],hueRange[1]+360,centroid);
  return hsl(h,lerp(saturation[0],saturation[1],noisiness),lerp(lightness[0],lightness[1],rms));
}

export function semanticColorChannels(features={}){
  return {
    hueMeaning:"spectral centroid",
    saturationMeaning:"high-frequency/noise proportion",
    lightnessMeaning:"RMS amplitude",
    color:acousticColor(features)
  };
}
