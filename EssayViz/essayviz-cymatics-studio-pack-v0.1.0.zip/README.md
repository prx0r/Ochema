# EssayViz Cymatics Studio 0.1

A tested seed package for:

- Chladni plate and membrane visualizations;
- nodal-particle transport;
- simplified Faraday-pattern generation;
- Sanskrit phoneme acoustic experiments;
- audio-derived morphing geometry;
- generative art and semantic color;
- Tymoczko-inspired voice-leading paths;
- QRI-inspired, explicitly hypothetical structural-valence features;
- agent-authored child configurations.

## Install

```bash
npm install
npm test
npm run validate
npm run demo
npm run e2e
```

The Mathematics package is a peer dependency:

```bash
npm install ./prx0r-essayviz-mathematics-0.2.0.tgz
```

## Core principle

```text
apparatus response ≠ generative art ≠ valence hypothesis
```

All three may use the same audio, but they must remain labelled.

## Agent entry points

Read:

```text
skills/CYMATICS-STUDIO-DIRECTOR.md
skills/CYMATICS-CHILD-PACK-AUTHOR.md
skills/SANSKRIT-PHONEME-LAB.md
```

## Child examples

```text
examples/children/sanskrit-vowel-atlas.json
examples/children/tymoczko-voice-leading.json
examples/children/qri-valence-experiment.json
```

## Current reference limitations

- the JavaScript DFT is a correctness/reference implementation, not a
  production real-time FFT;
- square and circular modes are analytic approximations;
- Faraday patterns are modal generators rather than full fluid simulations;
- particle transport approximates nodal migration;
- the voice-leading implementation is compact and factorial for small chords;
- valence features are hypotheses, not subjective measurements.
