import {
  capabilityRegistry, compositionRegistry, styleRegistry, motionRegistry,
  signalRegistry, typographyRegistry, motifRegistry
} from "./index.mjs";

let initialized = false;
export function registerBuiltins() {
  if (initialized) return;
  initialized = true;

  for (const id of [
    "base","human-anatomy","yogic-subtle-body","neurocognition",
    "invariant-composition","pathkit-geometry","particle-fields",
    "audio-reactive","tantric-geometry","comparative-epistemology",
    "systems-dynamics","temporal-processes","textual-scholarship"
  ]) capabilityRegistry.register(id, { kind: "capability" });

  compositionRegistry
    .register("proof-and-frontier", { stages:["contention","premises","rival","discriminator","framework-update","frontier"] })
    .register("recognition-arc", { stages:["ordinary-model","instability","preparation","recognition","assimilation"] })
    .register("causal-explanation", { stages:["state","disturbance","mechanism","feedback","failure","regulation"] })
    .register("formal-tournament", { stages:["candidates","homology-test","rejections","selection","realization","exam"] })
    .register("ritual-progression", { stages:["boundary","purification","installation","activation","identification","dissolution"] });

  styleRegistry
    .register("crisp-white-notation", { theme:"whiteScientific", density:"sparse", material:"ink" })
    .register("technical-neural", { theme:"whiteScientific", density:"medium", material:"signal" })
    .register("ritual-gold", { theme:"midnightVellum", density:"medium", material:"gold-light" })
    .register("mineral-manuscript", { theme:"ivoryManuscript", density:"medium", material:"pigment" })
    .register("visionary-midnight", { theme:"midnightVellum", density:"variable", material:"luminous-field" })
    .register("ash-and-ember", { theme:"midnightVellum", density:"sparse", material:"ember" });

  motionRegistry
    .register("proof-mutation", { verbs:["create-edge","cut-edge","branch","converge","bracket"] })
    .register("causal-memory", { verbs:["trace","retain","decay","return"] })
    .register("breath-current", { verbs:["expand","contract","alternate","entrain"] })
    .register("growth-repair", { verbs:["branch","damage","recover","stabilize"] })
    .register("phase-entrainment", { verbs:["oscillate","synchronize","desynchronize"] });

  signalRegistry
    .register("narration-attention", { buses:["narration"], policy:"suppress-competing-information" })
    .register("formal-score", { buses:["score"], policy:"formal-causality" })
    .register("performed-audio", { buses:["music"], policy:"performance-modulation" })
    .register("hybrid-counterpoint", { buses:["score","music","narration"], policy:"separate-responsibilities" });

  typographyRegistry.register("logicvid-serif-math", {
    proseFamily:"Source Serif 4", mathFamily:"KaTeX Math",
    iastFamily:"Source Serif 4", devanagariFamily:"Noto Serif Devanagari",
    minimumBodyPx:14, background:"white", maxProseBlocks:3
  });

  for (const id of ["semantic-essay","argument-diagram","argument-diagram-v2","logical-argument","composition"]) {
    motifRegistry.register(id, { kind:"kernel-motif" });
  }
}
