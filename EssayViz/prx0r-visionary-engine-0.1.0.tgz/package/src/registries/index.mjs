import { Registry } from "./registry.mjs";
export const capabilityRegistry = new Registry("capabilities");
export const compositionRegistry = new Registry("composition profiles");
export const styleRegistry = new Registry("style profiles");
export const motionRegistry = new Registry("motion profiles");
export const signalRegistry = new Registry("signal profiles");
export const typographyRegistry = new Registry("typography profiles");
export const motifRegistry = new Registry("motifs");
export { Registry };
