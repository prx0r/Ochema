import { registerBuiltins } from "../registries/builtins.mjs";
import { validateProject } from "../validation/project-validator.mjs";
import {
  planArgument,planContinuity,planCandidates,planStoryboard,planTypography,
  planSignals,planTiming,planRender,planReview
} from "../planners/index.mjs";
import { compileScenePack } from "./scene-pack-compiler.mjs";

export function compileProject(project) {
  registerBuiltins();
  validateProject(project);
  const argumentIR=planArgument(project);
  const continuity=planContinuity(project,argumentIR);
  const candidates=planCandidates(argumentIR);
  const storyboard=planStoryboard(project,argumentIR,candidates);
  const typography=planTypography(project,storyboard);
  const signals=planSignals(project,storyboard);
  const timing=planTiming(project,storyboard);
  const scenePack=compileScenePack(project,storyboard,timing);
  const renderPlan=planRender(project,storyboard,timing,signals);
  const reviewPlan=planReview(storyboard);
  return {argumentIR,continuity,candidates,storyboard,typography,signals,timing,scenePack,renderPlan,reviewPlan};
}
