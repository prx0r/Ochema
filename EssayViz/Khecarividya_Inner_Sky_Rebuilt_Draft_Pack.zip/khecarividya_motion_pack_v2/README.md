# Khecarīvidyā — The Inner Sky (Rebuilt Edition)

A completely redrawn 20-scene motion-graphics pack.

## Render specification
- Resolution: 1920×1080
- Frame rate: 12 fps
- Scene count: 20
- Duration per scene: 8.0 seconds
- Total duration: 160.0 seconds
- Codec: H.264, yuv420p, CRF 18

## Design changes
- No ruled or lined backgrounds.
- White museum-field default.
- Black or colour used only when doctrinally relevant.
- New assets, new compositions, no recolored reuse from earlier packs.
- Minimal direct captions rather than large footer cards.

## Requirements
- Python 3.10+
- Pillow
- NumPy
- FFmpeg / ffprobe

## Render
```bash
python render_pack.py
```

The renderer is deterministic and resume-safe. Existing complete frames and valid scene MP4s are skipped unless `--force` is supplied.
