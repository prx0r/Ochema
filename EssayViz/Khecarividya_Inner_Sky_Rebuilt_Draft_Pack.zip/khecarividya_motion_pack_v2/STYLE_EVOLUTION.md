# STYLE EVOLUTION — Khecarīvidyā V2

## User-directed correction
- Deprecated all ruled and lined manuscript backgrounds.
- White is now the default field.
- Black, indigo, ruby, and botanical green appear only when the scene's doctrine materially requires inner sky, luminosity, ritual seed, or herbarium imagery.
- Scene length increased from 4.8 to 8 seconds.
- Resolution increased from 1280×720 to 1920×1080.

## New material vocabulary
1. white lacquer;
2. obsidian aperture;
3. nacre valve;
4. suspended moon bowl;
5. silver membrane;
6. ruby enamel key;
7. optical critical lenses;
8. mineral shell vault;
9. pressed botanical relief;
10. copper ember-thread.

## New relationships
- dispersed witnesses → intersecting critical focus;
- exterior sky → folded interior architecture;
- leak → membrane closure → stable circulation;
- oscillation → phase-locking → shared stillness;
- underpainting → cut-window revelation;
- redaction → coverage without total erasure.

## Deprecated motifs
- lined paper as universal scholarly texture;
- repeated manuscript cards;
- repeated arch silhouettes;
- decorative stars outside conceptually relevant inner-sky scenes;
- generic anatomy outlines;
- footer boxes dominating the art.

## Transition grammar
The pack now transitions internally by aperture opening, optical convergence, membrane closure, counterflow turns, lacquer coverage, and botanical unfolding rather than by simple fade-in.

## Closing seal
The final Moon-Key cosmogram combines thirty-one witness stars, a lunar gate, a reversed ruby current, a sealed pearl orbit, and a still central drop.
