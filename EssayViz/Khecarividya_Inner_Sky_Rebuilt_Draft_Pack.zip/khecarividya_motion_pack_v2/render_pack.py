#!/usr/bin/env python3
"""Khecarīvidyā — The Inner Sky, rebuilt as a high-resolution motion-graphics pack.

Design revision goals:
- no ruled or lined manuscript backgrounds;
- white museum-field default, black/colour only when conceptually justified;
- completely redrawn scene assets and compositions;
- longer 8-second scenes at 1920x1080;
- deterministic, resume-safe rendering;
- symbolic/doctrinal visualization, not practical instruction.
"""
from __future__ import annotations

import argparse
import json
import math
import random
import shutil
import subprocess
import textwrap
import zipfile
from pathlib import Path
from typing import Callable

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent
FRAMES = ROOT / "frames"
SCENES_DIR = ROOT / "scenes"
W, H = 1920, 1080
FPS = 12
DURATION = 8.0
NFRAMES = int(FPS * DURATION)
SEED = 53917

# Clean sculptural palette.
WHITE = (248, 248, 246)
COOL_WHITE = (236, 239, 242)
INK = (19, 21, 25)
CHARCOAL = (40, 43, 49)
BLACK = (5, 7, 12)
INDIGO = (13, 24, 51)
MIDNIGHT = (7, 13, 31)
MOON = (226, 232, 231)
PEARL = (249, 244, 226)
SILVER = (177, 188, 199)
CINNABAR = (169, 35, 46)
RUBY = (119, 18, 37)
SAFFRON = (225, 143, 35)
COPPER = (151, 94, 57)
VERDIGRIS = (59, 122, 112)
VIOLET = (92, 70, 132)
LEAF = (97, 126, 79)
PALE_GREEN = (229, 236, 218)
SKY_BLUE = (92, 148, 199)

FONT_SERIF = "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"
FONT_SERIF_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"
FONT_SANS = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_SANS_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
TITLE_FONT = ImageFont.truetype(FONT_SERIF_BOLD, 44)
SUB_FONT = ImageFont.truetype(FONT_SERIF, 25)
TERM_FONT = ImageFont.truetype(FONT_SANS_BOLD, 22)
NUM_FONT = ImageFont.truetype(FONT_SANS_BOLD, 18)
SMALL_FONT = ImageFont.truetype(FONT_SANS, 20)
TINY_FONT = ImageFont.truetype(FONT_SANS, 15)


def clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def smooth(a: float, b: float, x: float) -> float:
    if a == b:
        return 1.0 if x >= b else 0.0
    t = clamp((x - a) / (b - a))
    return t * t * (3 - 2 * t)


def ease(t: float) -> float:
    return 0.5 - 0.5 * math.cos(math.pi * clamp(t))


def out(t: float) -> float:
    t = clamp(t)
    return 1 - (1 - t) ** 3


def back(t: float) -> float:
    t = clamp(t)
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def mix(a, b, t: float):
    return tuple(int(lerp(x, y, clamp(t))) for x, y in zip(a, b))


def rgba(c, a=255):
    return (*c[:3], int(a))


def P(x: float, y: float) -> tuple[float, float]:
    return (x * W, y * H)


def layer() -> Image.Image:
    return Image.new("RGBA", (W, H), (0, 0, 0, 0))


def solid_bg(color) -> Image.Image:
    return Image.new("RGBA", (W, H), rgba(color, 255))


def vertical_gradient(top, bottom) -> Image.Image:
    arr = np.zeros((H, W, 4), dtype=np.uint8)
    ys = np.linspace(0, 1, H, dtype=np.float32)[:, None]
    for k in range(3):
        arr[..., k] = (top[k] * (1 - ys) + bottom[k] * ys).astype(np.uint8)
    arr[..., 3] = 255
    return Image.fromarray(arr, "RGBA")


def radial_gradient(inner, outer, cx=0.5, cy=0.42, radius=0.72) -> Image.Image:
    yy, xx = np.mgrid[0:H, 0:W]
    dx = (xx / W - cx) / radius
    dy = (yy / H - cy) / radius
    r = np.clip(np.sqrt(dx * dx + dy * dy), 0, 1)[..., None]
    a = np.array(inner, dtype=np.float32)[None, None, :]
    b = np.array(outer, dtype=np.float32)[None, None, :]
    rgb = a * (1 - r) + b * r
    alpha = np.full((H, W, 1), 255, dtype=np.float32)
    return Image.fromarray(np.uint8(np.clip(np.concatenate([rgb, alpha], axis=2), 0, 255)), "RGBA")


BG_WHITE = vertical_gradient((255, 255, 253), (239, 242, 245))
BG_WARM = vertical_gradient((255, 253, 246), (241, 238, 228))
BG_BLACK = radial_gradient((21, 32, 68), (3, 5, 12), .5, .43, .76)
BG_INDIGO = radial_gradient((28, 45, 86), (7, 11, 28), .5, .38, .74)
BG_GREEN = vertical_gradient((246, 249, 240), PALE_GREEN)
BG_RUBY = radial_gradient((126, 26, 44), (36, 7, 18), .5, .45, .9)


def scene_bg(kind: str) -> Image.Image:
    return {
        "white": BG_WHITE,
        "warm": BG_WARM,
        "black": BG_BLACK,
        "indigo": BG_INDIGO,
        "green": BG_GREEN,
        "ruby": BG_RUBY,
    }[kind].copy()


def shadow(im: Image.Image, shape_fn: Callable[[ImageDraw.ImageDraw], None], blur=28, opacity=70, offset=(0, 18)):
    sh = layer()
    d = ImageDraw.Draw(sh)
    shape_fn(d)
    if opacity != 255:
        alpha = sh.getchannel("A").point(lambda p: int(p * opacity / 255))
        sh.putalpha(alpha)
    sh = sh.filter(ImageFilter.GaussianBlur(blur))
    im.alpha_composite(sh, offset)


def glow(im: Image.Image, xy, radius, color, alpha=150, blur=28):
    x, y = xy
    g = layer()
    d = ImageDraw.Draw(g)
    d.ellipse((x - radius, y - radius, x + radius, y + radius), fill=rgba(color, alpha))
    g = g.filter(ImageFilter.GaussianBlur(blur))
    im.alpha_composite(g)


def line_glow(im: Image.Image, pts, color, width=5, alpha=190, blur=16):
    if len(pts) < 2:
        return
    g = layer()
    gd = ImageDraw.Draw(g)
    gd.line(pts, fill=rgba(color, alpha), width=width * 4, joint="curve")
    g = g.filter(ImageFilter.GaussianBlur(blur))
    im.alpha_composite(g)
    ImageDraw.Draw(im).line(pts, fill=rgba(color, 245), width=width, joint="curve")


def soft_disc(im: Image.Image, xy, radius, fill, outline=None, width=3, glow_color=None):
    x, y = xy
    if glow_color:
        glow(im, xy, radius * 1.15, glow_color, 75, int(radius * .35))
    d = ImageDraw.Draw(im)
    for i in range(max(1, int(radius))):
        t = i / max(1, radius)
        col = mix(fill, WHITE, .22 * (1 - t))
        r = radius - i
        d.ellipse((x - r, y - r, x + r, y + r), outline=rgba(col, 255), width=2)
    if outline:
        d.ellipse((x - radius, y - radius, x + radius, y + radius), outline=rgba(outline, 230), width=width)


def partial(pts, p: float):
    p = clamp(p)
    if p <= 0:
        return []
    if p >= 1:
        return pts
    f = p * (len(pts) - 1)
    i = int(f)
    q = f - i
    outp = list(pts[: i + 1])
    if i + 1 < len(pts):
        a, b = pts[i], pts[i + 1]
        outp.append((lerp(a[0], b[0], q), lerp(a[1], b[1], q)))
    return outp


def bezier(p0, p1, p2, p3, n=120):
    pts = []
    for i in range(n):
        t = i / (n - 1)
        u = 1 - t
        pts.append((
            u**3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t**3 * p3[0],
            u**3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t**3 * p3[1],
        ))
    return pts


def star_points(cx, cy, r1, r2, n=8, rot=-math.pi / 2):
    return [
        (cx + math.cos(rot + math.pi * i / n) * (r1 if i % 2 == 0 else r2),
         cy + math.sin(rot + math.pi * i / n) * (r1 if i % 2 == 0 else r2))
        for i in range(n * 2)
    ]


def caption(im: Image.Image, idx: int, title: str, subtitle: str, term: str, dark=False):
    d = ImageDraw.Draw(im)
    fg = WHITE if dark else INK
    muted = mix(WHITE, SILVER, .35) if dark else CHARCOAL
    accent = SAFFRON if dark else CINNABAR
    d.text(P(.055, .055), f"{idx:02d}", font=NUM_FONT, fill=rgba(accent, 235))
    d.text(P(.09, .048), title, font=TITLE_FONT, fill=rgba(fg, 245))
    d.line((W * .055, H * .915, W * .38, H * .915), fill=rgba(accent, 150), width=3)
    wrapped = textwrap.fill(subtitle, width=74)
    d.multiline_text(P(.055, .932), wrapped, font=SUB_FONT, fill=rgba(muted, 225), spacing=5, anchor="ls")
    if term:
        bbox = d.textbbox((0, 0), term, font=TERM_FONT)
        tw = bbox[2] - bbox[0]
        d.text((W * .945 - tw, H * .927), term, font=TERM_FONT, fill=rgba(accent, 235))


def draw_glass_arc(im, box, color, width=8, alpha=220, blur=12, start=180, end=360):
    g = layer()
    d = ImageDraw.Draw(g)
    d.arc(box, start, end, fill=rgba(color, alpha), width=width)
    if blur:
        glow_layer = g.filter(ImageFilter.GaussianBlur(blur))
        glow_layer.putalpha(glow_layer.getchannel("A").point(lambda p: int(p * .55)))
        im.alpha_composite(glow_layer)
    im.alpha_composite(g)


def draw_moon_bowl(im, cx, cy, rx, ry, level=0.72, opening=1.0):
    d = ImageDraw.Draw(im)
    # shadow
    sh = layer(); sd = ImageDraw.Draw(sh)
    sd.ellipse((cx-rx*.92, cy+ry*.4, cx+rx*.92, cy+ry*1.1), fill=(0,0,0,70))
    sh = sh.filter(ImageFilter.GaussianBlur(28)); im.alpha_composite(sh)
    # outer crescent shell
    d.pieslice((cx-rx, cy-ry, cx+rx, cy+ry), 0, 180, fill=rgba(MOON, 235), outline=rgba(SILVER, 235), width=4)
    inset = 20
    d.pieslice((cx-rx+inset, cy-ry+inset, cx+rx-inset, cy+ry-inset), 0, 180, fill=rgba(INDIGO, 245))
    # liquid surface
    y = cy - ry*(1-level)*.25
    d.ellipse((cx-rx*.72*opening, y-18, cx+rx*.72*opening, y+18), fill=rgba(PEARL, 230), outline=rgba(WHITE, 250), width=3)
    for r in (0.25, 0.48, 0.7):
        d.arc((cx-rx*r, y-14*r, cx+rx*r, y+14*r), 0, 180, fill=rgba(SILVER, 130), width=2)


def draw_pearl(im, x, y, r, alpha=255):
    if r <= 0.4:
        return
    if r < 2:
        ImageDraw.Draw(im).ellipse((x-r, y-r, x+r, y+r), fill=rgba(PEARL, alpha))
        return
    glow(im, (x, y), r * 1.2, MOON, int(alpha*.38), max(6, int(r*.65)))
    d = ImageDraw.Draw(im)
    for i in range(max(2, int(r))):
        rr = r - i
        t = i / max(1, r)
        col = mix(PEARL, SILVER, t*.38)
        d.ellipse((x-rr, y-rr, x+rr, y+rr), outline=rgba(col, alpha), width=2)
    d.ellipse((x-r*.45, y-r*.45, x-r*.05, y-r*.05), fill=rgba(WHITE, int(alpha*.8)))


def draw_ribbon(im, pts, color=CINNABAR, width=15, glow_alpha=150):
    line_glow(im, pts, color, width, glow_alpha, max(8, width))
    d = ImageDraw.Draw(im)
    # central highlight
    d.line(pts, fill=rgba(mix(color, WHITE, .35), 170), width=max(2, width//4), joint="curve")


def rotate_point(x, y, cx, cy, a):
    dx, dy = x-cx, y-cy
    return (cx + dx*math.cos(a)-dy*math.sin(a), cy + dx*math.sin(a)+dy*math.cos(a))


SCENES = [
    dict(id="kh01", title="Thirty-One Witnesses", subtitle="A critical text is reconstructed from a dispersed manuscript ecology.", term="textual constellation", bg="white"),
    dict(id="kh02", title="A Vidyā Becomes a Mudrā", subtitle="A deity-mantra framework is recast as an embodied seal.", term="vidyā → mudrā", bg="white"),
    dict(id="kh03", title="The Sky-Going Seal", subtitle="The ordinary sky folds inward and becomes a navigable interior expanse.", term="khe-carī", bg="black"),
    dict(id="kh04", title="The Palatal Gate", subtitle="A hidden threshold appears as a nacreous valve rather than a flat surface.", term="tālu-dvāra", bg="white"),
    dict(id="kh05", title="The Lunar Reservoir", subtitle="A suspended upper store gathers a precious, reflective fluid.", term="candra-kalāśa", bg="indigo"),
    dict(id="kh06", title="The Descending Drop", subtitle="Ordinary flow carries the subtle drop downward toward consumption and loss.", term="bindu-flow", bg="black"),
    dict(id="kh07", title="The Reversal", subtitle="A settled current turns back upon itself and begins to rise.", term="ūrdhva-vṛtti", bg="white"),
    dict(id="kh08", title="The Tongue as Key", subtitle="A mobile red seal becomes the symbolic key to an upper chamber.", term="jihvā-mudrā", bg="white"),
    dict(id="kh09", title="Sealing the Leak", subtitle="An open system closes into a stable, circulating field.", term="bandha", bg="black"),
    dict(id="kh10", title="Breath and Mind Quiet Together", subtitle="Two independent oscillations lose amplitude and resolve into shared stillness.", term="nirodha", bg="white"),
    dict(id="kh11", title="The Cranial Vault", subtitle="A bodily cavity becomes luminous shell architecture and inner sanctuary.", term="brahma-candra", bg="black"),
    dict(id="kh12", title="Moving in Inner Space", subtitle="A mobile star-field turns around an unmoving interval.", term="antar-ākāśa", bg="indigo"),
    dict(id="kh13", title="The Khecarī Vidyā", subtitle="Seed, circuit, embodied form, and silence become one transformative sequence.", term="vidyā", bg="ruby"),
    dict(id="kh14", title="The Kaula Undercurrent", subtitle="An earlier ritual world remains visible beneath a later haṭhayogic surface.", term="palimpsest", bg="white"),
    dict(id="kh15", title="Orthodox Redaction", subtitle="A clean transmission surface covers what it cannot entirely erase.", term="redaction", bg="white"),
    dict(id="kh16", title="The Added Herbarium", subtitle="A later botanical appendix enters as a distinct material and conceptual layer.", term="chapter IV", bg="green"),
    dict(id="kh17", title="A Corpus of Different Approaches", subtitle="Several pathways circle the same hidden threshold without becoming identical.", term="textual variants", bg="white"),
    dict(id="kh18", title="The Ascetic Preserve", subtitle="A fragile technique survives through a narrow chain of restricted transmission.", term="lineage field", bg="warm"),
    dict(id="kh19", title="A Text in Circulation", subtitle="The work travels between regions, communities, and material forms.", term="citation network", bg="white"),
    dict(id="kh20", title="The Seal of the Moon-Key", subtitle="Witnesses, lunar store, red key, reversed flow, and inner sky converge as a closing cosmogram.", term="khecarī-seal", bg="black"),
]


def sc01(im, t):
    d = ImageDraw.Draw(im)
    cx, cy = P(.54, .48)
    p = smooth(.02, .66, t)
    # 31 independent witness marks: not leaves or reused pages.
    for i in range(31):
        rng = random.Random(SEED + i * 101)
        a = 2 * math.pi * i / 31 + .22
        radius = 410 + 180 * (i % 3) / 2
        sx = cx + math.cos(a) * radius
        sy = cy + math.sin(a) * radius * .62
        tx = cx + math.cos(a * 3.0) * 105
        ty = cy + math.sin(a * 2.0) * 70
        q = ease(clamp(p * 1.25 - i * .008))
        x, y = lerp(sx, tx, q), lerp(sy, ty, q)
        rot = a + (1-q)*1.3
        length = 28 + rng.random()*46
        x1 = x + math.cos(rot)*length
        y1 = y + math.sin(rot)*length
        d.line((x, y, x1, y1), fill=rgba(INK, 90 + int(120*q)), width=3)
        if i % 3 == 0:
            d.ellipse((x-4, y-4, x+4, y+4), fill=rgba(CINNABAR, 170))
    q = smooth(.45, .88, t)
    # Critical apparatus: three translucent lenses intersect, producing a precise center.
    for j, col in enumerate((SKY_BLUE, SAFFRON, CINNABAR)):
        a = (j-1)*math.pi/3
        r = 145*q
        ox, oy = math.cos(a)*65*q, math.sin(a)*40*q
        d.ellipse((cx-r+ox, cy-r*.62+oy, cx+r+ox, cy+r*.62+oy), outline=rgba(col, 170), width=6)
    if q:
        draw_pearl(im, cx, cy, 25 + 20*q)
        d.text((cx, cy+120*q), "KHECARĪVIDYĀ", font=TERM_FONT, fill=rgba(INK, int(240*q)), anchor="mm")


def sc02(im, t):
    d = ImageDraw.Draw(im)
    p = smooth(.02, .6, t)
    # Left: abstract seed-wheel. Right: sculptural lock. A ribbon transforms between them.
    lc = P(.28, .46); rc = P(.74, .46)
    for i in range(12):
        a = i*2*math.pi/12 + t*.6
        r = 145
        x = lc[0] + math.cos(a)*r
        y = lc[1] + math.sin(a)*r
        s = out(clamp(p*1.25-i*.035))
        rr = 7+9*s
        d.ellipse((x-rr,y-rr,x+rr,y+rr), fill=rgba(SAFFRON, int(210*s)))
    d.ellipse((lc[0]-185,lc[1]-185,lc[0]+185,lc[1]+185), outline=rgba(VIOLET, 180), width=5)
    d.polygon(star_points(lc[0],lc[1],88,35,8,rot=t*.25), outline=rgba(VIOLET, 210), width=4)
    path = bezier((lc[0]+185,lc[1]), P(.43,.30), P(.56,.65), (rc[0]-170,rc[1]), 150)
    draw_ribbon(im, partial(path, p), CINNABAR, 18, 150)
    q = smooth(.35,.9,t)
    # Lock as floating pearl aperture with sliding inner chamber.
    sh = layer(); sd = ImageDraw.Draw(sh)
    sd.rounded_rectangle((rc[0]-185,rc[1]-150,rc[0]+185,rc[1]+190), radius=85, fill=(0,0,0,80))
    sh = sh.filter(ImageFilter.GaussianBlur(25)); im.alpha_composite(sh,(0,16))
    d.rounded_rectangle((rc[0]-185,rc[1]-150,rc[0]+185,rc[1]+190), radius=85, fill=rgba(MOON, int(225*q)), outline=rgba(SILVER, int(240*q)), width=5)
    slit = 70 + 65*q
    d.rounded_rectangle((rc[0]-slit,rc[1]-20,rc[0]+slit,rc[1]+115), radius=slit*.45, fill=rgba(INDIGO, int(245*q)))
    draw_pearl(im, rc[0], rc[1]-20, 24*q)


def sc03(im, t):
    d = ImageDraw.Draw(im)
    p = smooth(.02,.75,t)
    # White architectural plane closes around a black internal aperture.
    outer = (W*.19, H*.15, W*.81, H*.83)
    d.rounded_rectangle(outer, radius=240, fill=rgba(WHITE, 245), outline=rgba(MOON, 90), width=4)
    opening = 120 + 270*out(p)
    d.rounded_rectangle((W*.5-opening, H*.29, W*.5+opening, H*.75), radius=opening*.38, fill=rgba(BLACK,255), outline=rgba(SILVER, 180), width=5)
    # Stars exist only inside the interior aperture.
    mask = Image.new("L",(W,H),0); md=ImageDraw.Draw(mask)
    md.rounded_rectangle((W*.5-opening, H*.29, W*.5+opening, H*.75), radius=opening*.38, fill=255)
    stars = layer(); sd=ImageDraw.Draw(stars)
    for i in range(90):
        rng=random.Random(SEED+3000+i)
        x=rng.randint(int(W*.26),int(W*.74)); y=rng.randint(int(H*.31),int(H*.71))
        twinkle=.4+.6*math.sin(t*8+i*.9)**2
        r=rng.choice([1,2,2,3])
        sd.ellipse((x-r,y-r,x+r,y+r), fill=rgba(MOON,int(80+160*twinkle)))
    stars.putalpha(Image.composite(stars.getchannel("A"),Image.new("L",(W,H),0),mask))
    im.alpha_composite(stars)
    # Red path enters and curls in depth.
    pts=[]
    for i in range(170):
        u=i/169
        x=W*.5+math.sin(u*math.pi*3.4)*90*(.25+.75*u)
        y=H*.77-u*H*.37
        pts.append((x,y))
    draw_ribbon(im,partial(pts,smooth(.28,.92,t)),CINNABAR,17,170)
    draw_pearl(im,W*.5,H*.48,18*smooth(.72,.96,t))


def sc04(im, t):
    d=ImageDraw.Draw(im)
    cx,cy=P(.55,.46)
    p=smooth(.02,.72,t)
    # Nacre valve: a three-dimensional shell iris, not an anatomical diagram.
    sh=layer(); sd=ImageDraw.Draw(sh)
    sd.ellipse((cx-350,cy-220,cx+350,cy+240),fill=(0,0,0,70))
    sh=sh.filter(ImageFilter.GaussianBlur(38)); im.alpha_composite(sh,(0,24))
    for i in range(14):
        a=-math.pi*.92 + i*(math.pi*.84/13)
        local=out(clamp(p*1.4-i*.045))
        length=300*local
        x0=cx+math.cos(a)*70; y0=cy+math.sin(a)*40
        x1=cx+math.cos(a)*length; y1=cy+math.sin(a)*length*.62
        col=mix(MOON,COPPER,i/18)
        d.line((x0,y0,x1,y1),fill=rgba(col,220),width=8)
        d.ellipse((x1-8,y1-8,x1+8,y1+8),fill=rgba(PEARL,230))
    q=smooth(.42,.86,t)
    opening=48+82*q
    d.ellipse((cx-opening,cy-opening*.6,cx+opening,cy+opening*.6),fill=rgba(INDIGO,245),outline=rgba(SILVER,240),width=5)
    draw_pearl(im,cx,cy,18+12*q)
    # Hinged lower plate subtly rises.
    plate=[(cx-250,cy+150),(cx+250,cy+150),(cx+170,cy+275),(cx-170,cy+275)]
    d.polygon(plate,fill=rgba(MOON,205),outline=rgba(SILVER,210))


def sc05(im,t):
    cx,cy=P(.5,.43)
    p=smooth(.02,.7,t)
    draw_moon_bowl(im,cx,cy,330,230,level=.78,opening=out(p))
    d=ImageDraw.Draw(im)
    # Crystalline ribs collect droplets from above.
    for i in range(17):
        a=math.pi*1.06 + i*math.pi*.88/16
        q=out(clamp(p*1.35-i*.035))
        x=cx+math.cos(a)*350*q; y=cy+math.sin(a)*220*q
        d.line((x,y,cx+math.cos(a)*130,cy+math.sin(a)*65),fill=rgba(SILVER,150),width=3)
        if i%2==0: draw_pearl(im,x,y,7*q,190)
    q=smooth(.5,.92,t)
    for j in range(5):
        x=cx+(j-2)*70
        y=cy-270-j*8
        draw_pearl(im,x,lerp(y,cy-30,q),12,220)
    glow(im,(cx,cy-20),110*q,MOON,70,55)


def sc06(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.82,t)
    # Four translucent chambers with a consuming fire below.
    centers=[P(.5,.22),P(.5,.39),P(.5,.56)]
    widths=[220,170,120]
    for i,(c,w) in enumerate(zip(centers,widths)):
        d.ellipse((c[0]-w,c[1]-42,c[0]+w,c[1]+42),outline=rgba(SILVER,150),width=4)
        d.line((c[0]-w*.7,c[1]+38,c[0]-w*.42,c[1]+100),fill=rgba(SILVER,100),width=3)
        d.line((c[0]+w*.7,c[1]+38,c[0]+w*.42,c[1]+100),fill=rgba(SILVER,100),width=3)
    # Drop accelerates; a trail remains.
    y=lerp(H*.16,H*.72,ease(p))
    for k in range(7):
        trail_y=y-k*28
        draw_pearl(im,W*.5,trail_y,max(2,16-k*1.7),int(230-k*25))
    # Geometric fire, conceptually relevant color field.
    q=smooth(.48,.9,t)
    base=P(.5,.79)
    for i in range(9):
        a=-math.pi+i*math.pi/8
        r=75+35*math.sin(i*2.1)
        tip=(base[0]+math.cos(a)*r,base[1]+math.sin(a)*r*1.5)
        d.polygon([base,(base[0]-18,base[1]+90),tip,(base[0]+18,base[1]+90)],fill=rgba(mix(SAFFRON,CINNABAR,i/8),int(180*q)))
    glow(im,base,100*q,SAFFRON,100,45)


def sc07(im,t):
    d=ImageDraw.Draw(im)
    cx,cy=P(.52,.47)
    p=smooth(.02,.72,t)
    # A transparent torus-like figure built from nested ellipses.
    for i in range(11):
        r=310-i*20
        d.ellipse((cx-r,cy-r*.56,cx+r,cy+r*.56),outline=rgba(mix(SILVER,SKY_BLUE,i/10),100),width=3)
    # Downward line turns around the torus and climbs as counterflow.
    down=bezier(P(.37,.15),P(.29,.36),P(.37,.67),P(.5,.72),140)
    up=bezier(P(.5,.72),P(.68,.66),P(.72,.34),P(.58,.13),140)
    whole=down+up[1:]
    draw_ribbon(im,partial(whole,p),CINNABAR,16,150)
    # Pearls move in opposite directions.
    for j in range(6):
        u=(t*.55+j/6)%1
        idx=int(u*(len(whole)-1))
        draw_pearl(im,*whole[idx],8,190)
    q=smooth(.64,.94,t)
    d.arc((cx-120,cy-45,cx+120,cy+45),180,540,fill=rgba(SAFFRON,int(220*q)),width=8)


def sc08(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.78,t)
    # A ruby ribbon becomes a key only at the moment it meets the lunar lock.
    lock=P(.72,.44)
    sh=layer(); sd=ImageDraw.Draw(sh)
    sd.rounded_rectangle((lock[0]-210,lock[1]-210,lock[0]+210,lock[1]+210),radius=100,fill=(0,0,0,55))
    sh=sh.filter(ImageFilter.GaussianBlur(32)); im.alpha_composite(sh,(0,22))
    d.rounded_rectangle((lock[0]-210,lock[1]-210,lock[0]+210,lock[1]+210),radius=100,fill=rgba(MOON,235),outline=rgba(SILVER,235),width=5)
    d.ellipse((lock[0]-78,lock[1]-78,lock[0]+78,lock[1]+78),fill=rgba(INDIGO,245),outline=rgba(WHITE,230),width=4)
    path=[]
    for i in range(180):
        u=i/179
        x=W*.19+u*W*.46
        y=H*.72-math.sin(u*math.pi*1.55)*H*.42 + math.sin(u*math.pi*4)*25*(1-u)
        path.append((x,y))
    pp=partial(path,p)
    draw_ribbon(im,pp,RUBY,21,160)
    # At the tip, a key bit unfolds abstractly—symbolic, non-procedural.
    if p>.74:
        tip=pp[-1]
        q=smooth(.74,.95,p)
        d.line((tip[0],tip[1],tip[0]+65*q,tip[1]),fill=rgba(RUBY,245),width=18)
        d.line((tip[0]+45*q,tip[1],tip[0]+45*q,tip[1]-35*q),fill=rgba(RUBY,245),width=16)
        d.line((tip[0]+65*q,tip[1],tip[0]+65*q,tip[1]+30*q),fill=rgba(RUBY,245),width=16)
        glow(im,lock,55*q,MOON,80,30)


def sc09(im,t):
    d=ImageDraw.Draw(im)
    cx,cy=P(.5,.46)
    p=smooth(.02,.72,t)
    # Broken membrane and escaping pearls.
    segments=[]
    for i in range(12):
        a0=i*2*math.pi/12+.08
        a1=a0+2*math.pi/12*.72
        segments.append((a0,a1))
    for i,(a0,a1) in enumerate(segments):
        q=out(clamp(p*1.3-i*.025))
        box=(cx-280,cy-280,cx+280,cy+280)
        d.arc(box,math.degrees(a0),math.degrees(a1),fill=rgba(MOON,int(230*q)),width=12)
    # escaping drops early, then reverse inward as gaps seal
    q=smooth(.3,.82,t)
    for i in range(7):
        a=i*2*math.pi/7+.3
        dist=lerp(360,250,q)
        x=cx+math.cos(a)*dist; y=cy+math.sin(a)*dist
        draw_pearl(im,x,y,9,180)
    # red membrane stitches the gaps
    r=smooth(.48,.9,t)
    for i in range(12):
        a=(i+.86)*2*math.pi/12
        x1=cx+math.cos(a)*248; y1=cy+math.sin(a)*248
        x2=cx+math.cos(a)*284; y2=cy+math.sin(a)*284
        d.line((x1,y1,x2,y2),fill=rgba(CINNABAR,int(230*r)),width=10)
    # stable circulation inside
    if r:
        for j in range(8):
            a=t*2*math.pi*.45+j*2*math.pi/8
            x=cx+math.cos(a)*170; y=cy+math.sin(a)*110
            draw_pearl(im,x,y,8,210)


def sc10(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.88,t)
    # Two high-amplitude ribbon fields gradually lock phase and flatten.
    xs=np.linspace(W*.12,W*.88,300)
    amp=145*(1-out(p)) + 4
    phase_delta=(1-out(p))*1.2
    pts1=[]; pts2=[]
    for i,x in enumerate(xs):
        u=i/(len(xs)-1)
        envelope=.35+.65*math.sin(math.pi*u)
        y1=H*.38+math.sin(u*math.pi*5+t*3.1)*amp*envelope
        y2=H*.61+math.sin(u*math.pi*5+t*3.1+phase_delta)*amp*.8*envelope
        pts1.append((x,y1)); pts2.append((x,y2))
    d.line(pts1,fill=rgba(CINNABAR,210),width=7,joint="curve")
    d.line(pts2,fill=rgba(INDIGO,210),width=7,joint="curve")
    # Shared central stillness appears as a thin bright interval.
    q=smooth(.68,.96,t)
    d.line((W*.27,H*.5,W*.73,H*.5),fill=rgba(SAFFRON,int(220*q)),width=5)
    if q: glow(im,P(.5,.5),45*q,MOON,60,28)


def sc11(im,t):
    d=ImageDraw.Draw(im)
    cx,cy=P(.5,.54)
    p=smooth(.02,.78,t)
    # Shell vault builds from ribs and floating mineral tiles.
    for i in range(23):
        a=-math.pi+.12+i*(math.pi-.24)/22
        q=out(clamp(p*1.35-i*.032))
        x0=cx+math.cos(a)*95; y0=cy+math.sin(a)*36
        x1=cx+math.cos(a)*390*q; y1=cy+math.sin(a)*270*q
        d.line((x0,y0,x1,y1),fill=rgba(mix(MOON,COPPER,i/30),210),width=7)
        if i%2==0: draw_pearl(im,x1,y1,5+4*q,180)
    # inner tessellation
    q=smooth(.4,.9,t)
    for row in range(5):
        for col in range(9-row):
            x=cx+(col-(8-row)/2)*72
            y=cy-65-row*58
            r=18*q
            pts=star_points(x,y,r,r*.62,6,rot=math.pi/6)
            d.polygon(pts,fill=rgba(mix(INDIGO,VIOLET,row/5),150),outline=rgba(MOON,120))
    glow(im,(cx,cy-170),95*q,MOON,70,45)


def sc12(im,t):
    d=ImageDraw.Draw(im)
    cx,cy=P(.5,.48)
    p=smooth(.02,.75,t)
    # Layered orbital field with parallax and one empty centre.
    for ring in range(5):
        rx=150+ring*90; ry=70+ring*50
        a0=t*(.35+.08*ring)*((-1)**ring)
        for j in range(10+ring*3):
            a=a0+j*2*math.pi/(10+ring*3)
            q=out(clamp(p*1.25-ring*.08-j*.003))
            x=cx+math.cos(a)*rx*q
            y=cy+math.sin(a)*ry*q
            r=3+ring*.8
            col=[MOON,SAFFRON,SKY_BLUE,VIOLET,CINNABAR][ring]
            d.ellipse((x-r,y-r,x+r,y+r),fill=rgba(col,180))
    # Still centre is explicitly unoccupied.
    q=smooth(.5,.92,t)
    d.ellipse((cx-55*q,cy-35*q,cx+55*q,cy+35*q),outline=rgba(WHITE,200),width=4)
    glow(im,(cx,cy),45*q,MOON,55,24)


def sc13(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.88,t)
    # Four transformations across a single horizontal axis.
    centers=[P(.18,.49),P(.39,.49),P(.61,.49),P(.82,.49)]
    # seed
    draw_pearl(im,*centers[0],35*out(clamp(p*1.5)),230)
    # circuit
    q=out(clamp((p-.15)/.35))
    for i in range(8):
        a=i*2*math.pi/8+t*.6
        x=centers[1][0]+math.cos(a)*105*q; y=centers[1][1]+math.sin(a)*105*q
        d.ellipse((x-9,y-9,x+9,y+9),fill=rgba(SAFFRON,210))
    d.ellipse((centers[1][0]-130*q,centers[1][1]-130*q,centers[1][0]+130*q,centers[1][1]+130*q),outline=rgba(VIOLET,180),width=5)
    # embodied form: wing-like pair around a central red axis
    r=out(clamp((p-.35)/.35))
    cx,cy=centers[2]
    for side in (-1,1):
        wing=[]
        for i in range(9):
            yy=cy-140+i*35
            wing.append((cx+side*(35+95*math.sin(i/8*math.pi))*r,yy))
        d.line(wing,fill=rgba(MOON,220),width=10,joint="curve")
    d.line((cx,cy-155*r,cx,cy+155*r),fill=rgba(CINNABAR,235),width=12)
    # silence: all resolves into an open square/field, not another symbol
    s=out(clamp((p-.62)/.32))
    cx,cy=centers[3]
    d.rounded_rectangle((cx-120*s,cy-120*s,cx+120*s,cy+120*s),radius=45*s,outline=rgba(WHITE,220),width=5)
    # bridges
    for i in range(3):
        a=centers[i]; b=centers[i+1]
        q=out(clamp(p*1.45-i*.18))
        d.line((a[0]+145,a[1],lerp(a[0]+145,b[0]-145,q),b[1]),fill=rgba(MOON,120),width=3)


def sc14(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.86,t)
    # Underpainting: black field with crimson ritual geometry.
    under=Image.new("RGBA",(W,H),rgba(BLACK,255)); ud=ImageDraw.Draw(under)
    cx,cy=P(.5,.5)
    for i in range(8):
        a=i*2*math.pi/8
        x=cx+math.cos(a)*250; y=cy+math.sin(a)*180
        ud.polygon(star_points(x,y,40,15,6,rot=a),fill=rgba(CINNABAR,190))
        ud.line((cx,cy,x,y),fill=rgba(COPPER,120),width=4)
    ud.ellipse((cx-120,cy-120,cx+120,cy+120),outline=rgba(SAFFRON,200),width=7)
    # White surface with moving cut windows reveals what lies beneath.
    cover=Image.new("RGBA",(W,H),rgba(WHITE,250)); mask=Image.new("L",(W,H),255); md=ImageDraw.Draw(mask)
    windows=[(.24,.34,.18,.15),(.49,.23,.24,.14),(.64,.47,.19,.18),(.35,.62,.23,.17)]
    q=out(p)
    for i,(x,y,w,h) in enumerate(windows):
        s=out(clamp(q*1.3-i*.1))
        md.rounded_rectangle((W*(x-w*s/2),H*(y-h*s/2),W*(x+w*s/2),H*(y+h*s/2)),radius=45,fill=0)
    cover.putalpha(mask)
    im.alpha_composite(under)
    im.alpha_composite(cover)
    # edge shadows around cuts
    for i,(x,y,w,h) in enumerate(windows):
        s=out(clamp(q*1.3-i*.1))
        d.rounded_rectangle((W*(x-w*s/2),H*(y-h*s/2),W*(x+w*s/2),H*(y+h*s/2)),radius=45,outline=rgba(INK,75),width=5)


def sc15(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.86,t)
    # A crimson relief is slowly covered by a pristine white lacquer slab.
    cx,cy=P(.48,.5)
    for i in range(11):
        a=i*2*math.pi/11+t*.08
        x=cx+math.cos(a)*260; y=cy+math.sin(a)*170
        d.ellipse((x-18,y-18,x+18,y+18),fill=rgba(CINNABAR,170))
        d.line((cx,cy,x,y),fill=rgba(CINNABAR,85),width=3)
    # slab slides across with real depth
    slab_x=lerp(W*1.1,W*.29,out(p))
    sh=layer(); sd=ImageDraw.Draw(sh)
    sd.rounded_rectangle((slab_x,H*.2,slab_x+W*.62,H*.8),radius=55,fill=(0,0,0,80))
    sh=sh.filter(ImageFilter.GaussianBlur(30)); im.alpha_composite(sh,(15,20))
    d.rounded_rectangle((slab_x,H*.2,slab_x+W*.62,H*.8),radius=55,fill=rgba(WHITE,252),outline=rgba(SILVER,180),width=4)
    # Ghost embossing remains faintly visible.
    q=smooth(.55,.95,t)
    if q:
        for i in range(7):
            x=slab_x+150+i*110
            d.ellipse((x-20,H*.49-20,x+20,H*.49+20),outline=rgba(CINNABAR,int(48*q)),width=3)


def sc16(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.82,t)
    # Botanical specimens unfold from compressed silhouettes into a three-dimensional herbarium constellation.
    stems=[]
    for i in range(9):
        x=W*(.17+i*.082)
        base=P(x/W,.74)
        height=190+60*math.sin(i*1.7)
        q=out(clamp(p*1.3-i*.045))
        top=(x,H*.74-height*q)
        d.line((base[0],base[1],top[0],top[1]),fill=rgba(LEAF,200),width=5)
        # leaves rotate outward
        for j in range(4):
            u=(j+1)/5
            y=lerp(base[1],top[1],u)
            side=-1 if (i+j)%2==0 else 1
            size=(28+8*j)*q
            a=side*(.5+.18*math.sin(t*2+i))
            leaf=[(x,y),(x+math.cos(a)*size,y+math.sin(a)*size),(x+math.cos(a+.45)*size*.7,y+math.sin(a+.45)*size*.7)]
            d.polygon(leaf,fill=rgba(mix(LEAF,VERDIGRIS,j/5),170),outline=rgba(CHARCOAL,70))
        stems.append(top)
    q=smooth(.55,.94,t)
    # later appendix enters as a separate copper bracket around the botanical field
    d.arc((W*.12,H*.13,W*.88,H*.92),190,350,fill=rgba(COPPER,int(200*q)),width=8)
    d.text(P(.5,.18),"LATER BOTANICAL LAYER",font=TERM_FONT,fill=rgba(COPPER,int(220*q)),anchor="mm")


def sc17(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.85,t)
    target=P(.76,.43)
    # Distinct pathways: spiral, staircase, wave, and straight arc, each with unique material.
    paths=[]
    # spiral
    pts=[]
    for i in range(150):
        u=i/149; a=u*math.pi*3.6; r=160*(1-u)+15
        pts.append((W*.2+math.cos(a)*r, H*.42+math.sin(a)*r*.65))
    paths.append((pts,VIOLET))
    paths.append((bezier(P(.1,.75),P(.35,.72),P(.48,.32),target,150),CINNABAR))
    wave=[]
    for i in range(150):
        u=i/149
        wave.append((W*.12+u*W*.62,H*.26+math.sin(u*math.pi*5)*55*(1-u)))
    paths.append((wave,SKY_BLUE))
    # staircase-like
    stair=[]
    x,y=P(.18,.58)
    for i in range(11):
        stair += [(x+i*80,y-i*24),(x+(i+1)*80,y-i*24)]
    paths.append((stair,COPPER))
    for i,(pts,col) in enumerate(paths):
        q=out(clamp(p*1.25-i*.1))
        pp=partial(pts,q)
        d.line(pp,fill=rgba(col,210),width=8,joint="curve")
    # same hidden gate, not merged into one path
    q=smooth(.58,.94,t)
    d.rounded_rectangle((target[0]-110*q,target[1]-150*q,target[0]+110*q,target[1]+150*q),radius=80*q,outline=rgba(INK,220),width=6)
    d.ellipse((target[0]-30*q,target[1]-20*q,target[0]+30*q,target[1]+20*q),fill=rgba(INDIGO,240))


def sc18(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.88,t)
    # A small ember travels through a sequence of narrowing social/architectural frames.
    frames=[(.12,.26,.21,.7),(.34,.31,.18,.62),(.53,.36,.15,.54),(.7,.4,.12,.46)]
    for i,(x,y,w,h) in enumerate(frames):
        q=out(clamp(p*1.2-i*.08))
        d.rounded_rectangle((W*x,H*y,W*(x+w),H*(y+h)),radius=38,outline=rgba(mix(COPPER,INK,i/4),170),width=5)
    path=bezier(P(.08,.72),P(.35,.8),P(.58,.32),P(.82,.47),180)
    pp=partial(path,p)
    d.line(pp,fill=rgba(COPPER,160),width=5)
    if pp:
        tip=pp[-1]
        glow(im,tip,35,SAFFRON,110,24)
        d.ellipse((tip[0]-11,tip[1]-11,tip[0]+11,tip[1]+11),fill=rgba(SAFFRON,240))
    # final ascetic pillar receives it
    q=smooth(.66,.96,t)
    x=W*.86
    d.line((x,H*.27,x,H*.72),fill=rgba(INK,int(230*q)),width=14)
    d.ellipse((x-30,H*.22,x+30,H*.28),fill=rgba(MOON,int(240*q)))


def sc19(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.86,t)
    # Region/community nodes as floating sculptural plaques; no geographic map imitation.
    nodes=[(.16,.31,"Kashmir"),(.31,.67,"Deccan"),(.49,.35,"Nepal"),(.66,.65,"Ascetic"),(.82,.3,"Haṭha")]
    centers=[]
    for i,(x,y,label) in enumerate(nodes):
        q=out(clamp(p*1.3-i*.06))
        cx,cy=P(x,y); centers.append((cx,cy))
        w=150*q; h=58*q
        d.rounded_rectangle((cx-w,cy-h,cx+w,cy+h),radius=30,fill=rgba(WHITE,245),outline=rgba(mix(SILVER,COPPER,i/5),190),width=4)
        if q>.65: d.text((cx,cy),label,font=SMALL_FONT,fill=rgba(INK,210),anchor="mm")
    # Circulating critical leaf as a faceted prism rather than a page.
    route=[centers[i] for i in [0,2,4,3,1,0]]
    q=smooth(.25,.92,t)
    for i in range(len(route)-1):
        local=clamp(q*1.35-i*.18)
        pp=partial(bezier(route[i],route[i],route[i+1],route[i+1],60),local)
        d.line(pp,fill=rgba([SKY_BLUE,CINNABAR,COPPER,VIOLET,VERDIGRIS][i],120),width=4)
    if q:
        total=(t*.42)%1*(len(route)-1)
        seg=int(total); u=total-seg
        a=route[seg]; b=route[seg+1]
        x=lerp(a[0],b[0],u); y=lerp(a[1],b[1],u)
        pts=star_points(x,y,28,18,4,rot=t*2)
        d.polygon(pts,fill=rgba(PEARL,240),outline=rgba(CINNABAR,190))


def sc20(im,t):
    d=ImageDraw.Draw(im)
    cx,cy=P(.5,.49)
    p=smooth(.02,.9,t)
    # 31 witness stars form the outer field.
    for i in range(31):
        a=i*2*math.pi/31-.3
        q=out(clamp(p*1.35-i*.012))
        r=370
        x=cx+math.cos(a)*r*q; y=cy+math.sin(a)*r*.72*q
        rr=3+(i%4)
        d.polygon(star_points(x,y,rr*1.8,rr*.75,5,rot=a),fill=rgba(MOON,160))
    # lunar bowl and gate
    q=smooth(.16,.7,t)
    draw_glass_arc(im,(cx-250*q,cy-260*q,cx+250*q,cy+110*q),MOON,10,int(220*q),15,180,360)
    d.ellipse((cx-90*q,cy-60*q,cx+90*q,cy+60*q),outline=rgba(SILVER,int(220*q)),width=5)
    # reversed red key rises through centre
    pts=[]
    for i in range(170):
        u=i/169
        x=cx+math.sin(u*math.pi*2.8)*55*(1-u*.5)
        y=cy+250-u*420
        pts.append((x,y))
    draw_ribbon(im,partial(pts,smooth(.3,.88,t)),CINNABAR,19,170)
    # sealed orbit
    r=smooth(.55,.94,t)
    for j in range(8):
        a=t*.6+j*2*math.pi/8
        x=cx+math.cos(a)*150; y=cy+math.sin(a)*95
        draw_pearl(im,x,y,8*r,210)
    # final still pearl
    draw_pearl(im,cx,cy-70,30*smooth(.78,.98,t),245)



# --- V2 refinement pass: fuller sculptural compositions for selected scenes ---
def sc01(im,t):
    d=ImageDraw.Draw(im)
    cx,cy=P(.52,.48)
    p=smooth(.02,.72,t)
    # Thirty-one faceted witness shards remain legible even after convergence.
    for i in range(31):
        rng=random.Random(SEED+8100+i*53)
        a=2*math.pi*i/31+.18
        r0=470+95*math.sin(i*1.91)
        sx=cx+math.cos(a)*r0
        sy=cy+math.sin(a)*r0*.58
        tx=cx+math.cos(a*2.7)*195
        ty=cy+math.sin(a*2.15)*110
        q=ease(clamp(p*1.12-i*.004))
        x,y=lerp(sx,tx,q),lerp(sy,ty,q)
        rot=a+(1-q)*.9
        L=28+rng.random()*34
        w=7+rng.random()*8
        pts=[rotate_point(x-L,y-w,x,y,rot),rotate_point(x+L,y-w*.45,x,y,rot),rotate_point(x+L*.7,y+w,x,y,rot),rotate_point(x-L*.8,y+w*.55,x,y,rot)]
        # tiny shadow and glass shard
        sh=[(px+5,py+7) for px,py in pts]
        d.polygon(sh,fill=rgba(INK,25))
        col=mix(SILVER,[SKY_BLUE,SAFFRON,CINNABAR][i%3],.35)
        d.polygon(pts,fill=rgba(mix(WHITE,col,.3),210),outline=rgba(col,160))
        d.line((x,y,lerp(x,cx,.22),lerp(y,cy,.22)),fill=rgba(col,60),width=2)
    # Three large optical lenses intersect at the reconstructed centre.
    q=smooth(.38,.9,t)
    for j,col in enumerate((SKY_BLUE,SAFFRON,CINNABAR)):
        a=(j-1)*math.pi/3
        rx=225*q; ry=145*q
        ox,oy=math.cos(a)*95*q,math.sin(a)*62*q
        d.ellipse((cx-rx+ox,cy-ry+oy,cx+rx+ox,cy+ry+oy),fill=rgba(col,20),outline=rgba(col,175),width=7)
    if q:
        glow(im,(cx,cy),90*q,MOON,70,42)
        draw_pearl(im,cx,cy,35+16*q)
        d.text((cx,cy+190*q),'KHECARĪVIDYĀ',font=TERM_FONT,fill=rgba(INK,int(235*q)),anchor='mm')


def sc10(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.9,t)
    xs=np.linspace(W*.12,W*.88,360)
    amp=155*(1-out(p)) + 13
    delta=(1-out(p))*1.35
    # Ghost phase fields provide depth and make the loss of amplitude visible.
    for ghost in range(5):
        alpha=28-ghost*4
        pts=[]
        for i,x in enumerate(xs):
            u=i/(len(xs)-1)
            env=.22+.78*math.sin(math.pi*u)
            y=H*.5+math.sin(u*math.pi*(4.5+ghost*.18)+t*3+ghost*.45)*(amp+ghost*18)*env
            pts.append((x,y))
        d.line(pts,fill=rgba(SILVER,alpha),width=2)
    pts1=[]; pts2=[]
    for i,x in enumerate(xs):
        u=i/(len(xs)-1); env=.3+.7*math.sin(math.pi*u)
        pts1.append((x,H*.39+math.sin(u*math.pi*5+t*3.1)*amp*env))
        pts2.append((x,H*.61+math.sin(u*math.pi*5+t*3.1+delta)*amp*.83*env))
    line_glow(im,pts1,CINNABAR,6,80,10)
    line_glow(im,pts2,INDIGO,6,70,10)
    # Paired beads approach phase identity.
    for j in range(7):
        u=(j+1)/8; k=int(u*(len(xs)-1))
        draw_pearl(im,pts1[k][0],pts1[k][1],6,180)
        draw_pearl(im,pts2[k][0],pts2[k][1],6,180)
    q=smooth(.58,.95,t)
    d.line((W*.25,H*.5,W*.75,H*.5),fill=rgba(SAFFRON,int(225*q)),width=6)
    for j in range(9):
        x=lerp(W*.3,W*.7,j/8)
        draw_pearl(im,x,H*.5,4*q,180)
    glow(im,P(.5,.5),58*q,MOON,65,32)


def sc16(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.84,t)
    # Nine distinct pressed specimens, each with its own leaf grammar.
    for i in range(9):
        x=W*(.14+i*.09); base_y=H*.75
        q=out(clamp(p*1.32-i*.04))
        height=(220+55*math.sin(i*1.55))*q
        top_y=base_y-height
        # specimen shadow
        d.line((x+7,base_y+5,x+7,top_y+5),fill=rgba(INK,22),width=8)
        d.line((x,base_y,x,top_y),fill=rgba(mix(LEAF,COPPER,i/12),210),width=6)
        nleaf=3+(i%4)
        for j in range(nleaf):
            u=(j+1)/(nleaf+1)
            y=lerp(base_y,top_y,u)
            side=-1 if (i+j)%2==0 else 1
            L=(38+10*(j%3))*q
            ang=side*(.38+.13*j+math.sin(t*2+i)*.05)
            cx=x+math.cos(ang)*L*.55; cy=y+math.sin(ang)*L*.55
            # almond leaf built from two arcs/polygons
            tip=(x+math.cos(ang)*L,y+math.sin(ang)*L)
            norm=(-math.sin(ang),math.cos(ang))
            pts=[(x,y),(cx+norm[0]*L*.24,cy+norm[1]*L*.24),tip,(cx-norm[0]*L*.24,cy-norm[1]*L*.24)]
            col=mix(LEAF,VERDIGRIS,(j+i%3)/8)
            d.polygon(pts,fill=rgba(col,150),outline=rgba(CHARCOAL,65))
            d.line((x,y,tip[0],tip[1]),fill=rgba(CHARCOAL,55),width=1)
        # seed capsule / flower head
        if i%3==0:
            d.ellipse((x-17*q,top_y-18*q,x+17*q,top_y+18*q),fill=rgba(SAFFRON,150),outline=rgba(COPPER,170))
        elif i%3==1:
            d.polygon(star_points(x,top_y,20*q,9*q,6,rot=t*.1),fill=rgba(VERDIGRIS,150),outline=rgba(LEAF,170))
        else:
            d.rounded_rectangle((x-12*q,top_y-24*q,x+12*q,top_y+24*q),radius=8,fill=rgba(COPPER,125),outline=rgba(LEAF,170))
    q=smooth(.48,.94,t)
    # Copper archival halo establishes this as an appended, bounded layer.
    d.arc((W*.085,H*.12,W*.915,H*.92),192,348,fill=rgba(COPPER,int(210*q)),width=9)
    d.text(P(.5,.17),'LATER BOTANICAL LAYER',font=TERM_FONT,fill=rgba(COPPER,int(230*q)),anchor='mm')


def sc17(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.86,t)
    target=P(.79,.45)
    # Four materially distinct trajectories.
    # 1 glass wave
    wave=[]
    for i in range(170):
        u=i/169
        wave.append((W*.08+u*W*.62,H*.24+math.sin(u*math.pi*5.2)*70*(1-u*.45)))
    q=out(clamp(p*1.2))
    line_glow(im,partial(wave,q),SKY_BLUE,9,80,13)
    # 2 copper staircase with cast shadow
    stair=[]; x0,y0=P(.1,.71)
    for i in range(12):
        stair.extend([(x0+i*78,y0-i*25),(x0+(i+1)*78,y0-i*25)])
    pp=partial(stair,out(clamp(p*1.23-.09)))
    if pp:
        d.line([(x+7,y+10) for x,y in pp],fill=rgba(INK,30),width=12,joint='curve')
        d.line(pp,fill=rgba(COPPER,220),width=9,joint='curve')
    # 3 ruby silk curve
    silk=bezier(P(.08,.83),P(.34,.82),P(.48,.43),target,180)
    draw_ribbon(im,partial(silk,out(clamp(p*1.24-.18))),CINNABAR,13,90)
    # 4 violet spiral tube
    spiral=[]
    for i in range(160):
        u=i/159;a=u*math.pi*3.7;r=170*(1-u)+18
        spiral.append((W*.22+math.cos(a)*r,H*.49+math.sin(a)*r*.62))
    line_glow(im,partial(spiral,out(clamp(p*1.25-.28))),VIOLET,10,75,12)
    # Sculptural target aperture.
    r=smooth(.55,.95,t)
    sh=layer();sd=ImageDraw.Draw(sh)
    sd.rounded_rectangle((target[0]-125*r,target[1]-170*r,target[0]+125*r,target[1]+170*r),radius=92*r,fill=(0,0,0,65))
    sh=sh.filter(ImageFilter.GaussianBlur(24));im.alpha_composite(sh,(0,18))
    d.rounded_rectangle((target[0]-125*r,target[1]-170*r,target[0]+125*r,target[1]+170*r),radius=92*r,fill=rgba(MOON,int(232*r)),outline=rgba(SILVER,int(235*r)),width=5)
    d.ellipse((target[0]-35*r,target[1]-22*r,target[0]+35*r,target[1]+22*r),fill=rgba(INDIGO,int(245*r)))


def sc18(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.9,t)
    # Four non-identical custodial thresholds.
    # copper ring
    q=out(clamp(p*1.25))
    d.ellipse((W*.1,H*.28,W*.3,H*.75),outline=rgba(COPPER,int(210*q)),width=10)
    # pearl rectangular gate
    r=out(clamp(p*1.25-.1))
    d.rounded_rectangle((W*.33,H*.31,W*.49,H*.72),radius=55,fill=rgba(WHITE,int(170*r)),outline=rgba(SILVER,int(210*r)),width=7)
    # braided arch
    s=out(clamp(p*1.25-.2)); cx=W*.61
    for off,col in [(-10,CINNABAR),(0,COPPER),(10,VERDIGRIS)]:
        d.arc((cx-W*.09+off,H*.34,cx+W*.09+off,H*.75),180,360,fill=rgba(col,int(190*s)),width=6)
        d.line((cx-W*.09+off,H*.545,cx-W*.09+off,H*.73),fill=rgba(col,int(190*s)),width=6)
        d.line((cx+W*.09+off,H*.545,cx+W*.09+off,H*.73),fill=rgba(col,int(190*s)),width=6)
    # final black ascetic pillar
    u=out(clamp(p*1.25-.32)); x=W*.84
    d.rounded_rectangle((x-25,H*.26,x+25,H*.74),radius=20,fill=rgba(INK,int(240*u)))
    d.ellipse((x-45,H*.2,x+45,H*.29),fill=rgba(MOON,int(240*u)),outline=rgba(SILVER,int(190*u)))
    # ember thread travels through all thresholds
    path=bezier(P(.05,.67),P(.35,.8),P(.6,.3),P(.84,.49),220)
    pp=partial(path,p)
    d.line([(x+6,y+8) for x,y in pp],fill=rgba(INK,28),width=10)
    d.line(pp,fill=rgba(COPPER,200),width=6)
    if pp:
        tip=pp[-1];glow(im,tip,40,SAFFRON,115,26);d.ellipse((tip[0]-12,tip[1]-12,tip[0]+12,tip[1]+12),fill=rgba(SAFFRON,245))


def sc19(im,t):
    d=ImageDraw.Draw(im)
    p=smooth(.02,.88,t)
    # Five different material stations replace a generic node chart.
    stations=[(.16,.32,'Kashmir',SKY_BLUE,6),(.31,.68,'Deccan',COPPER,4),(.49,.34,'Nepal',CINNABAR,5),(.67,.67,'Ascetic',VIOLET,7),(.83,.31,'Haṭha',VERDIGRIS,8)]
    centers=[]
    for i,(x,y,label,col,n) in enumerate(stations):
        q=out(clamp(p*1.3-i*.055));cx,cy=P(x,y);centers.append((cx,cy))
        rad=70*q
        # faceted station with drop shadow
        pts=star_points(cx,cy,rad,rad*.72,n,rot=math.pi/n)
        d.polygon([(px+8,py+10) for px,py in pts],fill=rgba(INK,25))
        d.polygon(pts,fill=rgba(mix(WHITE,col,.12),225),outline=rgba(col,190))
        if q>.7:d.text((cx,cy+rad+28),label,font=SMALL_FONT,fill=rgba(INK,190),anchor='mm')
    route=[centers[i] for i in [0,2,4,3,1,0]]
    q=smooth(.22,.94,t)
    cols=[SKY_BLUE,CINNABAR,VERDIGRIS,VIOLET,COPPER]
    for i in range(5):
        pp=partial(bezier(route[i],route[i],route[i+1],route[i+1],80),clamp(q*1.35-i*.16))
        line_glow(im,pp,cols[i],4,45,8)
    # faceted text-body circulates along the route
    total=(t*.48)%1*5;seg=min(4,int(total));u=total-seg
    a,b=route[seg],route[seg+1];x=lerp(a[0],b[0],u);y=lerp(a[1],b[1],u)
    prism=star_points(x,y,35,22,4,rot=t*2.2)
    glow(im,(x,y),38,MOON,65,20)
    d.polygon(prism,fill=rgba(PEARL,245),outline=rgba(CINNABAR,185))

FUNCS=[sc01,sc02,sc03,sc04,sc05,sc06,sc07,sc08,sc09,sc10,sc11,sc12,sc13,sc14,sc15,sc16,sc17,sc18,sc19,sc20]


def render_frame(index: int, frame: int) -> Image.Image:
    spec=SCENES[index]
    t=frame/(NFRAMES-1)
    im=scene_bg(spec["bg"])
    FUNCS[index](im,t)
    caption(im,index+1,spec["title"],spec["subtitle"],spec["term"],dark=spec["bg"] in {"black","indigo","ruby"})
    return im.convert("RGB")


def valid_video(path: Path, min_size=100_000) -> bool:
    return path.exists() and path.stat().st_size>min_size


def render_scene(index: int, force=False):
    spec=SCENES[index]
    sid=spec["id"]
    frame_dir=FRAMES/sid
    out=SCENES_DIR/f"{sid}_{spec['title'].lower().replace(' ','_').replace('ī','i').replace('ā','a').replace('ṭ','t').replace('ū','u').replace('ṛ','r').replace('ś','s').replace('ñ','n').replace('→','to')}.mp4"
    frame_dir.mkdir(parents=True,exist_ok=True)
    if valid_video(out) and not force:
        return out
    for f in range(NFRAMES):
        fp=frame_dir/f"frame_{f:04d}.jpg"
        if fp.exists() and fp.stat().st_size>30_000 and not force:
            continue
        img=render_frame(index,f)
        img.save(fp,"JPEG",quality=94,subsampling=0,optimize=False)
    cmd=["ffmpeg","-y","-loglevel","error","-framerate",str(FPS),"-i",str(frame_dir/"frame_%04d.jpg"),"-c:v","libx264","-preset","slow","-crf","18","-pix_fmt","yuv420p","-movflags","+faststart",str(out)]
    subprocess.run(cmd,check=True)
    return out


def build_combined(outputs):
    concat=ROOT/"concat.txt"
    concat.write_text("\n".join(f"file '{p.as_posix()}'" for p in outputs)+"\n")
    combined=ROOT/"khecarividya_inner_sky_v2.mp4"
    subprocess.run(["ffmpeg","-y","-loglevel","error","-f","concat","-safe","0","-i",str(concat),"-c","copy","-movflags","+faststart",str(combined)],check=True)
    return combined


def contact_sheet():
    thumb_w,thumb_h=480,270
    sheet=Image.new("RGB",(thumb_w*4,thumb_h*5+36*5),(10,12,17))
    d=ImageDraw.Draw(sheet)
    fnt=ImageFont.truetype(FONT_SANS_BOLD,18)
    for i,spec in enumerate(SCENES):
        img=render_frame(i,int(NFRAMES*.69)).resize((thumb_w,thumb_h),Image.Resampling.LANCZOS)
        row,col=divmod(i,4)
        y=row*(thumb_h+36)
        sheet.paste(img,(col*thumb_w,y+36))
        d.text((col*thumb_w+14,y+10),f"{i+1:02d}  {spec['title']}",font=fnt,fill=(245,245,245))
    out=ROOT/"contact_sheet.jpg"; sheet.save(out,"JPEG",quality=95,subsampling=0)
    return out


def qa_sheet():
    picks=[(0,.18),(2,.58),(4,.72),(7,.82),(10,.68),(13,.75),(15,.76),(19,.9)]
    tw,th=640,360
    out=Image.new("RGB",(tw*2,th*4),(12,14,20))
    for j,(idx,tt) in enumerate(picks):
        img=render_frame(idx,int(tt*(NFRAMES-1))).resize((tw,th),Image.Resampling.LANCZOS)
        out.paste(img,((j%2)*tw,(j//2)*th))
    path=ROOT/"qa_representative_frames.jpg"; out.save(path,"JPEG",quality=95,subsampling=0)
    return path


def write_metadata():
    manifest={
        "project":"Khecarīvidyā — The Inner Sky (Rebuilt Edition)",
        "version":"2.0",
        "source_basis":[
            "James Mallinson's critical work on the Khecarīvidyā and its manuscript witnesses",
            "historical comparison of deity-mantra, Kaula, and haṭhayogic layers",
            "fresh visual paraphrase; no extended modern translation reproduced"
        ],
        "historical_guardrail":"The imagery is symbolic and doctrinal, not a practical guide to the physical procedure.",
        "design_revision":[
            "removed ruled manuscript backgrounds",
            "white museum field as default",
            "black or colour only when conceptually motivated",
            "all scene assets and compositions redrawn",
            "longer scenes and full-HD output"
        ],
        "render":{"resolution":[W,H],"fps":FPS,"scene_duration_seconds":DURATION,"total_scenes":20,"total_duration_seconds":20*DURATION,"codec":"H.264 yuv420p CRF 18"},
        "style":{"thesis":"Lunar surgical cosmography: white lacquer, obsidian inner skies, nacre valves, moon bowls, ruby keys, optical lenses, mineral vaults, and botanical reliefs.","materials":["white lacquer","obsidian","nacre","moonstone","ruby enamel","silver membrane","pressed botanical relief","copper transmission thread"]},
        "scenes":[]
    }
    relations=[
        "many witnesses converge_as critical reconstruction","ritual seed transforms_into embodied seal","external sky folds_into interior vault","flat surface opens_as nacre threshold","upper store gathers reflective fluid","fluid descends_toward consumption","settled flow reverses_direction","mobile red seal functions_as symbolic key","open system closes_into circulation","breath and mind damp_into shared stillness","cavity constructs_itself_as luminous sanctuary","moving field revolves_around still interval","seed becomes circuit becomes form becomes silence","later surface reveals earlier Kaula layer","clean redaction covers_without fully erasing","botanical appendix attaches_as distinct layer","different pathways approach_same hidden threshold","restricted chain preserves_fragile technique","text circulates_across communities and forms","all pack relations converge_as closing seal"
    ]
    for i,s in enumerate(SCENES):
        fname=f"{s['id']}_{s['title'].lower().replace(' ','_').replace('ī','i').replace('ā','a').replace('ṭ','t').replace('ū','u').replace('ṛ','r').replace('ś','s').replace('ñ','n').replace('→','to')}.mp4"
        manifest["scenes"].append({"id":s["id"],"title":s["title"],"subtitle":s["subtitle"],"mode":s["term"],"background":s["bg"],"duration":DURATION,"output_filename":fname,"relation":relations[i]})
    (ROOT/"scene_manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
    catalog={
        "scene_ids":[s["id"] for s in SCENES],
        "titles":{s["id"]:s["title"] for s in SCENES},
        "background_logic":{s["id"]:s["bg"] for s in SCENES},
        "visual_families":{
            "critical_optics":["kh01","kh19"],"threshold_architecture":["kh02","kh03","kh04","kh08","kh17"],"lunar_fluid_mechanics":["kh05","kh06","kh07","kh09"],"stillness_and_inner_space":["kh10","kh11","kh12"],"textual_layers":["kh13","kh14","kh15","kh16","kh18"],"closing_synthesis":["kh20"]
        },
        "novelty_tags":["intersecting critical lenses","white architectural aperture","nacre iris valve","suspended lunar bowl","counterflow torus","ruby symbolic key","silver membrane seal","phase-lock ribbons","mineral shell vault","palimpsest cut windows","white lacquer redaction slab","botanical relief constellation","multi-path threshold topology","ember transmission chain","faceted circulation prism","moon-key cosmogram"]
    }
    (ROOT/"scene_catalog.json").write_text(json.dumps(catalog,indent=2,ensure_ascii=False))
    dossier="""# AGENT KNOWLEDGE DOSSIER — Khecarīvidyā, Rebuilt Edition

## Scope
This pack visualizes the Khecarīvidyā as a layered textual and yogic system: manuscript reconstruction, transformation of a deity-mantra framework into an embodied haṭhayogic seal, lunar fluid mechanics, reversal and containment, inner-space imagery, Kaula underlayers, later redaction, an added botanical chapter, and circulation through multiple communities.

## Guardrails
- The pack is symbolic and historical, not procedural instruction.
- The tongue/key scenes deliberately avoid anatomically actionable depiction.
- Modern anatomical equivalence is not asserted.
- Early Kaula material, later haṭhayogic framing, and later additions remain visibly distinct.
- No long copyrighted modern translation is reproduced.

## Visual thesis
The previous version relied too heavily on ruled manuscript fields. Version 2 replaces that system with **lunar surgical cosmography**: white museum space, obsidian interior skies, nacre valves, optical lenses, moon bowls, silver membranes, ruby enamel, mineral vaults, and pressed botanical relief.

## Reuse constraints
Reuse motion operators—convergence, folding inward, opening, reversal, sealing, damping, layering—but do not reuse the actual assets as generic tantra symbols. The nacre valve belongs specifically to hidden threshold imagery; the moon bowl belongs to upper-store mechanics; the white lacquer slab belongs to redaction.
"""
    (ROOT/"AGENT_KNOWLEDGE_DOSSIER.md").write_text(dossier)
    style="""# STYLE EVOLUTION — Khecarīvidyā V2

## User-directed correction
- Deprecated all ruled and lined manuscript backgrounds.
- White is now the default field.
- Black, indigo, ruby, and botanical green appear only when the scene's doctrine materially requires inner sky, luminosity, ritual seed, or herbarium imagery.
- Scene length increased from 4.8 to 8 seconds.
- Resolution increased from 1280×720 to 1920×1080.

## New material vocabulary
1. white lacquer;
2. obsidian aperture;
3. nacre valve;
4. suspended moon bowl;
5. silver membrane;
6. ruby enamel key;
7. optical critical lenses;
8. mineral shell vault;
9. pressed botanical relief;
10. copper ember-thread.

## New relationships
- dispersed witnesses → intersecting critical focus;
- exterior sky → folded interior architecture;
- leak → membrane closure → stable circulation;
- oscillation → phase-locking → shared stillness;
- underpainting → cut-window revelation;
- redaction → coverage without total erasure.

## Deprecated motifs
- lined paper as universal scholarly texture;
- repeated manuscript cards;
- repeated arch silhouettes;
- decorative stars outside conceptually relevant inner-sky scenes;
- generic anatomy outlines;
- footer boxes dominating the art.

## Transition grammar
The pack now transitions internally by aperture opening, optical convergence, membrane closure, counterflow turns, lacquer coverage, and botanical unfolding rather than by simple fade-in.

## Closing seal
The final Moon-Key cosmogram combines thirty-one witness stars, a lunar gate, a reversed ruby current, a sealed pearl orbit, and a still central drop.
"""
    (ROOT/"STYLE_EVOLUTION.md").write_text(style)
    readme=f"""# Khecarīvidyā — The Inner Sky (Rebuilt Edition)

A completely redrawn 20-scene motion-graphics pack.

## Render specification
- Resolution: {W}×{H}
- Frame rate: {FPS} fps
- Scene count: 20
- Duration per scene: {DURATION:.1f} seconds
- Total duration: {20*DURATION:.1f} seconds
- Codec: H.264, yuv420p, CRF 18

## Design changes
- No ruled or lined backgrounds.
- White museum-field default.
- Black or colour used only when doctrinally relevant.
- New assets, new compositions, no recolored reuse from earlier packs.
- Minimal direct captions rather than large footer cards.

## Requirements
- Python 3.10+
- Pillow
- NumPy
- FFmpeg / ffprobe

## Render
```bash
python render_pack.py
```

The renderer is deterministic and resume-safe. Existing complete frames and valid scene MP4s are skipped unless `--force` is supplied.
"""
    (ROOT/"README.md").write_text(readme)


def validate(combined: Path):
    cmd=["ffprobe","-v","error","-show_entries","stream=codec_name,width,height,r_frame_rate:format=duration,size","-of","json",str(combined)]
    data=json.loads(subprocess.check_output(cmd,text=True))
    data["expected"]={"width":W,"height":H,"fps":FPS,"duration":20*DURATION,"scene_count":20}
    (ROOT/"validation_report.json").write_text(json.dumps(data,indent=2))
    return data


def make_zip():
    path=ROOT.parent/"Khecarividya_Inner_Sky_Rebuilt_FullHD.zip"
    include=[ROOT/"khecarividya_inner_sky_v2.mp4",ROOT/"contact_sheet.jpg",ROOT/"qa_representative_frames.jpg",ROOT/"render_pack.py",ROOT/"scene_manifest.json",ROOT/"scene_catalog.json",ROOT/"AGENT_KNOWLEDGE_DOSSIER.md",ROOT/"STYLE_EVOLUTION.md",ROOT/"README.md",ROOT/"validation_report.json"]
    include += sorted(SCENES_DIR.glob("*.mp4"))
    with zipfile.ZipFile(path,"w",zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in include:
            z.write(p,p.relative_to(ROOT.parent))
    return path


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--force",action="store_true")
    ap.add_argument("--contact-only",action="store_true")
    ap.add_argument("--scene",type=int,help="1-based scene number")
    args=ap.parse_args()
    FRAMES.mkdir(exist_ok=True); SCENES_DIR.mkdir(exist_ok=True)
    write_metadata()
    contact_sheet(); qa_sheet()
    if args.contact_only:
        return
    if args.scene:
        render_scene(args.scene-1,args.force)
        return
    outs=[]
    for i in range(20):
        print(f"Rendering {i+1:02d}/20: {SCENES[i]['title']}",flush=True)
        outs.append(render_scene(i,args.force))
    combined=build_combined(outs)
    validate(combined)
    z=make_zip()
    print(combined)
    print(z)

if __name__=="__main__":
    main()
