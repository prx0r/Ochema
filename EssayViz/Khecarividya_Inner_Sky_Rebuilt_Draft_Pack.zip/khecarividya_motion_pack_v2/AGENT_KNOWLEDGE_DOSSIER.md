# AGENT KNOWLEDGE DOSSIER — Khecarīvidyā, Rebuilt Edition

## Scope
This pack visualizes the Khecarīvidyā as a layered textual and yogic system: manuscript reconstruction, transformation of a deity-mantra framework into an embodied haṭhayogic seal, lunar fluid mechanics, reversal and containment, inner-space imagery, Kaula underlayers, later redaction, an added botanical chapter, and circulation through multiple communities.

## Guardrails
- The pack is symbolic and historical, not procedural instruction.
- The tongue/key scenes deliberately avoid anatomically actionable depiction.
- Modern anatomical equivalence is not asserted.
- Early Kaula material, later haṭhayogic framing, and later additions remain visibly distinct.
- No long copyrighted modern translation is reproduced.

## Visual thesis
The previous version relied too heavily on ruled manuscript fields. Version 2 replaces that system with **lunar surgical cosmography**: white museum space, obsidian interior skies, nacre valves, optical lenses, moon bowls, silver membranes, ruby enamel, mineral vaults, and pressed botanical relief.

## Reuse constraints
Reuse motion operators—convergence, folding inward, opening, reversal, sealing, damping, layering—but do not reuse the actual assets as generic tantra symbols. The nacre valve belongs specifically to hidden threshold imagery; the moon bowl belongs to upper-store mechanics; the white lacquer slab belongs to redaction.
