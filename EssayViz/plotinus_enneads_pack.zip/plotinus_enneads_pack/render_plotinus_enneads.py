
from pathlib import Path
import json, math, zipfile, shutil, subprocess, textwrap, random
from PIL import Image, ImageDraw, ImageFont

ROOT = Path("/mnt/data/plotinus_enneads_pack")
FRAMES = ROOT / "frames"
SCENES_DIR = ROOT / "scenes"
for p in [ROOT, FRAMES, SCENES_DIR]:
    p.mkdir(parents=True, exist_ok=True)

W, H = 1280, 720
FPS = 10
SCENE_DUR = 5.0
SCENE_FRAMES = int(FPS * SCENE_DUR)

IVORY = (245, 240, 229)
INK = (29, 24, 25)
PORPHYRY = (118, 39, 57)
LAPIS = (42, 72, 112)
GOLD = (174, 135, 56)
GREY = (111, 105, 101)
PALE = (224, 216, 201)
SHADOW = (47, 43, 47)
WHITE = (252, 250, 246)

font_candidates = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf",
    "/usr/share/fonts/truetype/liberation2/LiberationSerif-Regular.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
]
font_path = next((p for p in font_candidates if Path(p).exists()), None)
TITLE = ImageFont.truetype(font_path, 30) if font_path else ImageFont.load_default()
SUB = ImageFont.truetype(font_path, 18) if font_path else ImageFont.load_default()
SMALL = ImageFont.truetype(font_path, 16) if font_path else ImageFont.load_default()
TINY = ImageFont.truetype(font_path, 14) if font_path else ImageFont.load_default()

SCENES = [
    {"id":"pl01","title":"Porphyry's Sixfold Library","subtitle":"Six enneads, nine treatises each","mode":"library","summary":"The corpus opens as a late-antique library: six arched chambers, each containing nine lights, suggesting Porphyry's arrangement without reducing the work to a table of contents."},
    {"id":"pl02","title":"The One Beyond Being","subtitle":"Source prior to every predicate","mode":"one_beyond","summary":"The first principle is shown through withheld form: lines, measures, and names halt before an unoccupied center that cannot be made into one object among others."},
    {"id":"pl03","title":"The Fountain That Does Not Empty","subtitle":"Procession without depletion","mode":"fountain","summary":"A full source overflows into successive basins while remaining undiminished, visualizing Plotinian production as abundance rather than loss."},
    {"id":"pl04","title":"Intellect Turns Back","subtitle":"Reversion gives form to multiplicity","mode":"intellect_turns","summary":"The first outflow bends back toward its source; in turning, it differentiates into a many-sided noetic flower of Forms."},
    {"id":"pl05","title":"The Living Intelligible City","subtitle":"All Forms awake within one another","mode":"intelligible_city","summary":"The intelligible world becomes a transparent city-temple in which every chamber is alive, internally related, and illuminated from within."},
    {"id":"pl06","title":"Soul Between Two Worlds","subtitle":"One face above, one below","mode":"soul_between","summary":"Soul is rendered as a double-facing mediator: one orientation toward Intellect, another toward the sensible cosmos it animates."},
    {"id":"pl07","title":"Soul Weaves the Cosmos","subtitle":"Care for the lower world","mode":"soul_loom","summary":"The soul's lower activity becomes a loom: invisible rational patterns are woven into a visible world without severing the soul from its higher life."},
    {"id":"pl08","title":"The Cosmos as Beautiful Image","subtitle":"An ordered imitation, not a prison","mode":"cosmos_mosaic","summary":"The sensible universe appears as a circular mosaic whose changing parts participate in a stable intelligible pattern."},
    {"id":"pl09","title":"Against the Broken Cosmos","subtitle":"Harmony answers contempt for the world","mode":"against_gnostics","summary":"A fractured black panel is gradually repaired into a luminous mosaic, reflecting Plotinus's defense of cosmic order against views that despise the world."},
    {"id":"pl10","title":"Beauty as Form Shining Through","subtitle":"Matter becomes legible","mode":"beauty_form","summary":"A rough block receives proportion, rhythm, and contour until an intelligible pattern begins to shine through the material surface."},
    {"id":"pl11","title":"Sculpt the Inner Statue","subtitle":"Remove what obscures","mode":"inner_statue","summary":"The self appears as marble under the chisel: practice removes excess rather than manufacturing a foreign identity."},
    {"id":"pl12","title":"The Eye Becomes Sunlike","subtitle":"Vision transformed by likeness","mode":"eye_sun","summary":"An ordinary eye becomes a solar emblem, suggesting that the knower must become akin to what it seeks to behold."},
    {"id":"pl13","title":"Contemplation Produces","subtitle":"Theoria flowers into life","mode":"contemplation_tree","summary":"Still contemplation is not sterile: a seed-eye becomes a branching tree whose fruits repeat the forms it beholds."},
    {"id":"pl14","title":"Time as the Life of Soul","subtitle":"Eternity unrolled","mode":"time_unrolls","summary":"A simultaneous noetic rosette unrolls into a moving scroll, presenting time as the life of soul extended in sequence."},
    {"id":"pl15","title":"Eternity All at Once","subtitle":"No before and after in Intellect","mode":"eternity","summary":"Many phases occupy one transparent polyhedral flower at once, showing eternity as complete life jointly present rather than endless duration."},
    {"id":"pl16","title":"Matter as the Dark Margin","subtitle":"Indeterminacy beneath formed life","mode":"matter_shadow","summary":"Ordered forms approach a dark, unstable margin where proportion thins and determination weakens."},
    {"id":"pl17","title":"Evil as Privation","subtitle":"Absence, not a rival god","mode":"privation","summary":"A mosaic is not invaded by a second positive principle; instead, missing tesserae create a pattern of absence within an otherwise ordered field."},
    {"id":"pl18","title":"Eros Draws the Soul Upward","subtitle":"Love as the motive of return","mode":"eros_return","summary":"A winged spiral gathers the scattered soul and turns longing toward the Good as its true object."},
    {"id":"pl19","title":"The Interior Temple","subtitle":"Turn inward, not elsewhere","mode":"interior_temple","summary":"An exterior colonnade folds into an inner sanctuary, making ascent a deepening of interior awareness rather than travel to a distant place."},
    {"id":"pl20","title":"Alone Toward the Alone","subtitle":"All mediation falls silent","mode":"union","summary":"The final cosmogram gently releases its symbols, architectures, and distinctions until only a poised relation between living awareness and the unfigured source remains."},
]

def lerp(a,b,t): return a + (b-a)*t
def ease(t): return 3*t*t - 2*t*t*t
def smooth(a,b,t):
    if t <= a: return 0.0
    if t >= b: return 1.0
    x=(t-a)/(b-a)
    return x*x*(3-2*x)
def mix(c1,c2,t): return tuple(int(lerp(a,b,t)) for a,b in zip(c1,c2))
def circle(d,x,y,r,outline=INK,width=2,fill=None):
    d.ellipse((x-r,y-r,x+r,y+r),outline=outline,width=width,fill=fill)
def line(d,pts,fill=INK,width=2):
    d.line(pts,fill=fill,width=width)
def poly(d,pts,outline=INK,width=2,fill=None):
    d.polygon(pts,outline=outline,fill=fill)
    if outline and width>1:
        for i in range(len(pts)):
            d.line([pts[i],pts[(i+1)%len(pts)]],fill=outline,width=width)
def arc(d,box,a1,a2,fill=INK,width=2):
    d.arc(box,start=a1,end=a2,fill=fill,width=width)
def radial(cx,cy,r,n,phase=0):
    return [(cx+r*math.cos(phase+2*math.pi*i/n),cy+r*math.sin(phase+2*math.pi*i/n)) for i in range(n)]
def star(d,cx,cy,r1,r2,n=8,outline=GOLD,width=2,fill=None,phase=0):
    pts=[]
    for i in range(n*2):
        a=phase+math.pi*i/n
        r=r1 if i%2==0 else r2
        pts.append((cx+r*math.cos(a),cy+r*math.sin(a)))
    poly(d,pts,outline=outline,width=width,fill=fill)
def arrow(d,p1,p2,fill=GREY,width=2,head=9):
    line(d,[p1,p2],fill=fill,width=width)
    a=math.atan2(p2[1]-p1[1],p2[0]-p1[0])
    for off in (2.65,-2.65):
        q=(p2[0]+head*math.cos(a+off),p2[1]+head*math.sin(a+off))
        line(d,[p2,q],fill=fill,width=width)
def spiral(cx,cy,r0,r1,turns=3,n=220,phase=0):
    pts=[]
    for i in range(n):
        q=i/(n-1)
        a=phase+turns*2*math.pi*q
        r=lerp(r0,r1,q)
        pts.append((cx+r*math.cos(a),cy+r*math.sin(a)))
    return pts
def title_block(d,scene,idx):
    d.text((54,42),f"{idx:02d}. {scene['title']}",fill=INK,font=TITLE)
    d.text((54,80),scene["subtitle"],fill=PORPHYRY,font=SUB)
def footer(d,text):
    d.multiline_text((55,H-82),textwrap.fill(text,width=92),fill=GREY,font=TINY,spacing=4)

def parchment(im,seed):
    d=ImageDraw.Draw(im)
    rnd=random.Random(seed)
    for _ in range(260):
        x=rnd.randrange(W); y=rnd.randrange(H)
        c=mix(PALE,IVORY,rnd.random())
        r=1 if rnd.random()<0.92 else 2
        d.ellipse((x-r,y-r,x+r,y+r),fill=c)
    for i in range(18):
        d.rectangle((i,i,W-1-i,H-1-i),outline=mix(PALE,IVORY,0.35),width=1)
    # very faint late-antique rosette traces
    for rr in (190,300):
        arc(d,(W/2-rr,H/2-rr,W/2+rr,H/2+rr),20,135,fill=mix(PALE,GREY,.18),width=1)
        arc(d,(W/2-rr,H/2-rr,W/2+rr,H/2+rr),200,315,fill=mix(PALE,GREY,.18),width=1)

def arch(d,x0,y0,x1,y1,outline=INK,width=2):
    mid=(x0+x1)/2
    d.line((x0,y1,x0,y0+(y1-y0)*.33),fill=outline,width=width)
    d.line((x1,y1,x1,y0+(y1-y0)*.33),fill=outline,width=width)
    d.arc((x0,y0,x1,y0+(y1-y0)*.66),180,360,fill=outline,width=width)

def mosaic_tile(d,x,y,s,c,outline=IVORY):
    d.rectangle((x-s,y-s,x+s,y+s),fill=c,outline=outline,width=1)

def render(scene,t):
    im=Image.new("RGB",(W,H),IVORY)
    parchment(im,int(scene["id"][-2:]))
    d=ImageDraw.Draw(im)
    idx=int(scene["id"][-2:])
    title_block(d,scene,idx)
    m=scene["mode"]
    cx,cy=W/2,H/2+8
    e=ease(t)

    if m=="library":
        # six niches, each with nine lamps
        xs=[220,420,620,820,1020,1120]
        widths=[155,155,155,155,155,110]
        for j,(x,w) in enumerate(zip(xs,widths)):
            arch(d,x-w/2,180,x+w/2,500,outline=INK,width=2)
            for k in range(9):
                row=k//3; col=k%3
                px=x+(col-1)*28; py=300+row*55
                rr=4+2*smooth(.08+j*.05,.55+j*.03,t)
                circle(d,px,py,rr,fill=GOLD if (j+k)%2 else LAPIS,outline=None,width=1)
            d.text((x-30,520),f"Enn. {j+1}",fill=PORPHYRY,font=TINY)
        # wax tablet / editorial thread
        line(d,[(140,560),(1140,560)],fill=PALE,width=2)
        for x in [220,420,620,820,1020,1120]:
            line(d,[(x,548),(x,572)],fill=GREY,width=1)

    elif m=="one_beyond":
        # many measures approach but stop before center
        for rr in [90,145,210,285]:
            arc(d,(cx-rr,cy-rr,cx+rr,cy+rr),12,156,fill=GREY if rr>150 else INK,width=1 if rr>150 else 2)
            arc(d,(cx-rr,cy-rr,cx+rr,cy+rr),204,348,fill=GREY if rr>150 else INK,width=1 if rr>150 else 2)
        for a in [i*math.pi/8 for i in range(16)]:
            r1=80; r2=250
            line(d,[(cx+r1*math.cos(a),cy+r1*math.sin(a)),(cx+r2*math.cos(a),cy+r2*math.sin(a))],fill=PALE,width=1)
        # blank marble disk with no interior symbol
        circle(d,cx,cy,58,outline=PORPHYRY,width=2,fill=WHITE)
        d.text((520,550),"prior to name • prior to number • prior to being",fill=PORPHYRY,font=SMALL)

    elif m=="fountain":
        # source basin
        circle(d,cx,180,26,fill=PORPHYRY,outline=PORPHYRY,width=1)
        star(d,cx,180,44,18,n=10,outline=GOLD,width=2,phase=t*.1)
        basins=[(cx,300,120),(cx,420,210),(cx,540,320)]
        for i,(x,y,w) in enumerate(basins):
            arc(d,(x-w,y-36,x+w,y+36),180,360,fill=INK if i==0 else GREY,width=3 if i==0 else 2)
            line(d,[(x-w,y),(x+w,y)],fill=PALE,width=1)
            if i==0: arrow(d,(cx,210),(cx,264),fill=GOLD,width=3)
            else: arrow(d,(cx,basins[i-1][1]+20),(cx,y-36),fill=GOLD,width=2)
        # branching overflow ribbons
        for off in [-90,-45,0,45,90]:
            pts=[]
            for q in range(18):
                y=215+q*19
                x=cx+off*(q/17)+12*math.sin(q*.6+t*2+off)
                pts.append((x,y))
            line(d,pts,fill=GOLD if off==0 else mix(GOLD,PALE,.2),width=3 if off==0 else 2)

    elif m=="intellect_turns":
        # outflow bends back into rosette
        source=(cx,155)
        circle(d,*source,14,fill=PORPHYRY,outline=PORPHYRY,width=1)
        rays=[]
        for off in [-130,-90,-50,-10,30,70,110]:
            pts=[]
            for q in range(45):
                u=q/44
                x=cx+off*u + 65*math.sin(math.pi*u)*math.copysign(1,off or 1)
                y=170+300*u
                pts.append((x,y))
            rays.append(pts)
            line(d,pts,fill=GOLD if abs(off)<40 else GREY,width=2)
        # reversion arrows curve into noetic flower
        for pts in rays[1::2]:
            arrow(d,pts[-1],(cx,330),fill=PALE,width=1)
        flower=radial(cx,390,120,12,phase=t*.16)
        inner=radial(cx,390,58,12,phase=-t*.13)
        for i in range(12):
            poly(d,[inner[i],flower[i],inner[(i+1)%12]],outline=INK if i%2 else PORPHYRY,width=2,fill=None)
        circle(d,cx,390,16,fill=GOLD,outline=GOLD,width=1)

    elif m=="intelligible_city":
        # transparent late-antique city-temple
        # central domed sanctuary
        arch(d,520,165,760,500,outline=INK,width=3)
        for x in [430,520,760,850]:
            d.rectangle((x-24,260,x+24,520),outline=INK,width=2)
            d.rectangle((x-34,245,x+34,260),outline=INK,width=2)
        # inner chambers
        rooms=[(395,340,485,505),(545,300,625,505),(655,300,735,505),(795,340,885,505)]
        for i,box in enumerate(rooms):
            d.rectangle(box,outline=GREY if i in [0,3] else PORPHYRY,width=2)
            star(d,(box[0]+box[2])/2,(box[1]+box[3])/2,20,8,n=6,outline=GOLD,width=1)
        # all rooms connected
        pts=[(440,420),(585,390),(695,390),(840,420)]
        for i in range(len(pts)-1):
            line(d,[pts[i],pts[i+1]],fill=PALE,width=2)
        # transparent city canopy
        for rr in [180,245]:
            arc(d,(cx-rr,120,cx+rr,120+2*rr),200,340,fill=GOLD if rr==180 else GREY,width=1)

    elif m=="soul_between":
        # two-faced medallion
        circle(d,cx,350,145,outline=INK,width=3)
        line(d,[(cx,210),(cx,490)],fill=PALE,width=2)
        # upward face profile
        arc(d,(500,255,645,400),80,260,fill=PORPHYRY,width=3)
        line(d,[(545,315),(590,300),(610,320)],fill=PORPHYRY,width=2)
        # downward face profile
        arc(d,(635,300,780,445),260,80,fill=LAPIS,width=3)
        line(d,[(670,365),(715,380),(735,360)],fill=LAPIS,width=2)
        # upper stars / lower mosaic
        for p in radial(cx,175,100,7,phase=t*.05):
            star(d,p[0],p[1],8,3,n=6,outline=GOLD,width=1)
        for iy in range(3):
            for ix in range(5):
                mosaic_tile(d,545+ix*48,500+iy*26,8,LAPIS if (ix+iy)%2 else PORPHYRY)

    elif m=="soul_loom":
        # loom frame
        d.rectangle((300,190,980,540),outline=INK,width=3)
        for x in range(350,951,40):
            line(d,[(x,210),(x,520)],fill=PALE,width=1)
        # intelligible pattern at top
        star(d,cx,155,42,16,n=8,outline=GOLD,width=2,phase=t*.12)
        # woven world grows downward
        rows=int(8*smooth(.08,.8,t))+1
        for j in range(rows):
            y=260+j*30
            pts=[]
            for x in range(340,941,30):
                yy=y+8*math.sin(x*.035+j)
                pts.append((x,yy))
            line(d,pts,fill=PORPHYRY if j%3==0 else LAPIS if j%3==1 else GREY,width=2)
        # soul shuttle
        sx=lerp(360,920,(math.sin(t*2*math.pi)+1)/2)
        poly(d,[(sx,390),(sx+25,400),(sx,410),(sx-25,400)],outline=INK,width=2,fill=GOLD)

    elif m=="cosmos_mosaic":
        # circular mosaic universe
        circle(d,cx,360,230,outline=INK,width=3)
        rings=[70,125,180,225]
        colors=[PORPHYRY,LAPIS,GOLD,GREY]
        for j,r in enumerate(rings):
            n=8+4*j
            pts=radial(cx,360,r,n,phase=t*.04*(j+1))
            for i,(x,y) in enumerate(pts):
                mosaic_tile(d,x,y,5+2*(j<2),colors[(i+j)%len(colors)])
            circle(d,cx,360,r,outline=PALE,width=1)
        star(d,cx,360,54,22,n=12,outline=GOLD,width=2,phase=-t*.08)
        # animal / elemental emblems
        for a,label in zip([0,math.pi/2,math.pi,3*math.pi/2],["air","fire","earth","water"]):
            x=cx+150*math.cos(a); y=360+150*math.sin(a)
            d.text((x-15,y-8),label,fill=INK,font=TINY)

    elif m=="against_gnostics":
        # fractured black slab
        d.rectangle((300,180,980,550),fill=SHADOW,outline=INK,width=3)
        cracks=[
            [(410,180),(470,300),(435,430),(500,550)],
            [(640,180),(600,310),(670,420),(620,550)],
            [(820,180),(760,285),(840,390),(790,550)],
        ]
        for pts in cracks: line(d,pts,fill=IVORY,width=3)
        # repair with mosaic from left to right
        prog=smooth(.15,.9,t)
        cols=int(14*prog)
        for ix in range(cols):
            for iy in range(7):
                x=325+ix*45; y=210+iy*45
                c=[PORPHYRY,LAPIS,GOLD,IVORY][(ix+iy)%4]
                mosaic_tile(d,x,y,15,c,outline=SHADOW)
        if prog>.7:
            star(d,640,365,65,28,n=10,outline=GOLD,width=2)

    elif m=="beauty_form":
        # rough block and emerging proportion grid
        d.rectangle((410,185,870,535),fill=mix(PALE,IVORY,.2),outline=INK,width=3)
        # marble veins
        for k in range(7):
            pts=[]
            for q in range(16):
                x=430+q*27
                y=250+k*38+15*math.sin(q*.7+k)
                pts.append((x,y))
            line(d,pts,fill=GREY,width=1)
        # golden ratio / formed rosette emerges
        p=smooth(.2,.9,t)
        for r in [40,80,130]:
            circle(d,cx,360,r*p,outline=GOLD if r<100 else PORPHYRY,width=2)
        petals=radial(cx,360,155*p,8,phase=t*.1)
        inner=radial(cx,360,55*p,8,phase=-t*.1)
        for i in range(8):
            poly(d,[inner[i],petals[i],inner[(i+1)%8]],outline=INK,width=2)

    elif m=="inner_statue":
        # marble slab on left, emerging human profile on right
        d.rectangle((310,170,600,555),fill=mix(PALE,IVORY,.12),outline=INK,width=3)
        # chisel
        line(d,[(690,210),(820,485)],fill=INK,width=6)
        poly(d,[(805,475),(840,520),(823,532),(790,490)],outline=INK,width=2,fill=GOLD)
        # profile contour
        prof=[(760,500),(735,430),(740,365),(780,315),(850,280),(905,315),(920,380),(900,430),(870,450),(860,500)]
        visible=int(len(prof)*smooth(.12,.85,t))+1
        line(d,prof[:max(2,visible)],fill=PORPHYRY,width=4)
        # stone chips
        for i in range(20):
            if smooth(.2,.9,t) > i/20:
                x=650+(i*31)%250; y=520-(i*47)%140
                poly(d,[(x,y),(x+8,y+3),(x+3,y+10)],outline=GREY,width=1,fill=PALE)

    elif m=="eye_sun":
        # eye
        d.arc((360,260,920,500),200,340,fill=INK,width=4)
        d.arc((360,260,920,500),20,160,fill=INK,width=4)
        circle(d,cx,380,70,outline=PORPHYRY,width=3)
        circle(d,cx,380,18,fill=INK,outline=INK,width=1)
        # transform iris to sun
        p=smooth(.35,.9,t)
        for i in range(16):
            a=i*math.pi/8+t*.05
            r1=78; r2=78+95*p
            line(d,[(cx+r1*math.cos(a),380+r1*math.sin(a)),(cx+r2*math.cos(a),380+r2*math.sin(a))],fill=GOLD,width=2)
        if p>.55:
            star(d,cx,380,42,18,n=12,outline=GOLD,width=2,phase=t*.1)

    elif m=="contemplation_tree":
        # seated seed-eye
        circle(d,cx,500,28,outline=PORPHYRY,width=3)
        circle(d,cx,500,7,fill=INK,outline=INK,width=1)
        # trunk
        grow=smooth(.05,.75,t)
        line(d,[(cx,470),(cx,470-220*grow)],fill=INK,width=5)
        # branches
        if grow>.35:
            for level,(y,span) in enumerate([(390,110),(330,165),(275,220)]):
                q=smooth(.3+level*.1,.7+level*.08,t)
                line(d,[(cx,y),(cx-span*q,y-55*q)],fill=INK,width=3)
                line(d,[(cx,y),(cx+span*q,y-55*q)],fill=INK,width=3)
                for side in [-1,1]:
                    x=cx+side*span*q; yy=y-55*q
                    star(d,x,yy,12+3*level,5,n=6,outline=GOLD if level==2 else LAPIS,width=1)
        # roots toward lower world
        for a in [2.2,2.6,.55,.95]:
            line(d,[(cx,525),(cx+95*math.cos(a)*grow,525+85*math.sin(a)*grow)],fill=GREY,width=2)

    elif m=="time_unrolls":
        # eternity rosette left
        star(d,420,350,105,44,n=12,outline=GOLD,width=2,phase=t*.04)
        circle(d,420,350,22,fill=PORPHYRY,outline=PORPHYRY,width=1)
        # scroll unrolling right
        d.rectangle((610,235,940,470),outline=INK,width=2,fill=WHITE)
        d.arc((900,215,980,490),90,270,fill=INK,width=3)
        # timeline on scroll
        line(d,[(650,350),(900,350)],fill=GREY,width=2)
        for i in range(7):
            x=670+i*35
            line(d,[(x,335),(x,365)],fill=PORPHYRY if i==3 else GREY,width=2)
        # transfer ribbon
        arrow(d,(525,350),(600,350),fill=GOLD,width=3)
        d.text((710,495),"soul extends simultaneous life into sequence",fill=PORPHYRY,font=TINY)

    elif m=="eternity":
        # transparent polyhedral flower
        for r,n,phase,col in [(70,6,t*.1,PORPHYRY),(125,8,-t*.06,LAPIS),(185,12,t*.03,GOLD)]:
            pts=radial(cx,360,r,n,phase)
            poly(d,pts,outline=col,width=2,fill=None)
            for p in pts:
                circle(d,p[0],p[1],4,fill=col,outline=col,width=1)
        # all phases linked simultaneously
        inner=radial(cx,360,70,6,t*.1)
        outer=radial(cx,360,185,12,t*.03)
        for i,p in enumerate(inner):
            for q in [outer[(2*i)%12],outer[(2*i+1)%12]]:
                line(d,[p,q],fill=PALE,width=1)
        circle(d,cx,360,12,fill=INK,outline=INK,width=1)

    elif m=="matter_shadow":
        # upper forms descending toward dark sea
        forms=[(420,210,6),(640,190,8),(860,220,5)]
        for x,y,n in forms:
            star(d,x,y,45,18,n=n,outline=GOLD if n==8 else INK,width=2)
            line(d,[(x,y+50),(x,420)],fill=PALE,width=1)
        # dark indeterminate sea
        sea=[(0,510)]
        for x in range(0,W+1,40):
            sea.append((x,500+25*math.sin(x*.014+t*2)))
        sea += [(W,H),(0,H)]
        d.polygon(sea,fill=SHADOW)
        # forms lose definition near margin
        for x in [420,640,860]:
            for rr in [15,30,50]:
                arc(d,(x-rr,440-rr,x+rr,440+rr),190,350,fill=GREY,width=1)

    elif m=="privation":
        # mosaic field with absence
        tile=28
        x0,y0=340,180
        for iy in range(12):
            for ix in range(22):
                x=x0+ix*tile; y=y0+iy*tile
                dx=x-(cx); dy=y-360
                hole=(dx*dx/(130*130)+dy*dy/(95*95))<1
                crack=(ix in [10,11] and iy>4)
                if hole or crack: continue
                c=[PORPHYRY,LAPIS,GOLD,PALE][(ix+2*iy)%4]
                mosaic_tile(d,x,y,11,c)
        # absence outlined but not filled
        d.ellipse((cx-130,265,cx+130,455),outline=GREY,width=2)
        d.text((510,520),"privation appears as missing order, not a second source",fill=PORPHYRY,font=SMALL)

    elif m=="eros_return":
        # scattered lower soul fragments
        fragments=radial(cx,500,190,11,phase=t*.08)
        for i,(x,y) in enumerate(fragments):
            star(d,x,y,11,4,n=5+(i%3),outline=GREY if i%2 else LAPIS,width=1)
        # winged spiral upward
        sp=spiral(cx,490,35,230,turns=2.6,n=220,phase=-math.pi/2)
        line(d,sp,fill=PORPHYRY,width=3)
        # wings near middle
        for side in [-1,1]:
            wing=[]
            for q in range(8):
                wing.append((cx+side*(35+q*20),360-q*10+10*math.sin(q+t*2)))
            line(d,wing,fill=GOLD,width=3)
        circle(d,cx,160,14,fill=PORPHYRY,outline=PORPHYRY,width=1)
        star(d,cx,160,34,14,n=8,outline=GOLD,width=2)

    elif m=="interior_temple":
        # exterior colonnade
        for x in [320,430,850,960]:
            d.rectangle((x-18,220,x+18,540),outline=INK,width=2)
            d.rectangle((x-30,205,x+30,220),outline=INK,width=2)
        d.rectangle((285,540,995,565),outline=INK,width=2)
        arch(d,470,150,810,540,outline=INK,width=3)
        # inner sanctuary smaller and more luminous
        arch(d,545,255,735,505,outline=PORPHYRY,width=3)
        star(d,cx,345,36,14,n=8,outline=GOLD,width=2,phase=t*.1)
        circle(d,cx,345,8,fill=PORPHYRY,outline=PORPHYRY,width=1)
        # folding inward arrows
        for p in [(350,390),(930,390),(520,520),(760,520)]:
            arrow(d,p,(cx,345),fill=PALE,width=1)

    elif m=="union":
        # begin with total cosmogram, then dissolve
        fade=1-smooth(.45,.98,t)
        # architecture
        if fade>0.05:
            arch(d,390,120,890,545,outline=mix(PALE,INK,fade),width=2)
            for x in [470,810]:
                d.rectangle((x-18,250,x+18,540),outline=mix(PALE,INK,fade),width=2)
        # symbols
        pts=radial(cx,360,190,10,phase=t*.06)
        for i,p in enumerate(pts):
            col=mix(PALE,[PORPHYRY,LAPIS,GOLD][i%3],fade)
            star(d,p[0],p[1],14,5,n=6,outline=col,width=1)
            line(d,[p,(cx,360)],fill=mix(PALE,GREY,fade),width=1)
        # living soul and source
        source_y=170
        soul_y=470-180*smooth(.3,.95,t)
        circle(d,cx,source_y,13,fill=PORPHYRY,outline=PORPHYRY,width=1)
        circle(d,cx,soul_y,10,fill=INK,outline=INK,width=1)
        line(d,[(cx,soul_y-12),(cx,source_y+15)],fill=GOLD,width=2)
        # widening white silence
        if t>.7:
            rr=350*smooth(.7,1,t)
            circle(d,cx,320,rr,outline=WHITE,width=18)

    footer(d,scene["summary"])
    return im

# Render frames and scene clips (resume-safe)
thumbs=[]
for si,scene in enumerate(SCENES):
    scene_frame_dir=FRAMES / scene["id"]
    scene_frame_dir.mkdir(exist_ok=True)
    out=SCENES_DIR/f"{scene['id']}_{scene['mode']}.mp4"
    complete_frames = len(list(scene_frame_dir.glob("frame_*.png"))) == SCENE_FRAMES
    complete_globals = all((FRAMES/f"frame_{si*SCENE_FRAMES+fi:05d}.png").exists() for fi in range(SCENE_FRAMES))
    if not (complete_frames and complete_globals):
        print(f"Rendering {scene['id']} {scene['title']}", flush=True)
        for fi in range(SCENE_FRAMES):
            t=fi/(SCENE_FRAMES-1)
            im=render(scene,t)
            global_idx=si*SCENE_FRAMES+fi
            fp=FRAMES/f"frame_{global_idx:05d}.png"
            im.save(fp)
            im.save(scene_frame_dir/f"frame_{fi:04d}.png")
    if not out.exists() or out.stat().st_size < 1000:
        subprocess.run([
            "ffmpeg","-y","-framerate",str(FPS),"-i",str(scene_frame_dir/"frame_%04d.png"),
            "-c:v","libx264","-pix_fmt","yuv420p",str(out)
        ],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    thumb_path=FRAMES/f"frame_{si*SCENE_FRAMES+int(SCENE_FRAMES*.72):05d}.png"
    thumbs.append(Image.open(thumb_path).convert("RGB"))

combined=ROOT/"plotinus_enneads_animation.mp4"
print("Encoding combined animation", flush=True)
subprocess.run([
    "ffmpeg","-y","-framerate",str(FPS),"-i",str(FRAMES/"frame_%05d.png"),
    "-c:v","libx264","-pix_fmt","yuv420p",str(combined)
],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)

# Contact sheet
cols,rows=4,5
tw,th=320,180
sheet=Image.new("RGB",(cols*tw,rows*th),(255,255,255))
for i,im in enumerate(thumbs):
    thumb=im.resize((tw,th))
    x=(i%cols)*tw; y=(i//cols)*th
    sheet.paste(thumb,(x,y))
    dd=ImageDraw.Draw(sheet)
    dd.rectangle((x+6,y+6,x+260,y+29),fill=(255,255,255))
    dd.text((x+10,y+9),f"{i+1:02d}. {SCENES[i]['title'][:27]}",fill=INK,font=TINY)
contact=ROOT/"contact_sheet.jpg"
sheet.save(contact,quality=92)

manifest={
    "project":"Plotinus — The Enneads",
    "version":"1.0",
    "source_basis":"Fresh visual paraphrases grounded in major themes across the Enneads; no long translation passages reproduced.",
    "style":{
        "name":"Late-Antique Interior Luminosity",
        "background":"ivory parchment",
        "primary":"dark umber",
        "accents":["porphyry red","lapis blue","muted gold"],
        "new_symbols":["enneadic library","overflowing fountain","transparent intelligible city","soul loom","cosmic mosaic","inner sculptor","solar eye","contemplation tree","eternity rosette","privation mosaic","interior temple"],
        "principles":["each scene is a distinct artwork","symbols express relations rather than decorate","more architectural and mosaic vocabulary","slower resolution","fewer generic ladders and circles"]
    },
    "fps":FPS,
    "resolution":[W,H],
    "scene_duration_seconds":SCENE_DUR,
    "total_scenes":len(SCENES),
    "total_duration_seconds":len(SCENES)*SCENE_DUR,
    "scenes":SCENES,
}
(ROOT/"scene_manifest.json").write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding="utf-8")

catalog={
    "scene_ids":[s["id"] for s in SCENES],
    "titles":{s["id"]:s["title"] for s in SCENES},
    "modes":{s["id"]:s["mode"] for s in SCENES},
    "clusters":{
        "text_and_architecture":["pl01","pl05","pl19"],
        "first_principles":["pl02","pl03","pl04","pl15"],
        "soul_and_cosmos":["pl06","pl07","pl08","pl09","pl13","pl14"],
        "beauty_and_ethics":["pl10","pl11","pl12","pl18"],
        "matter_evil_union":["pl16","pl17","pl20"]
    },
    "reusability_notes":{
        "pl03":"Use for procession without depletion, abundance, source, or emanation.",
        "pl04":"Use for reversion, intellective self-formation, Forms, or multiplicity organized by return.",
        "pl05":"Use for Intellect, living Forms, intelligible beauty, or transparent noetic order.",
        "pl07":"Use for world-soul, logoi, cosmic production, weaving, or mediation.",
        "pl10":"Use for beauty, form, proportion, intelligibility in matter, or artistic creation.",
        "pl12":"Use for likeness, transformed perception, contemplative vision, or the eye becoming adequate to its object.",
        "pl14":"Use for time/eternity comparisons, soul's sequence, or the unrolling of simultaneous life.",
        "pl17":"Use for privation, evil, deficiency, absence, or missing order.",
        "pl19":"Use for inward turn, interiority, contemplative ascent, or inner sanctuary.",
        "pl20":"Use as a final union, apophatic closure, or stripping away of mediation."
    }
}
(ROOT/"scene_catalog.json").write_text(json.dumps(catalog,indent=2,ensure_ascii=False),encoding="utf-8")

dossier = """# AGENT KNOWLEDGE DOSSIER — Plotinus / The Enneads

## Source and structure
Porphyry arranged Plotinus's writings into six Enneads, each containing nine treatises. The pack follows major Plotinian themes rather than pretending that one scene represents every treatise.

## Style development
This pack extends the late-antique style developed in the Iamblichus V2 set but shifts the visual personality toward Plotinus:

- less ritual apparatus;
- more interior luminosity;
- more marble, mosaic, fountain, temple, mirror, and sculptural motifs;
- more emphasis on inward turning, transparency, contemplation, beauty, and apophatic release;
- each scene is designed as a distinct artwork, not a repeated diagram template.

## New symbols added to the shared library
- sixfold enneadic library
- unoccupied apophatic center
- fountain that overflows without depletion
- noetic rosette formed by reversion
- transparent intelligible city
- double-facing soul medallion
- cosmic loom
- harmonious mosaic cosmos
- repaired fractured cosmos
- beauty emerging through marble
- inner sculptor and chisel
- solar eye
- contemplation tree
- eternity rosette unrolling into time-scroll
- shadow sea of matter
- privation as missing tesserae
- winged eros spiral
- interior temple
- silent union field

## Core doctrinal relations
1. **One → Intellect → Soul**: graded dependence, not temporal fabrication.
2. **Procession and reversion**: what proceeds becomes determinate through turning back.
3. **Intellect as living multiplicity**: Forms are mutually present within an ordered noetic whole.
4. **Soul as mediator**: soul remains linked upward while animating and ordering what is below.
5. **The cosmos as image**: the sensible world is an ordered and beautiful imitation, not simply an evil prison.
6. **Beauty as intelligible form**: beauty appears where form and proportion shine through matter.
7. **Contemplation as productive**: contemplation is active and generative, not inert observation.
8. **Time and eternity**: eternity is complete life jointly present; time is soul's life extended in sequence.
9. **Matter and evil**: matter marks indeterminacy; evil is privation rather than a positive rival principle.
10. **Return through likeness and love**: the soul rises by becoming akin to what it seeks.
11. **Interior ascent**: the path turns inward toward Intellect and ultimately beyond Intellect.
12. **Apophatic union**: the One is not possessed as an object of discursive thought.

## Reuse logic
Retrieve scenes by relation, not by name alone:
- source / abundance → pl02–pl03
- procession / reversion → pl03–pl04
- intelligible world / Forms → pl04–pl05
- soul / mediation / cosmos → pl06–pl09
- beauty / self-cultivation / transformed vision → pl10–pl12
- contemplation / time / eternity → pl13–pl15
- matter / evil / deficiency → pl16–pl17
- love / ascent / inwardness / union → pl18–pl20

## Guardrails
- Do not equate the One with a large supreme being inside the universe.
- Do not render procession as a chronological explosion.
- Do not present the sensible cosmos as wholly evil; Plotinus explicitly defends its order and beauty.
- Do not reduce union to an ordinary emotional state.
- Structural comparisons with Trika, Proclus, Sufism, or Christianity should preserve doctrinal differences.

## Renderer migration
The current deterministic renderer can be replaced by Skia, Motion Canvas, Three.js, or Blender while preserving:
- scene id
- relation
- symbol vocabulary
- phase structure
- color and material family
- timing and resolution arc
"""
(ROOT/"AGENT_KNOWLEDGE_DOSSIER.md").write_text(dossier,encoding="utf-8")

style_notes = """# STYLE EVOLUTION — Plotinus Pack

## Shared late-antique base
The project now has a reusable family of parchment, architectural, cosmographic, and emblematic motifs.

## Plotinian differentiation
Iamblichus emphasized altar, hierarchy, invocation, and descent.
Plotinus emphasizes fountain, mirror, transparency, inwardness, sculptural purification, beauty, and silent source.

## Rule for future packs
Every new thinker must add:
1. at least five new symbols;
2. at least three new causal or contemplative relationships;
3. at least one new material vocabulary;
4. a distinct closing seal;
5. no more than two scenes built from the same basic composition.
"""
(ROOT/"STYLE_EVOLUTION.md").write_text(style_notes,encoding="utf-8")

readme=f"""# Plotinus — Enneads Animation Pack

Included:
- plotinus_enneads_animation.mp4
- contact_sheet.jpg
- scenes/ — 20 individual reusable MP4 clips
- scene_manifest.json
- scene_catalog.json
- AGENT_KNOWLEDGE_DOSSIER.md
- STYLE_EVOLUTION.md
- render_plotinus_enneads.py

Specs:
- Resolution: {W}×{H}
- FPS: {FPS}
- Scene count: {len(SCENES)}
- Duration per scene: {SCENE_DUR:.1f}s
- Total runtime: {len(SCENES)*SCENE_DUR/60:.2f} minutes
"""
(ROOT/"README.md").write_text(readme,encoding="utf-8")

zip_path=Path("/mnt/data/plotinus_enneads_pack.zip")
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as z:
    for p in ROOT.rglob("*"):
        if p.is_file() and "frames/" not in str(p):
            z.write(p,p.relative_to(ROOT.parent))

print(zip_path)
print(combined)
print(contact)
