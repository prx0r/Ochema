# AGENT KNOWLEDGE DOSSIER — Plotinus / The Enneads

## Source and structure
Porphyry arranged Plotinus's writings into six Enneads, each containing nine treatises. The pack follows major Plotinian themes rather than pretending that one scene represents every treatise.

## Style development
This pack extends the late-antique style developed in the Iamblichus V2 set but shifts the visual personality toward Plotinus:

- less ritual apparatus;
- more interior luminosity;
- more marble, mosaic, fountain, temple, mirror, and sculptural motifs;
- more emphasis on inward turning, transparency, contemplation, beauty, and apophatic release;
- each scene is designed as a distinct artwork, not a repeated diagram template.

## New symbols added to the shared library
- sixfold enneadic library
- unoccupied apophatic center
- fountain that overflows without depletion
- noetic rosette formed by reversion
- transparent intelligible city
- double-facing soul medallion
- cosmic loom
- harmonious mosaic cosmos
- repaired fractured cosmos
- beauty emerging through marble
- inner sculptor and chisel
- solar eye
- contemplation tree
- eternity rosette unrolling into time-scroll
- shadow sea of matter
- privation as missing tesserae
- winged eros spiral
- interior temple
- silent union field

## Core doctrinal relations
1. **One → Intellect → Soul**: graded dependence, not temporal fabrication.
2. **Procession and reversion**: what proceeds becomes determinate through turning back.
3. **Intellect as living multiplicity**: Forms are mutually present within an ordered noetic whole.
4. **Soul as mediator**: soul remains linked upward while animating and ordering what is below.
5. **The cosmos as image**: the sensible world is an ordered and beautiful imitation, not simply an evil prison.
6. **Beauty as intelligible form**: beauty appears where form and proportion shine through matter.
7. **Contemplation as productive**: contemplation is active and generative, not inert observation.
8. **Time and eternity**: eternity is complete life jointly present; time is soul's life extended in sequence.
9. **Matter and evil**: matter marks indeterminacy; evil is privation rather than a positive rival principle.
10. **Return through likeness and love**: the soul rises by becoming akin to what it seeks.
11. **Interior ascent**: the path turns inward toward Intellect and ultimately beyond Intellect.
12. **Apophatic union**: the One is not possessed as an object of discursive thought.

## Reuse logic
Retrieve scenes by relation, not by name alone:
- source / abundance → pl02–pl03
- procession / reversion → pl03–pl04
- intelligible world / Forms → pl04–pl05
- soul / mediation / cosmos → pl06–pl09
- beauty / self-cultivation / transformed vision → pl10–pl12
- contemplation / time / eternity → pl13–pl15
- matter / evil / deficiency → pl16–pl17
- love / ascent / inwardness / union → pl18–pl20

## Guardrails
- Do not equate the One with a large supreme being inside the universe.
- Do not render procession as a chronological explosion.
- Do not present the sensible cosmos as wholly evil; Plotinus explicitly defends its order and beauty.
- Do not reduce union to an ordinary emotional state.
- Structural comparisons with Trika, Proclus, Sufism, or Christianity should preserve doctrinal differences.

## Renderer migration
The current deterministic renderer can be replaced by Skia, Motion Canvas, Three.js, or Blender while preserving:
- scene id
- relation
- symbol vocabulary
- phase structure
- color and material family
- timing and resolution arc
