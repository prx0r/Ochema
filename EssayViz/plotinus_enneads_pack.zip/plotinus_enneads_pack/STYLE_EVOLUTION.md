# STYLE EVOLUTION — Plotinus Pack

## Shared late-antique base
The project now has a reusable family of parchment, architectural, cosmographic, and emblematic motifs.

## Plotinian differentiation
Iamblichus emphasized altar, hierarchy, invocation, and descent.
Plotinus emphasizes fountain, mirror, transparency, inwardness, sculptural purification, beauty, and silent source.

## Rule for future packs
Every new thinker must add:
1. at least five new symbols;
2. at least three new causal or contemplative relationships;
3. at least one new material vocabulary;
4. a distinct closing seal;
5. no more than two scenes built from the same basic composition.
