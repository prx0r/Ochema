# Plotinus — Enneads Animation Pack

Included:
- plotinus_enneads_animation.mp4
- contact_sheet.jpg
- scenes/ — 20 individual reusable MP4 clips
- scene_manifest.json
- scene_catalog.json
- AGENT_KNOWLEDGE_DOSSIER.md
- STYLE_EVOLUTION.md
- render_plotinus_enneads.py

Specs:
- Resolution: 1280×720
- FPS: 10
- Scene count: 20
- Duration per scene: 5.0s
- Total runtime: 1.67 minutes
