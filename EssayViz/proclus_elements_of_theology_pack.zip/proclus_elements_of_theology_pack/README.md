# Proclus — Elements of Theology Pack

Included files:
- proclus_elements_of_theology_animation.mp4
- contact_sheet.jpg
- scene_manifest.json
- scene_catalog.json
- AGENT_KNOWLEDGE_DOSSIER.md
- README.md

Specs:
- Resolution: 1280x720
- FPS: 12
- Scene count: 20
- Duration per scene: 4.2s
- Total runtime: 1.4 minutes
