# AGENT KNOWLEDGE DOSSIER — Proclus, *Elements of Theology*

## Aim
This pack visualizes core Proclean metaphysical relations in a calm, diagrammatic, elegant form suited to philosophical documentary video.

## Textual orientation
The *Elements of Theology* is not a narrative text. It is a chain of propositions. Therefore the pack should not be cut like mythic storytelling. It works best when used as:
- structured exposition
- proposition-by-proposition commentary
- metaphysical comparison visuals
- chapter or section separators in Neoplatonic documentaries

## Core Proclean ideas represented
1. **The One** — beyond plurality, beyond being
2. **Participation** — lower realities receive higher principles according to capacity
3. **Unparticipated / participated / participant** — essential explanatory triad
4. **Monē, prohodos, epistrophē** — remaining, procession, reversion
5. **Henads** — divine unities mediating causal series
6. **Being, Life, Intellect** — central intelligible triad
7. **Series (seirai)** — causal chains rooted in divine unities
8. **Providence** — presence of higher causality without diminution
9. **Soul** — self-moving middle order
10. **Ascent through likeness** — return through assimilation to superior causes

## Visual rules
- Avoid explosive or temporal-creation imagery.
- Procession is dependence, not chronological birth.
- Reversion is orientation toward source, not simple backward movement.
- The One should never be rendered as one item among many competing items.
- Henads should appear as harmonized plurality, not rival gods in anthropomorphic conflict.
- Hierarchy should look calm, ordered, and intelligible.

## Style family
- Warm white background
- Black geometry for structure
- Crimson for source, decisive causal emphasis, or apophatic center
- Grey / pale lines for mediating relations and quiet secondary order
- More verticality and triadic composition than the Tantra packs

## How to reuse the scenes
- `pr01` / `pr02`: opening philosophical hook on unity and plurality
- `pr03` / `pr18`: participation grammar, mediation, graded ontology
- `pr04` / `pr05` / `pr06` / `pr07`: the main Proclean causal logic
- `pr08` / `pr11` / `pr19`: divine orders, henads, series
- `pr09` / `pr13`: noetic architecture and triads
- `pr14` / `pr15` / `pr16`: soul, time, nature, body
- `pr17` / `pr20`: return, ascent, and closing synthesis

## Comparison guardrails
When mapping Proclus against other traditions:
- Do not equate the One with Brahman, Śiva, Ein Sof, or emptiness without residue.
- Do not turn procession into creation ex nihilo.
- Do not flatten participation into modern influence or vague 'energy'.
- If compared with Trika, emphasize structural analogies and doctrinal differences.

## Backend note
These scenes were rendered in a simple deterministic 2D pipeline, but the semantics are portable.
A sleeker renderer can preserve the same scene logic while upgrading:
- line quality
- camera motion
- easing
- layered typography
- luminous fields
- shader-based soft radiance
