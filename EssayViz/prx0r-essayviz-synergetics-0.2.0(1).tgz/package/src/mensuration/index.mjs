import { volume, surfaceArea } from "../geometry/mesh.mjs";
export function euclideanMensuration(mesh){return {volume:volume(mesh),surfaceArea:surfaceArea(mesh)};}
export function fullerVectorEquilibriumTetravolume(frequency=1){return 20*Math.pow(frequency,3);}
export function fullerFrequencyMemberCount(frequency=1){return 4*Math.pow(frequency,2);}
export function mensurationReport(mesh,{frequency=1}={}){
  return {
    object:mesh.id,
    euclidean:euclideanMensuration(mesh),
    fullerDefined:mesh.id==="vector-equilibrium"?{tetravolume:fullerVectorEquilibriumTetravolume(frequency),frequency,status:"fuller-defined-formalism"}:null
  };
}

export function scaleSynergeticsVolume(baseVolume,frequency=1){
  if(!Number.isFinite(baseVolume)||!Number.isFinite(frequency))throw new Error("baseVolume and frequency must be finite");
  return baseVolume*Math.pow(frequency,3);
}
