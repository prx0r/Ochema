import { v3 } from "../math/vec3.mjs";
import { makeMesh, orientFacesOutward, volume } from "./mesh.mjs";

function hullFacesByPlane(vertices,faceSize,tol=1e-8){
  const candidates=new Map(),n=vertices.length;
  for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)for(let k=j+1;k<n;k++){
    const a=vertices[i],b=vertices[j],c=vertices[k];
    const nx=(b.y-a.y)*(c.z-a.z)-(b.z-a.z)*(c.y-a.y);
    const ny=(b.z-a.z)*(c.x-a.x)-(b.x-a.x)*(c.z-a.z);
    const nz=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
    const nn=Math.hypot(nx,ny,nz);
    if(nn<tol)continue;
    const d=nx*a.x+ny*a.y+nz*a.z;
    const signed=vertices.map(p=>nx*p.x+ny*p.y+nz*p.z-d);
    if(signed.some(s=>s>tol)&&signed.some(s=>s<-tol))continue;
    const on=signed.map((s,index)=>Math.abs(s)<=tol?index:-1).filter(index=>index>=0);
    if(on.length!==faceSize)continue;
    const key=[...on].sort((x,y)=>x-y).join(":");
    candidates.set(key,on);
  }
  return [...candidates.values()].map(indices=>{
    const center=indices.reduce((s,i)=>v3(s.x+vertices[i].x,s.y+vertices[i].y,s.z+vertices[i].z),v3());
    center.x/=indices.length;center.y/=indices.length;center.z/=indices.length;
    const p0=vertices[indices[0]],p1=vertices[indices[1]],p2=vertices[indices[2]];
    const normal=v3(
      (p1.y-p0.y)*(p2.z-p0.z)-(p1.z-p0.z)*(p2.y-p0.y),
      (p1.z-p0.z)*(p2.x-p0.x)-(p1.x-p0.x)*(p2.z-p0.z),
      (p1.x-p0.x)*(p2.y-p0.y)-(p1.y-p0.y)*(p2.x-p0.x)
    );
    const axis=Math.abs(normal.x)<.8*Math.hypot(normal.x,normal.y,normal.z)?v3(1,0,0):v3(0,1,0);
    const ux=v3(
      normal.y*axis.z-normal.z*axis.y,
      normal.z*axis.x-normal.x*axis.z,
      normal.x*axis.y-normal.y*axis.x
    );
    const un=Math.hypot(ux.x,ux.y,ux.z);ux.x/=un;ux.y/=un;ux.z/=un;
    const uy=v3(
      normal.y*ux.z-normal.z*ux.y,
      normal.z*ux.x-normal.x*ux.z,
      normal.x*ux.y-normal.y*ux.x
    );
    return indices.sort((ia,ib)=>{
      const pa=vertices[ia],pb=vertices[ib];
      const aa=Math.atan2(
        (pa.x-center.x)*uy.x+(pa.y-center.y)*uy.y+(pa.z-center.z)*uy.z,
        (pa.x-center.x)*ux.x+(pa.y-center.y)*ux.y+(pa.z-center.z)*ux.z
      );
      const ab=Math.atan2(
        (pb.x-center.x)*uy.x+(pb.y-center.y)*uy.y+(pb.z-center.z)*uy.z,
        (pb.x-center.x)*ux.x+(pb.y-center.y)*ux.y+(pb.z-center.z)*ux.z
      );
      return aa-ab;
    });
  });
}

function tetraVertices(sign=1){
  const base=[
    v3(1,1,1),v3(1,-1,-1),v3(-1,1,-1),v3(-1,-1,1)
  ];
  return base.map(p=>v3(sign*p.x,sign*p.y,sign*p.z));
}
function cubeVertices(){
  const vertices=[];
  for(const x of [-1,1])for(const y of [-1,1])for(const z of [-1,1])vertices.push(v3(x,y,z));
  return vertices;
}
function octaVertices(){return [v3(2,0,0),v3(-2,0,0),v3(0,2,0),v3(0,-2,0),v3(0,0,2),v3(0,0,-2)];}
function veVertices(){
  const vertices=[];
  for(const zero of [0,1,2]){
    const others=[0,1,2].filter(i=>i!==zero);
    for(const a of [-2,2])for(const b of [-2,2]){
      const c=[0,0,0];c[others[0]]=a;c[others[1]]=b;vertices.push(v3(...c));
    }
  }
  return vertices;
}

function mesh(id,name,vertices,faceSize,metadata={}){
  return orientFacesOutward(makeMesh({
    id,name,vertices,faces:hullFacesByPlane(vertices,faceSize),
    metadata:{
      epistemicStatus:"conventional Cartesian geometry normalized by Fuller tetrahedral volume unit",
      ...metadata
    }
  }));
}

export function createHierarchyTetrahedron(){
  return mesh("hierarchy-tetrahedron","Unit-Volume Tetrahedron",tetraVertices(1),3,{synergeticsVolume:1,primeEdge:2*Math.sqrt(2)});
}
export function createDualTetrahedron(){
  return mesh("hierarchy-dual-tetrahedron","Dual Tetrahedron",tetraVertices(-1),3,{synergeticsVolume:1,primeEdge:2*Math.sqrt(2)});
}
export function createDuoTetCube(){
  const m=mesh("duo-tet-cube","Duo-Tet Cube",cubeVertices(),4,{synergeticsVolume:3,construction:"union hull of tetrahedron and its dual"});
  m.constituentTetrahedra=[tetraVertices(1),tetraVertices(-1)];
  return m;
}
export function createHierarchyOctahedron(){
  return mesh("hierarchy-octahedron","Hierarchy Octahedron",octaVertices(),3,{synergeticsVolume:4});
}
export function createRhombicDodecahedron(){
  const vertices=[...cubeVertices(),...octaVertices()];
  return mesh("rhombic-dodecahedron","Rhombic Dodecahedron",vertices,4,{synergeticsVolume:6,spaceFiller:true});
}
export function createHierarchyVectorEquilibrium(){
  return mesh("hierarchy-vector-equilibrium","Hierarchy Vector Equilibrium",veVertices(),3,{
    synergeticsVolume:20,
    note:"Hull includes triangular and square planes; faces are recomputed below."
  });
}
function createVEWithMixedFaces(){
  const vertices=veVertices();
  const faces=[...hullFacesByPlane(vertices,3),...hullFacesByPlane(vertices,4)];
  return orientFacesOutward(makeMesh({
    id:"hierarchy-vector-equilibrium",name:"Hierarchy Vector Equilibrium",
    vertices,faces,
    metadata:{
      synergeticsVolume:20,
      primeEdge:2*Math.sqrt(2),
      epistemicStatus:"conventional cuboctahedron geometry + Fuller tetrahedral-volume normalization"
    }
  }));
}

export function createSynergeticsHierarchy(){
  const tetra=createHierarchyTetrahedron();
  const members=[
    tetra,
    createDuoTetCube(),
    createHierarchyOctahedron(),
    createRhombicDodecahedron(),
    createVEWithMixedFaces()
  ];
  const tetraEuclideanVolume=volume(tetra);
  return {
    id:"synergetics-concentric-hierarchy-part1",
    normalization:"common prime-vector edge / shared Cartesian hierarchy coordinates",
    tetraEuclideanVolume,
    members:members.map(m=>({
      ...m,
      computedTetraVolumeRatio:volume(m)/tetraEuclideanVolume
    })),
    expectedVolumes:{
      "hierarchy-tetrahedron":1,
      "duo-tet-cube":3,
      "hierarchy-octahedron":4,
      "rhombic-dodecahedron":6,
      "hierarchy-vector-equilibrium":20
    },
    sourceBenchmark:"grunch.net/synergetics/volumes.html"
  };
}
