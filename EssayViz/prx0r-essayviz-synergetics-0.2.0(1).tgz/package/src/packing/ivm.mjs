import { v3, distance } from "../math/vec3.mjs";

export const IVM_NEIGHBOR_OFFSETS=[
  [1,1,0],[1,-1,0],[-1,1,0],[-1,-1,0],
  [1,0,1],[1,0,-1],[-1,0,1],[-1,0,-1],
  [0,1,1],[0,1,-1],[0,-1,1],[0,-1,-1]
];

export function createIVM({radius=2,edgeLength=1,crop="sphere"}={}){
  const scale=edgeLength/Math.sqrt(2),nodes=[],index=new Map();
  for(let i=-radius;i<=radius;i++)for(let j=-radius;j<=radius;j++)for(let k=-radius;k<=radius;k++){
    if((i+j+k)%2!==0)continue;
    if(crop==="sphere"&&Math.hypot(i,j,k)>radius*Math.sqrt(2)+1e-9)continue;
    if(crop==="tetrahedral"&&(i+j+k<0||i<0||j<0||k<0))continue;
    const id=nodes.length,key=`${i},${j},${k}`;
    nodes.push({id,lattice:[i,j,k],position:v3(i*scale,j*scale,k*scale),shell:Math.max(Math.abs(i),Math.abs(j),Math.abs(k))});
    index.set(key,id);
  }
  for(const node of nodes){
    node.neighbors=[];
    for(const d of IVM_NEIGHBOR_OFFSETS){
      const key=`${node.lattice[0]+d[0]},${node.lattice[1]+d[1]},${node.lattice[2]+d[2]}`;
      if(index.has(key))node.neighbors.push(index.get(key));
    }
    node.coordinationNumber=node.neighbors.length;
  }
  const edges=[];
  for(const n of nodes)for(const m of n.neighbors)if(n.id<m)edges.push([n.id,m]);
  return {id:"ivm",nodes,edges,edgeLength,crop,radius,metadata:{epistemicStatus:"conventional FCC lattice interpreted as Fuller IVM"}};
}
export function localVectorEquilibrium(ivm,nodeId=0){
  const center=ivm.nodes[nodeId];
  const neighbors=center.neighbors.map(i=>ivm.nodes[i]);
  return {center,neighbors,valid:neighbors.length===12,distances:neighbors.map(n=>distance(center.position,n.position))};
}


export function cuboctahedralShellCount(frequency){
  if(!Number.isInteger(frequency)||frequency<1)throw new Error("frequency must be a positive integer");
  return 10*frequency*frequency+2;
}
export function createCuboctahedralShell({frequency=1,edgeLength=1}={}){
  if(!Number.isInteger(frequency)||frequency<1)throw new Error("frequency must be a positive integer");
  const scale=edgeLength/Math.sqrt(2),nodes=[],index=new Map();
  const F=frequency,R=2*F;
  for(let i=-R;i<=R;i++)for(let j=-R;j<=R;j++)for(let k=-R;k<=R;k++){
    if((i+j+k)%2!==0)continue;
    const max=Math.max(Math.abs(i),Math.abs(j),Math.abs(k));
    const sum=Math.abs(i)+Math.abs(j)+Math.abs(k);
    const inside=max<=F&&sum<=2*F;
    const boundary=max===F||sum===2*F;
    if(!inside||!boundary)continue;
    const id=nodes.length,key=`${i},${j},${k}`;
    nodes.push({id,lattice:[i,j,k],position:v3(i*scale,j*scale,k*scale),frequency:F});
    index.set(key,id);
  }
  const edges=[];
  for(const node of nodes){
    for(const d of IVM_NEIGHBOR_OFFSETS){
      const key=`${node.lattice[0]+d[0]},${node.lattice[1]+d[1]},${node.lattice[2]+d[2]}`;
      const other=index.get(key);
      if(other!==undefined&&node.id<other)edges.push([node.id,other]);
    }
  }
  return {
    id:`cuboctahedral-shell-f${F}`,frequency:F,nodes,edges,edgeLength,
    expectedCount:cuboctahedralShellCount(F),
    valid:nodes.length===cuboctahedralShellCount(F),
    metadata:{
      epistemicStatus:"conventional FCC shell matching the Synergetics cuboctahedral shell count",
      formula:"10F^2+2"
    }
  };
}
export function createCuboctahedralCluster({frequency=1,edgeLength=1}={}){
  const scale=edgeLength/Math.sqrt(2),nodes=[],index=new Map(),F=frequency,R=2*F;
  for(let i=-R;i<=R;i++)for(let j=-R;j<=R;j++)for(let k=-R;k<=R;k++){
    if((i+j+k)%2!==0)continue;
    if(Math.max(Math.abs(i),Math.abs(j),Math.abs(k))>F)continue;
    if(Math.abs(i)+Math.abs(j)+Math.abs(k)>2*F)continue;
    const id=nodes.length,key=`${i},${j},${k}`;
    nodes.push({id,lattice:[i,j,k],position:v3(i*scale,j*scale,k*scale)});
    index.set(key,id);
  }
  const edges=[];
  for(const node of nodes)for(const d of IVM_NEIGHBOR_OFFSETS){
    const key=`${node.lattice[0]+d[0]},${node.lattice[1]+d[1]},${node.lattice[2]+d[2]}`;
    const other=index.get(key);if(other!==undefined&&node.id<other)edges.push([node.id,other]);
  }
  return {id:`cuboctahedral-cluster-f${F}`,frequency:F,nodes,edges,edgeLength};
}
