import { createGeodesicIcosahedron } from "./subdivide.mjs";
import { makeMesh, orientFacesOutward, edgeLengths } from "../geometry/mesh.mjs";
import { centroid } from "../math/vec3.mjs";

export function triangulationNumber(a,b=0){
  return a*a+a*b+b*b;
}
export function classifyDomeClass(a,b=0){
  if(!Number.isInteger(a)||!Number.isInteger(b)||a<1||b<0)throw new Error("a and b must be non-negative integers with a >= 1");
  if(b===0)return "I";
  if(a===b)return "II";
  return "III";
}
export function createDomeSpecification({a=3,b=0,base="icosahedron"}={}){
  const domeClass=classifyDomeClass(a,b);
  return {
    a,b,class:domeClass,
    triangulationNumber:triangulationNumber(a,b),
    totalSphereFaces:20*triangulationNumber(a,b),
    base,
    implementationStatus:domeClass==="I"?"full-sphere and cap geometry implemented":"planar class pattern implemented; full spherical projection pending",
    epistemicStatus:"conventional geodesic classification"
  };
}
export function createClassIGeodesicSphere({frequency=3,radius=1}={}){
  const mesh=createGeodesicIcosahedron({frequency,radius});
  mesh.metadata={...mesh.metadata,class:"I",a:frequency,b:0,triangulationNumber:frequency*frequency};
  return mesh;
}
export function createClassIGeodesicDome({frequency=3,radius=1,cutoffZ=0}={}){
  const sphere=createClassIGeodesicSphere({frequency,radius});
  const keptFaces=sphere.faces.filter(face=>face.every(i=>sphere.vertices[i].z>=cutoffZ-1e-9));
  const used=[...new Set(keptFaces.flat())].sort((a,b)=>a-b);
  const remap=new Map(used.map((old,index)=>[old,index]));
  const vertices=used.map(i=>sphere.vertices[i]);
  const faces=keptFaces.map(face=>face.map(i=>remap.get(i)));
  return orientFacesOutward(makeMesh({
    id:`class-I-dome-f${frequency}`,
    name:`Class I ${frequency}-Frequency Geodesic Dome`,
    vertices,faces,
    metadata:{
      class:"I",frequency,cutoffZ,
      parentSphereFaces:sphere.faces.length,
      domeFaceCount:faces.length,
      fractionOfSphere:faces.length/sphere.faces.length,
      epistemicStatus:"conventional class-I geodesic cap"
    }
  }));
}
export function groupStrutLengths(mesh,{tolerance=1e-6}={}){
  const lengths=edgeLengths(mesh).sort((a,b)=>a-b),groups=[];
  for(const length of lengths){
    const g=groups.find(x=>Math.abs(x.mean-length)<=tolerance);
    if(g){g.values.push(length);g.mean=g.values.reduce((a,b)=>a+b,0)/g.values.length;}
    else groups.push({mean:length,values:[length]});
  }
  return groups.map((g,index)=>({classId:String.fromCharCode(65+index),length:g.mean,count:g.values.length}));
}
export function createPlanarClassCell({a=3,b=0,scale=80}={}){
  const e1={x:scale,y:0};
  const e2={x:scale/2,y:scale*Math.sqrt(3)/2};
  const p={x:a*e1.x+b*e2.x,y:a*e1.y+b*e2.y};
  const q={x:-b*e1.x+(a+b)*e2.x,y:-b*e1.y+(a+b)*e2.y};
  return {
    class:classifyDomeClass(a,b),a,b,
    triangulationNumber:triangulationNumber(a,b),
    corners:[{x:0,y:0},p,q],
    basis:{e1,e2},
    bounds:{
      minX:Math.min(0,p.x,q.x),maxX:Math.max(0,p.x,q.x),
      minY:Math.min(0,p.y,q.y),maxY:Math.max(0,p.y,q.y)
    }
  };
}
