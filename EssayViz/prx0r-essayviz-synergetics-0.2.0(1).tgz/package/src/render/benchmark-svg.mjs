import { projectOrthographic } from "./project.mjs";
import { createSynergeticsHierarchy } from "../geometry/synergetics-hierarchy.mjs";
import { createClassIGeodesicSphere, createClassIGeodesicDome, createPlanarClassCell, createDomeSpecification, groupStrutLengths } from "../geodesics/domes.mjs";
import { createCuboctahedralShell } from "../packing/ivm.mjs";

const COLORS={
  "hierarchy-tetrahedron":"#b04449",
  "duo-tet-cube":"#ad7e32",
  "hierarchy-octahedron":"#4b7795",
  "rhombic-dodecahedron":"#5c7b62",
  "hierarchy-vector-equilibrium":"#65538c"
};
function esc(s){return String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));}
function line(x1,y1,x2,y2,stroke,width=1,opacity=.7,dash=""){
  return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${stroke}" stroke-width="${width}" stroke-opacity="${opacity}" ${dash?`stroke-dasharray="${dash}"`:""}/>`;
}
function text(x,y,value,size=16,fill="#15191e",anchor="start",weight=400){
  return `<text x="${x}" y="${y}" font-family="Georgia,serif" font-size="${size}" fill="${fill}" text-anchor="${anchor}" font-weight="${weight}">${esc(value)}</text>`;
}
function meshWire(mesh,{width,height,scale,center,rotation,color,opacity=.65,vertexRadius=0}={}){
  const pts=projectOrthographic(mesh.vertices,{width,height,scale,center,rotation});
  const out=[];
  for(const [a,b] of mesh.edges)out.push(line(pts[a].x,pts[a].y,pts[b].x,pts[b].y,color,1.2,opacity));
  if(vertexRadius>0)for(const p of pts)out.push(`<circle cx="${p.x}" cy="${p.y}" r="${vertexRadius}" fill="${color}" fill-opacity="${opacity}"/>`);
  return out.join("\n");
}
export function hierarchyToSvg({width=1280,height=720}={}){
  const hierarchy=createSynergeticsHierarchy();
  const out=[`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`,
    `<rect width="100%" height="100%" fill="#fbfaf6"/>`,
    text(48,52,"Synergetics Concentric Hierarchy — Common Prime-Vector Coordinates",25),
    text(48,78,"Tetrahedral volume units and conventional wireframe geometry remain explicitly separated.",13,"#68717a")
  ];
  const rotation=[-.48,.65,.08],center=[480,365],scale=88;
  for(const member of [...hierarchy.members].reverse()){
    const color=COLORS[member.id];
    out.push(meshWire(member,{width,height,scale,center,rotation,color,opacity:.62,vertexRadius:1.8}));
  }
  out.push(`<rect x="790" y="112" width="430" height="470" rx="4" fill="#ffffff" stroke="#d8d4ca"/>`);
  out.push(text(825,150,"Computed hierarchy",19,"#15191e","start",700));
  out.push(text(825,177,"Shape",13,"#68717a"),text(1128,177,"Tet volume",13,"#68717a","end"));
  let y=215;
  for(const member of hierarchy.members){
    const expected=hierarchy.expectedVolumes[member.id];
    out.push(`<circle cx="806" cy="${y-5}" r="5" fill="${COLORS[member.id]}"/>`);
    out.push(text(825,y,member.name,15),text(1128,y,member.computedTetraVolumeRatio.toFixed(6),15,COLORS[member.id],"end",700));
    out.push(text(1168,y,`→ ${expected}`,13,"#68717a","start"));
    y+=66;
  }
  out.push(text(825,535,"Normalization",13,"#68717a"));
  out.push(text(825,560,hierarchy.normalization,13,"#15191e"));
  out.push(text(48,678,"Benchmark target: tetrahedron 1 · duo-tet cube 3 · octahedron 4 · rhombic dodecahedron 6 · vector equilibrium 20",14,"#15191e"));
  out.push(`</svg>`);
  return out.join("\n");
}

function drawMiniMesh(mesh,{x,y,w,h,title,subtitle}){
  const scale=Math.min(w,h)*.37;
  const pts=projectOrthographic(mesh.vertices,{width:w,height:h,scale,center:[x+w/2,y+h*.52],rotation:[-.52,.65,.05]});
  const out=[`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#ffffff" stroke="#ddd8ce"/>`,text(x+18,y+30,title,16,"#15191e","start",700),text(x+18,y+50,subtitle,11,"#68717a")];
  for(const [a,b] of mesh.edges)out.push(line(pts[a].x,pts[a].y,pts[b].x,pts[b].y,"#3f6f94",.85,.52));
  for(const p of pts)out.push(`<circle cx="${p.x}" cy="${p.y}" r="1.6" fill="#aa7c2e"/>`);
  return out.join("\n");
}
export function domeFrequencySheetToSvg({frequencies=[1,2,3,5,9],width=1500,height=720}={}){
  const out=[`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`,
    `<rect width="100%" height="100%" fill="#fbfaf6"/>`,
    text(42,50,"Class I Geodesic Frequency — Vertices Projected to Constant Radius",25),
    text(42,76,"For Class I, each icosahedral face becomes F² triangles; the complete sphere has 20F² faces.",13,"#68717a")
  ];
  const gap=18,cardW=(width-84-gap*(frequencies.length-1))/frequencies.length;
  frequencies.forEach((frequency,i)=>{
    const mesh=createClassIGeodesicSphere({frequency,radius:1});
    const struts=groupStrutLengths(mesh,{tolerance:1e-5});
    const subtitle=`${mesh.faces.length} faces · ${mesh.vertices.length} vertices · ${struts.length} strut classes`;
    out.push(drawMiniMesh(mesh,{x:42+i*(cardW+gap),y:112,w:cardW,h:500,title:`${frequency}-frequency`,subtitle}));
  });
  out.push(text(42,660,"Higher frequency increases triangular component count and approaches the sphere more smoothly.",14));
  out.push(`</svg>`);
  return out.join("\n");
}

function latticeLines(cell,{x,y,w,h,id}){
  const {corners,basis,bounds}=cell;
  const sx=w/(bounds.maxX-bounds.minX||1),sy=h/(bounds.maxY-bounds.minY||1),s=Math.min(sx,sy)*.82;
  const tx=x+w/2-(bounds.minX+bounds.maxX)/2*s,ty=y+h/2+(bounds.minY+bounds.maxY)/2*s;
  const map=p=>({x:tx+p.x*s,y:ty-p.y*s});
  const C=corners.map(map);
  const out=[`<clipPath id="${id}"><polygon points="${C.map(p=>`${p.x},${p.y}`).join(" ")}"/></clipPath>`,
    `<polygon points="${C.map(p=>`${p.x},${p.y}`).join(" ")}" fill="#f5f2ea" stroke="#15191e" stroke-width="1.5"/>`,
    `<g clip-path="url(#${id})">`];
  const range=12;
  const dirs=[
    [basis.e1,{x:basis.e2.x,y:basis.e2.y}],
    [basis.e2,{x:basis.e1.x,y:basis.e1.y}],
    [{x:basis.e2.x-basis.e1.x,y:basis.e2.y-basis.e1.y},{x:basis.e1.x,y:basis.e1.y}]
  ];
  for(const [dir,offset] of dirs){
    for(let k=-range;k<=range;k++){
      const base={x:k*offset.x,y:k*offset.y};
      const a=map({x:base.x-dir.x*range,y:base.y-dir.y*range});
      const b=map({x:base.x+dir.x*range,y:base.y+dir.y*range});
      out.push(line(a.x,a.y,b.x,b.y,"#4b7795",.8,.34));
    }
  }
  out.push(`</g>`);
  return out.join("\n");
}
export function domeClassSheetToSvg({width=1280,height=720}={}){
  const examples=[{a:3,b:0},{a:2,b:2},{a:3,b:1}];
  const out=[`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`,
    `<rect width="100%" height="100%" fill="#fbfaf6"/>`,
    text(42,50,"Geodesic Classes as Triangular-Lattice Supercells",25),
    text(42,76,"Class I: b=0 · Class II: a=b · Class III: a>b>0 · T=a²+ab+b²",13,"#68717a")
  ];
  examples.forEach((ex,i)=>{
    const cell=createPlanarClassCell({...ex,scale:1});
    const spec=createDomeSpecification(ex);
    const x=42+i*410,y=118;
    out.push(`<rect x="${x}" y="${y}" width="370" height="500" fill="#ffffff" stroke="#ddd8ce"/>`);
    out.push(text(x+20,y+34,`Class ${spec.class}`,21,"#15191e","start",700));
    out.push(text(x+20,y+58,`(a,b)=(${ex.a},${ex.b}) · T=${spec.triangulationNumber}`,13,"#68717a"));
    out.push(latticeLines(cell,{x:x+25,y:y+86,w:320,h:325,id:`clip-${i}`}));
    out.push(text(x+20,y+450,`Complete sphere: ${spec.totalSphereFaces} triangles`,14));
    out.push(text(x+20,y+475,spec.implementationStatus,11,"#a6434a"));
  });
  out.push(`</svg>`);
  return out.join("\n");
}


function drawPointCloud(system,{x,y,w,h,title,subtitle,rotation=[-.52,.65,.05],scale}={}){
  const points=system.nodes.map(n=>n.position);
  const pts=projectOrthographic(points,{width:w,height:h,scale:scale??Math.min(w,h)*.18,center:[x+w/2,y+h*.54],rotation});
  const out=[`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#ffffff" stroke="#ddd8ce"/>`,
    text(x+18,y+30,title,16,"#15191e","start",700),
    text(x+18,y+50,subtitle,11,"#68717a")];
  for(const [a,b] of system.edges)out.push(line(pts[a].x,pts[a].y,pts[b].x,pts[b].y,"#4b7795",.7,.22));
  for(const p of pts)out.push(`<circle cx="${p.x}" cy="${p.y}" r="3.1" fill="#aa7c2e" fill-opacity=".78"/>`);
  return out.join("\n");
}
export function packingShellSheetToSvg({frequencies=[1,2,3],width=1280,height=720}={}){
  const out=[`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`,
    `<rect width="100%" height="100%" fill="#fbfaf6"/>`,
    text(42,50,"Cuboctahedral Sphere-Packing Shells",25),
    text(42,76,"Each FCC shell contains 10F²+2 equal-radius sphere centers.",13,"#68717a")
  ];
  const gap=22,cardW=(width-84-gap*(frequencies.length-1))/frequencies.length;
  frequencies.forEach((frequency,i)=>{
    const shell=createCuboctahedralShell({frequency});
    out.push(drawPointCloud(shell,{
      x:42+i*(cardW+gap),y:112,w:cardW,h:500,
      title:`F=${frequency}`,
      subtitle:`${shell.nodes.length} centers · expected ${shell.expectedCount}`,
      scale:frequency===1?100:frequency===2?62:45
    }));
  });
  out.push(text(42,660,"The local F=1 shell is the twelve-vertex vector equilibrium around one nuclear center.",14));
  out.push(`</svg>`);
  return out.join("\n");
}

export function domeCapsSheetToSvg({frequencies=[3,5,9],width=1280,height=720}={}){
  const out=[`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`,
    `<rect width="100%" height="100%" fill="#fbfaf6"/>`,
    text(42,50,"Class I Geodesic Domes — Upper Spherical Caps",25),
    text(42,76,"A dome is a selected fraction of a complete projected geodesic sphere.",13,"#68717a")
  ];
  const gap=22,cardW=(width-84-gap*(frequencies.length-1))/frequencies.length;
  frequencies.forEach((frequency,i)=>{
    const dome=createClassIGeodesicDome({frequency,cutoffZ:0});
    const subtitle=`${dome.faces.length} faces · ${(100*dome.metadata.fractionOfSphere).toFixed(1)}% of complete face count`;
    out.push(drawMiniMesh(dome,{x:42+i*(cardW+gap),y:112,w:cardW,h:500,title:`${frequency}-frequency cap`,subtitle}));
  });
  out.push(text(42,660,"The present cap uses a z≥0 selection; production domes may specify any source-grounded cutoff.",14));
  out.push(`</svg>`);
  return out.join("\n");
}
