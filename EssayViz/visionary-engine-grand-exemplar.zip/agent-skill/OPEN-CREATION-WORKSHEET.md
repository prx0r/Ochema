# Open Creation Worksheet

## Source

- Exact contention:
- Secure conclusion:
- Rival:
- Discriminator:
- Frontier:

## Event chain

| Incoming belief | Verb | Outgoing belief | Relation | Invariant | Forbidden inference |
|---|---|---|---|---|---|

## Five candidates

### Notation

- Topology:
- Decisive mutation:
- Risk:

### Graph/topology

- Topology:
- Decisive mutation:
- Risk:

### Field/dynamical

- Topology:
- Decisive mutation:
- Risk:

### Embodied/domain

- Topology:
- Decisive mutation:
- Risk:

### Unconventional

- Topology:
- Decisive mutation:
- Risk:

## Selected dimensions

- Geometry:
- Material:
- Motion:
- Style:
- Signal:
- Composition:
- Presentation:
- Backend:

## Nearest template audit

- Nearest scene:
- Why insufficient:
- Mutation 1:
- Mutation 2:
- Primitive safely reused:

## Modal counterpoint

- Music:
- Image:
- Narration:
- Silence:
