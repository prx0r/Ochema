---
name: open-visual-language-agent
description: Invent new deterministic audiovisual forms from argument structure using the full Visionary Engine without copying completed templates.
version: 1.0
---

# Open Visual Language Agent

## Mission

Create a visual composition that is necessary to its source.

Reuse primitives and infrastructure. Do not reuse a completed visual argument
unless its causal structure is genuinely identical.

## 1. Read and abstract

Extract:

- exact contention;
- incoming audience model;
- outgoing audience model;
- premises;
- rival;
- discriminator;
- evidence statuses;
- unresolved frontier.

Then remove all proposed imagery.

## 2. Build an argument-event chain

```json
{
  "incoming_belief": "",
  "operation": "",
  "outgoing_belief": "",
  "relation": "",
  "invariant": "",
  "forbidden_inference": ""
}
```

## 3. Choose dimensions independently

For every scene choose:

```json
{
  "topology": "",
  "geometry": "",
  "material": "",
  "motion": "",
  "style": "",
  "signal_strategy": "",
  "composition_function": "",
  "presentation": ""
}
```

Do not allow a theme to choose the topology.

## 4. Generate a possibility field

Generate at least five candidates:

1. notation candidate;
2. graph/topology candidate;
3. field/dynamical candidate;
4. embodied/domain candidate;
5. deliberately unconventional candidate.

Candidates must differ in causal form.

## 5. Candidate tournament

Score:

- relation fidelity;
- invariant preservation;
- temporal causality;
- silent legibility;
- rival neutrality;
- discriminator power;
- epistemic restraint;
- visual originality;
- backend feasibility.

Hard failures cannot be averaged away.

## 6. Mutation requirement

Name the nearest completed scene.

Mutate at least two:

- topology;
- invariant;
- causal direction;
- time structure;
- subjectivity;
- evidence structure;
- medium relationship;
- backend.

## 7. Compose across modalities

Decide who leads and who lags:

```text
music proposes
visual complicates
narration reorients
silence permits completion
```

This is one option, not a law. Document the chosen counterpoint.

## 8. Select packs

Activate only required packs.

Possible layers:

- capability;
- invariant/meta;
- geometry;
- material;
- motion;
- style;
- signal;
- presentation;
- backend.

## 9. Render review

For every scene:

- five fixed frames;
- one transition strip;
- one audio-isolated render;
- one narration-isolated render when relevant.

## 10. Repair

Repair semantic structure before decoration.

## Required deliverables

- source lock;
- argument IR;
- candidate tournament;
- rejected alternatives;
- activated capability profile;
- scene pack;
- signal routes;
- process notes;
- review plan;
- validator output;
- final unresolved frontier.
