import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
const pack=JSON.parse(await readFile(new URL("../packs/visionary-engine-grand-exemplar.template.json",import.meta.url),"utf8"));
test("grand exemplar has twenty scenes",()=>assert.equal(pack.scenes.length,20));
test("all scenes use the showcase motif",()=>pack.scenes.forEach(s=>assert.equal(s.motif,"grand-exemplar")));
test("visual operations are diverse",()=>{
  const ops=pack.scenes.flatMap(s=>s.params.operations.map(o=>o.type));
  assert.ok(new Set(ops).size>=14);
});
test("broad capabilities are declared",()=>{
  for(const id of ["pathkit-geometry","particle-fields","audio-reactive","neurocognition","human-anatomy","yogic-subtle-body"])assert.ok(pack.capabilityPacks.includes(id));
});
