import { TAU, clamp, rgba, smoothstep, wave } from "../math.mjs";
import { drawArrowHead, drawGlowOrb, drawNode, drawPartialPath, drawRing } from "../primitives.mjs";

const W=1280,H=720,CX=640,CY=330;
const SERIF='"Source Serif 4", "EB Garamond", serif';
const MATH='"KaTeX Math", "Source Serif 4", serif';
const P={paper:"#fdfcf9",ink:"#15191e",graphite:"#606973",grid:"#d1d7da",
 indigo:"#31567e",blue:"#347b98",gold:"#a77a2e",green:"#3d7857",
 crimson:"#a43f49",violet:"#65528d",cyan:"#3d96a7",ember:"#c65a31"};

function font(size,{weight=400,italic=false,math=false}={}){return `${italic?"italic ":""}${weight} ${size}px ${math?MATH:SERIF}`;}
function txt(ctx,s,x,y,{size=18,color=P.ink,alpha=1,align="center",weight=400,italic=false,math=false}={}){
 ctx.save();ctx.font=font(size,{weight,italic,math});ctx.textAlign=align;ctx.textBaseline="middle";ctx.fillStyle=rgba(color,alpha);ctx.fillText(String(s),x,y);ctx.restore();
}
function multi(ctx,s,x,y,o={}){const z=o.size??18,ls=String(s).split("\n"),lh=z*(o.lineHeight??1.25);ls.forEach((v,i)=>txt(ctx,v,x,y+(i-(ls.length-1)/2)*lh,{...o,size:z}));}
function arrow(ctx,a,b,{color=P.graphite,alpha=.45,width=.9,dashed=false,head=7}={}){
 ctx.save();if(dashed)ctx.setLineDash([5,7]);ctx.strokeStyle=rgba(color,alpha);ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.restore();drawArrowHead(ctx,b.x,b.y,Math.atan2(b.y-a.y,b.x-a.x),head,color,alpha);
}
function paper(ctx,mode="white"){
 ctx.fillStyle=mode==="dark"?"#090b11":P.paper;ctx.fillRect(0,0,W,H);
 ctx.save();ctx.strokeStyle=rgba(mode==="dark"?"#76839b":P.grid,mode==="dark"?.025:.018);ctx.lineWidth=.45;
 for(let x=80;x<W;x+=80){ctx.beginPath();ctx.moveTo(x,50);ctx.lineTo(x,H-45);ctx.stroke();}
 for(let y=90;y<H;y+=60){ctx.beginPath();ctx.moveTo(45,y);ctx.lineTo(W-45,y);ctx.stroke();}ctx.restore();
}
function header(ctx,s,mode="white"){txt(ctx,s,72,58,{size:12,color:mode==="dark"?"#aeb9ca":P.graphite,align:"left",weight:700});ctx.strokeStyle=rgba(mode==="dark"?"#aeb9ca":P.graphite,.18);ctx.beginPath();ctx.moveTo(72,77);ctx.lineTo(420,77);ctx.stroke();}
function win(op,t,i,n){const s=op.start??i/n,e=op.end??(i+1)/n,p=clamp((t-s)/Math.max(.001,e-s));const a=op.persist?smoothstep(s,s+.06,t):smoothstep(s,s+.06,t)*(1-smoothstep(e-.06,e,t));return{p,a,visible:t>=s&&(op.persist||t<=e)};}
function box(ctx,x,y,w,h,{color=P.graphite,alpha=.3,fill=null}={}){ctx.save();ctx.globalAlpha=alpha;if(fill){ctx.fillStyle=fill;ctx.fillRect(x,y,w,h);}ctx.strokeStyle=color;ctx.lineWidth=.9;ctx.strokeRect(x,y,w,h);ctx.restore();}

/* notation */
function notationArgument(ctx,p,o){
 header(ctx,"FORMAL NOTATION");
 const xs=[190,470,770,1060],labels=o.labels??["P₁","P₂","C","U"];
 labels.forEach((s,i)=>{const q=smoothstep(.04+i*.1,.26+i*.1,p);drawRing(ctx,xs[i],CY,66,i===2?P.green:(i===3?P.crimson:P.indigo),.28*q,1);txt(ctx,s,xs[i],CY,{size:23,color:i===2?P.green:(i===3?P.crimson:P.indigo),math:true,weight:700,alpha:q});if(i<3)arrow(ctx,{x:xs[i]+66,y:CY},{x:xs[i+1]-66,y:CY},{color:i===2?P.crimson:P.graphite,alpha:.45*q,dashed:i===2});});
 txt(ctx,o.caption??"licensed implication followed by an unresolved bridge",CX,570,{size:18,color:P.ink,alpha:smoothstep(.58,.92,p)});
}

/* topology */
function quotientWorld(ctx,p,o){
 header(ctx,"QUOTIENT GEOMETRY");
 for(let i=0;i<72;i++){const a=i*2.399963,r=35+Math.sqrt(i/72)*245;drawNode(ctx,CX+Math.cos(a)*r,CY+Math.sin(a)*r*.65,2.3,{fill:i%3?P.graphite:P.violet,stroke:P.graphite,alpha:.22});}
 const q=smoothstep(.18,.85,p);
 for(let g=0;g<5;g++){const a=g/5*TAU-Math.PI/2,x=CX+Math.cos(a)*120*q,y=CY+Math.sin(a)*75*q;drawRing(ctx,x,y,38,P.violet,.26*q,1);txt(ctx,`[${g+1}]`,x,y,{size:14,color:P.violet,alpha:q});}
 txt(ctx,"many microstates → observer-relative equivalence classes",CX,585,{size:18,color:P.ink,alpha:q});
}

/* field */
function attractorField(ctx,p,o){
 header(ctx,"DYNAMICAL FIELD");
 const q=smoothstep(.05,.92,p);
 for(let i=0;i<18;i++){const a=i/18*TAU,r=230;const x=CX+Math.cos(a)*r,y=CY+Math.sin(a)*r*.68;const tx=CX+Math.cos(a*2)*65,ty=CY+Math.sin(a*3)*45;arrow(ctx,{x,y},{x:x+(tx-x)*q*.52,y:y+(ty-y)*q*.52},{color:i%2?P.blue:P.indigo,alpha:.22,width:.65});}
 drawGlowOrb(ctx,CX,CY,9,P.gold,.28*q);drawRing(ctx,CX,CY,75+8*wave(p,.4),P.gold,.18*q,1);
 txt(ctx,o.caption??"trajectories bend toward a constraint",CX,585,{size:18,color:P.ink,alpha:q});
}

/* memory */
function causalTrace(ctx,p,o){
 header(ctx,"CAUSAL MEMORY");
 const pts=[];for(let i=0;i<100;i++){const u=i/99,x=120+u*1040,y=CY+90*Math.sin(u*TAU*2.1)*(1-u*.35);pts.push({x,y});}
 const n=Math.max(2,Math.floor(pts.length*smoothstep(0,1,p)));
 ctx.save();ctx.strokeStyle=rgba(P.indigo,.52);ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);for(const a of pts.slice(1,n))ctx.lineTo(a.x,a.y);ctx.stroke();ctx.restore();
 for(let lag=1;lag<=4;lag++){ctx.save();ctx.strokeStyle=rgba(P.gold,.12/lag);ctx.lineWidth=4+lag*3;ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y+lag*5);for(const a of pts.slice(1,n))ctx.lineTo(a.x,a.y+lag*5);ctx.stroke();ctx.restore();}
 txt(ctx,"current trajectory + decaying trace",CX,590,{size:18,color:P.ink});
}

/* nested agency */
function nestedAgency(ctx,p,o){
 header(ctx,"MULTISCALE AGENCY");
 const rs=[52,102,158,225],names=["cell","tissue","organ","organism"],cols=[P.cyan,P.blue,P.violet,P.gold];
 rs.forEach((r,i)=>{const q=smoothstep(i*.09,i*.09+.3,p);drawRing(ctx,CX,CY,r,cols[i],.22*q,1);txt(ctx,names[i],CX+r+28,CY-r*.15,{size:14,color:cols[i],align:"left",alpha:q});});
 txt(ctx,"nested control ≠ automatic subject selection",CX,600,{size:18,color:P.crimson,alpha:smoothstep(.6,.92,p),weight:700});
}

/* coupling */
function couplingKernel(ctx,p,o){
 header(ctx,"COUPLING TOPOLOGY");
 const ys=[195,330,465],cols=[P.blue,P.violet,P.gold];
 ys.forEach((y,i)=>{ctx.strokeStyle=rgba(cols[i],.28);ctx.beginPath();ctx.ellipse(CX,y,285,48,0,0,TAU);ctx.stroke();txt(ctx,["visual","auditory","interoceptive"][i],965,y,{size:14,color:cols[i],align:"left"});});
 const q=smoothstep(.18,.85,p);
 for(let i=0;i<11;i++){const a={x:390+(i%4)*105,y:ys[i%3]},b={x:730+((i*2)%4)*90,y:ys[(i+1)%3]};arrow(ctx,a,b,{color:i%2?P.violet:P.blue,alpha:.18+.22*q,dashed:true,width:.7});}
 drawRing(ctx,CX,CY,260,P.green,.15*q,1.2);txt(ctx,"connected component",CX,590,{size:18,color:P.green,alpha:q});
}

/* fission */
function fissionPanels(ctx,p,o){
 header(ctx,"THEORY-SENSITIVE FISSION");
 const q=smoothstep(.06,.9,p),names=["IIT","QRI","GWT","Aperture","Biology"];
 names.forEach((name,i)=>{const x=155+i*242,th=.18+i*.145,split=smoothstep(th,th+.12,q);box(ctx,x-86,205,172,285,{color:i%2?P.violet:P.indigo,alpha:.25});drawRing(ctx,x-27*split,340,42-8*split,i%2?P.violet:P.indigo,.25,1);drawRing(ctx,x+27*split,370,42-8*split,i%2?P.violet:P.indigo,.25,1);txt(ctx,name,x,520,{size:14,color:P.ink});txt(ctx,`θ=${th.toFixed(2)}`,x,235,{size:12,color:P.crimson,math:true});});
 txt(ctx,"same intervention · different split predictions",CX,590,{size:18,color:P.ink});
}

/* symbolic geometry */
function lotusConstruction(ctx,p,o){
 header(ctx,"PARAMETRIC SYMBOLIC GEOMETRY");
 const petals=o.petals??12,q=smoothstep(.05,.9,p);
 for(let i=0;i<petals;i++){const a=i/petals*TAU-Math.PI/2,r=155,tip=92*q;ctx.save();ctx.translate(CX+Math.cos(a)*r,CY+Math.sin(a)*r);ctx.rotate(a+Math.PI/2);ctx.strokeStyle=rgba(i%2?P.gold:P.crimson,.42);ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,18);ctx.bezierCurveTo(-25,-10,-20,-tip*.65,0,-tip);ctx.bezierCurveTo(20,-tip*.65,25,-10,0,18);ctx.stroke();ctx.restore();}
 drawRing(ctx,CX,CY,58,P.gold,.25*q,1);txt(ctx,"lotus = constructed relation, not stock image",CX,590,{size:18,color:P.ink});
}
function yantraConstruction(ctx,p,o){
 header(ctx,"CAUSAL YANTRA CONSTRUCTION");
 const q=smoothstep(.04,.95,p);
 [150,115,82].forEach((r,i)=>drawRing(ctx,CX,CY,r,[P.graphite,P.gold,P.crimson][i],.18+.08*q,1));
 for(const [rot,col] of [[-Math.PI/2,P.gold],[Math.PI/2,P.crimson]]){ctx.save();ctx.translate(CX,CY);ctx.rotate(rot);ctx.strokeStyle=rgba(col,.45*q);ctx.beginPath();for(let i=0;i<3;i++){const a=i/3*TAU-Math.PI/2,x=Math.cos(a)*100,y=Math.sin(a)*100;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.closePath();ctx.stroke();ctx.restore();}
 drawGlowOrb(ctx,CX,CY,5,P.gold,.42*q);txt(ctx,"bindu → polarity → enclosure",CX,590,{size:18,color:P.ink,alpha:q});
}

/* particles/audio */
function nadiFlow(ctx,p,o,env){
 header(ctx,"AUDIO-REACTIVE PATH FLOW");
 const rms=clamp(env.audio?.rms??0),onset=clamp(env.audio?.onset??0),q=smoothstep(.03,.95,p);
 const paths=[-1,0,1];
 paths.forEach((side,i)=>{ctx.save();ctx.strokeStyle=rgba([P.blue,P.gold,P.crimson][i],.38);ctx.lineWidth=1.2;ctx.beginPath();for(let j=0;j<=90;j++){const u=j/90,y=120+u*440,x=CX+side*65*Math.sin(u*TAU*2.5)*(side===0?0:1);j?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.stroke();ctx.restore();});
 const count=18+Math.floor((rms+onset)*28);
 for(let i=0;i<count;i++){const u=(i/count+q*.7)%1,side=i%3-1,y=120+u*440,x=CX+side*65*Math.sin(u*TAU*2.5)*(side===0?0:1);drawGlowOrb(ctx,x,y,2.5+onset*2,[P.blue,P.gold,P.crimson][side+1],.24+.3*rms);}
 txt(ctx,"score selects event · waveform modulates performance",CX,600,{size:18,color:P.ink});
}

/* neural */
function neuralPropagation(ctx,p,o){
 header(ctx,"DOMAIN PACK: NEUROCOGNITION");
 const nodes=[];for(let i=0;i<24;i++){const a=i*2.399963,r=45+Math.sqrt(i/24)*220;nodes.push({x:CX+Math.cos(a)*r,y:CY+Math.sin(a)*r*.62});}
 nodes.forEach((n,i)=>{drawNode(ctx,n.x,n.y,3,{fill:P.blue,stroke:P.indigo,alpha:.32});if(i>0)arrow(ctx,nodes[Math.floor((i-1)/2)],n,{color:P.indigo,alpha:.12,width:.45});});
 const q=smoothstep(.08,.92,p),idx=Math.min(nodes.length-1,Math.floor(q*(nodes.length-1)));drawGlowOrb(ctx,nodes[idx].x,nodes[idx].y,7,P.gold,.5);txt(ctx,"propagation is a mechanism, not a consciousness icon",CX,590,{size:18,color:P.ink});
}

/* materials/styles */
function styleTriptych(ctx,p,o){
 header(ctx,"STYLE AS AN ORTHOGONAL DIMENSION");
 const cards=[
  {x:235,title:"scientific",bg:"#fbfcfd",c:P.indigo},
  {x:640,title:"ritual gold",bg:"#160a0b",c:"#e8b84d"},
  {x:1045,title:"manuscript",bg:"#eee5d2",c:"#7f3c34"},
 ];
 cards.forEach((c,i)=>{const q=smoothstep(.05+i*.1,.3+i*.1,p);ctx.save();ctx.globalAlpha=q;ctx.fillStyle=c.bg;ctx.fillRect(c.x-155,175,310,330);ctx.strokeStyle=rgba(c.c,.6);ctx.strokeRect(c.x-155,175,310,330);drawRing(ctx,c.x,335,72,c.c,.4,1.2);txt(ctx,c.title,c.x,540,{size:16,color:i===1?"#f4e7bf":P.ink,weight:700});ctx.restore();});
 txt(ctx,"same topology · different material and presentation constraints",CX,610,{size:18,color:P.ink});
}

/* recognition */
function recognitionTransaction(ctx,p,o){
 header(ctx,"RECOGNITION TRANSACTION");
 const q=smoothstep(.04,.9,p);
 const seeds=[{x:280,y:CY},{x:490,y:CY-95},{x:700,y:CY+70},{x:930,y:CY-35}];
 seeds.forEach((s,i)=>{const a=smoothstep(i*.1,i*.1+.28,p);drawRing(ctx,s.x,s.y,42,P.gold,.28*a,1);txt(ctx,"σ",s.x,s.y,{size:21,color:P.gold,math:true,weight:700,alpha:a});});
 const center={x:CX,y:CY};seeds.forEach((s,i)=>arrow(ctx,s,center,{color:P.graphite,alpha:.16*q,dashed:true}));
 drawRing(ctx,CX,CY,110,P.green,.18*q,1.2);txt(ctx,"same invariant",CX,CY,{size:22,color:P.green,weight:700,alpha:q});
 txt(ctx,"identity survives transformation without literal repetition",CX,590,{size:18,color:P.ink,alpha:q});
}

/* tournament */
function formalTournament(ctx,p,o){
 header(ctx,"FORMAL TOURNAMENT");
 const forms=["fugue","passacaglia","canon","rondo","phasing"];
 forms.forEach((f,i)=>{const x=155+i*242,q=smoothstep(.04+i*.07,.3+i*.07,p);box(ctx,x-82,210,164,270,{color:i===1?P.green:P.graphite,alpha:i===1?.42*q:.22*q});txt(ctx,f,x,250,{size:17,color:i===1?P.green:P.ink,weight:700,alpha:q});multi(ctx,["identity","through","change"][i%3]??"change",x,365,{size:14,color:P.graphite,alpha:q});txt(ctx,i===1?"selected":"rejected",x,500,{size:13,color:i===1?P.green:P.crimson,alpha:q});});
 txt(ctx,"choose by structural homology, not prestige",CX,590,{size:18,color:P.ink});
}

/* horizon */
function possibilityAtlas(ctx,p,o){
 header(ctx,"OPEN POSSIBILITY ATLAS");
 const axes=[
  ["topology","graph · field · quotient · manifold"],
  ["time","pulse · memory · bifurcation · recurrence"],
  ["material","ink · light · tissue · metal · data"],
  ["scale","glyph · cell · organism · cosmos"],
  ["subjectivity","camera · aperture · distributed field"],
  ["interaction","audio · narration · user · live data"],
 ];
 axes.forEach((a,i)=>{const q=smoothstep(.04+i*.08,.25+i*.08,p),y=145+i*78;txt(ctx,a[0],180,y,{size:15,color:P.gold,align:"left",weight:700,alpha:q});txt(ctx,a[1],400,y,{size:18,color:P.ink,align:"left",alpha:q});});
 txt(ctx,"primitives are reusable; completed visual arguments are not",CX,635,{size:19,color:P.crimson,weight:700,alpha:smoothstep(.65,.95,p)});
}

const DRAW={
 "notation-argument":notationArgument,"quotient-world":quotientWorld,"attractor-field":attractorField,
 "causal-trace":causalTrace,"nested-agency":nestedAgency,"coupling-kernel":couplingKernel,
 "fission-panels":fissionPanels,"lotus-construction":lotusConstruction,"yantra-construction":yantraConstruction,
 "nadi-flow":nadiFlow,"neural-propagation":neuralPropagation,"style-triptych":styleTriptych,
 "recognition-transaction":recognitionTransaction,"formal-tournament":formalTournament,"possibility-atlas":possibilityAtlas,
};

export function renderGrandExemplar(ctx,t,scene,env){
 const mode=scene.params?.background??"white";paper(ctx,mode);
 const ops=scene.params?.operations??[],n=Math.max(1,ops.length);
 ops.forEach((op,i)=>{const {p,a,visible}=win(op,t,i,n);if(!visible)return;ctx.save();ctx.globalAlpha=a;(DRAW[op.type]??(()=>{}))(ctx,p,op,env);ctx.restore();});
}
export const assetImplementations=Object.freeze({});
export const mechanismImplementations=Object.freeze({"grand-exemplar":renderGrandExemplar});
