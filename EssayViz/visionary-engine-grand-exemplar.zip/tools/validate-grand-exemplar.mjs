#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
const root=resolve(process.argv[2]??".");
const pack=JSON.parse(await readFile(resolve(root,"MOTHERFUCKER/packs/visionary-engine-grand-exemplar.template.json"),"utf8"));
const errors=[];
if(pack.scenes.length!==20)errors.push("expected twenty scenes");
const ops=pack.scenes.flatMap(s=>s.params.operations.map(o=>o.type));
if(new Set(ops).size<14)errors.push("insufficient visual diversity");
for(const scene of pack.scenes){
  if(scene.motif!=="grand-exemplar")errors.push(`${scene.id}: incorrect motif`);
  for(const op of scene.params.operations){
    if(!Number.isFinite(op.start)||!Number.isFinite(op.end)||op.end<=op.start)errors.push(`${scene.id}: invalid operation timing`);
  }
}
if(errors.length){console.error(errors.join("\n"));process.exit(1);}
console.log("Grand exemplar: valid");
