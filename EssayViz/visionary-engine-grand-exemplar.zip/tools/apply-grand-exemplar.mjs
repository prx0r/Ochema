#!/usr/bin/env node
import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const root=resolve(process.cwd());
async function patch(path,fn){
  const source=await readFile(path,"utf8");
  const updated=fn(source);
  if(updated!==source)await writeFile(path,updated);
  console.log(updated!==source?`patched ${path}`:`unchanged ${path}`);
}
await patch(resolve(root,"motifs.mjs"),source=>{
  if(!source.includes("renderGrandExemplar")){
    source=`import { renderGrandExemplar } from "./src/grand-exemplar-motif.mjs";\n${source}`;
  }
  if(!source.includes('"grand-exemplar": renderGrandExemplar')){
    source=source.replace("export const motifs = {",'export const motifs = {\n  "grand-exemplar": renderGrandExemplar,');
  }
  return source;
});
console.log("Grand exemplar registered.");
