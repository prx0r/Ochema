#!/usr/bin/env python3
from __future__ import annotations
import json, subprocess, sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
template=root/"MOTHERFUCKER/packs/visionary-engine-grand-exemplar.template.json"
entries={x["id"]:x for x in json.loads((root/"narration/narration-scenes.json").read_text())}
audio=root/"build/audio-scenes"
out=root/"MOTHERFUCKER/packs/visionary-engine-grand-exemplar.json"
pack=json.loads(template.read_text())
for scene in pack["scenes"]:
    file=audio/f'{scene["id"]}.mp3'
    r=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",str(file)],capture_output=True,text=True,check=True)
    scene["duration"]=round(float(r.stdout.strip()),3)
    scene["narration"]=entries[scene["id"]]["text"]
out.write_text(json.dumps(pack,indent=2)+"\n")
print(out)
