# Visionary Engine Grand Exemplar

A full-length showcase composition and open-ended agent laboratory for the
deterministic Skia visual framework.

This package demonstrates the range of the engine without defining a house
style. It contains:

- one long-form, twenty-scene showcase film;
- a standalone showcase motif with fifteen visual operations;
- composition, style, motion and signal-routing profiles;
- narration and reproducible build scripts;
- an agent skill for inventing new visual systems;
- a possibility atlas and mutation recipes;
- lineage review of all prior packs;
- review contact sheets and validators;
- future backend and pack specifications.

## Purpose

The film is not an advertisement made of unrelated effects. Its argument is:

```text
A visual language becomes expressive when meaning is separated into
relation, topology, invariant, material, motion, style, signal and sequence.
```

Each chapter changes one of these dimensions while preserving the same
underlying problem: how to make a viewer undergo an argument.

## Apply

Extract over the repository root, then from `MOTHERFUCKER/`:

```bash
node ../tools/apply-grand-exemplar.mjs
```

## Build

```bash
bash ../tools/build-film.sh
```

## Validate

```bash
node ../tools/validate-grand-exemplar.mjs ..
node --test tests/grand-exemplar.test.mjs
```
