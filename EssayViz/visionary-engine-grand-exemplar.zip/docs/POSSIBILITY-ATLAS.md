# Possibility Atlas

This atlas is not a menu of approved aesthetics. It is a map of dimensions an
agent may alter.

## Argument forms

- deductive proof;
- transcendental argument;
- dilemma;
- abductive comparison;
- causal explanation;
- counterexample;
- identity claim;
- intervention test;
- scale-selection problem;
- recognition transaction;
- unresolved bind;
- historical reconstruction.

## Topologies

- linear chain;
- branch;
- lattice;
- graph;
- bipartite graph;
- nested closure;
- quotient;
- manifold;
- field;
- attractor basin;
- connected component;
- boundary and aperture;
- braid;
- knot;
- torus;
- orbifold;
- hypergraph;
- causal DAG;
- tensor-like grid;
- recursive tree;
- spatial counterpoint.

## Temporal grammars

- accumulation;
- recurrence;
- phase locking;
- hysteresis;
- causal memory;
- bifurcation;
- oscillation;
- transfer;
- decay;
- growth;
- repair;
- condensation;
- dissolution;
- reversal;
- delayed recognition;
- anticipation and lag.

## Materials

- scientific ink;
- mineral pigment;
- gold leaf;
- charcoal and ash;
- translucent tissue;
- glass;
- fluid;
- woven thread;
- electrical signal;
- luminous plasma;
- paper fibre;
- etched metal;
- data field;
- photographic mask;
- typographic glyph;
- volumetric fog.

## Domain directions

- neurocognition;
- anatomy;
- cell biology;
- ecology;
- cosmology;
- Sanskrit philology;
- Buddhist analysis;
- ritual sequence;
- deity iconography;
- sacred architecture;
- music theory;
- dynamical systems;
- category theory;
- AI architecture;
- social systems;
- history of ideas.

## Signal directions

- MIDI events;
- score-form events;
- waveform amplitude;
- onset;
- spectral centroid;
- harmonic energy;
- speech density;
- semantic narration tags;
- breath;
- live sensor data;
- user interaction;
- scientific time series;
- network events;
- camera tracking.

## Presentation directions

- white scientific plate;
- annotated manuscript;
- cinematic negative space;
- museum object study;
- blackboard proof;
- technical atlas;
- ritual folio;
- live dashboard;
- split-screen debate;
- typographic poem;
- visual score;
- interactive map.

## Backend directions

- Skia;
- SVG;
- CanvasKit;
- WebGL/GLSL;
- WebGPU;
- Three.js;
- Lottie/Skottie;
- native Rust graphics;
- image-mask compositing;
- video texture ingestion.

A new direction should change the causal visual language, not merely its palette.
