# Exemplar Architecture

```text
source intention
    ↓
argument contract
    ↓
composition profile
    ↓
proof topology
    ↓
capability vocabulary
    ↓
geometry + material + motion
    ↓
style constraints
    ↓
score / waveform / narration signals
    ↓
deterministic renderer
    ↓
review and mutation
```

## Orthogonal dimensions

| Dimension | Question |
|---|---|
| Argument | What inference must occur? |
| Relation | What exact relation is being expressed? |
| Topology | What spatial structure minimally encodes it? |
| Invariant | What must remain identifiable? |
| Geometry | Which forms instantiate the topology? |
| Material | How do surfaces and light behave? |
| Motion | What transformation performs the inference? |
| Style | What global constraints create a directorial feel? |
| Signal | What external timing or energy modulates the scene? |
| Composition | Why does this scene follow the previous one? |
| Presentation | How are labels, frames and typography handled? |

A new visual direction can alter any subset of these dimensions.
