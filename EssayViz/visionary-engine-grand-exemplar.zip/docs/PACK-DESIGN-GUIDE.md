# Pack Design Guide

## Capability pack

Defines what a domain can show.

Required:

- assets;
- mechanisms;
- epistemic modes;
- parameters;
- motion proofs;
- compatibility notes.

## Composition pack

Defines why scenes follow one another.

Examples:

- dialectic;
- causal explanation;
- recognition arc;
- ritual progression;
- anatomical journey;
- intervention tournament.

## Style pack

Defines global constraints, not semantic meaning.

Include:

- palette;
- line weight;
- negative space;
- material defaults;
- typography;
- forbidden effects.

## Motion pack

Defines how transformations behave.

Examples:

- breath;
- fracture;
- repair;
- phase;
- growth;
- memory;
- transport;
- ritual gesture.

## Signal-routing pack

Maps external signals to subordinate parameters.

Always distinguish:

- formal score events;
- performed waveform features;
- narration attention;
- semantic narration events.

## Presentation pack

Defines editorial framing:

- labels;
- borders;
- title hierarchy;
- captions;
- evidence badges;
- citations;
- scene numbering.

## Backend adapter

Consumes the same visual IR using another renderer.
