# Mutation Recipes

Use these recipes to escape the nearest template.

## Change topology

```text
branch → lattice
nested rings → overlapping closures
graph → continuous field
linear proof → quotient map
single aperture → competing apertures
```

## Change invariant

```text
conserve object contour
→ conserve relation only

conserve carrier
→ conserve transformation rule

conserve node identity
→ conserve trajectory signature
```

## Change causal direction

```text
center controls periphery
→ periphery entrains center

object emits signal
→ field condenses object

agent follows path
→ path is produced by agent history
```

## Change time

```text
instant transition
→ hysteretic transition

reveal
→ delayed recognition

repetition
→ transformed recurrence

single timescale
→ fast local trace + slow semantic trace
```

## Change subjectivity

```text
external diagram
→ camera becomes aperture

fixed viewpoint
→ viewpoint transfers between agents

objective graph
→ graph changes with observer invariances
```

## Change evidence structure

```text
one preferred theory
→ rival predictions in parallel

conclusion
→ explicit missing bridge

one score
→ gate vector with null dimensions
```

## Change medium relationship

```text
music follows image
→ music proposes topology

narration explains image
→ narration arrives after visual recognition

all media climax
→ one medium withdraws while another completes
```
