# Future Specifications

## Visual intermediate representation

```text
Proposition
Variable
Domain
Node
Edge
Path
Field
Boundary
Aperture
Emitter
Constraint
Material
Layer
Mask
Invariant
Transition
SignalRoute
Camera
Interaction
```

## New pack frontiers

- deity component registry;
- full anatomical atlas;
- mantra phoneme wheel;
- manuscript reconstruction;
- category-theory notation;
- fluid and reaction-diffusion fields;
- spatial counterpoint;
- interactive observer quotients;
- live scientific datasets;
- camera subjectivity;
- three-dimensional sacred architecture;
- multimodal contact-sheet reviewer.

## Backend frontiers

- CanvasKit for deeper Skia exposure;
- SVG export for publication diagrams;
- WebGPU fields and particles;
- GLSL continuous material worlds;
- Three.js spatial scenes;
- Skottie/Lottie motion assets;
- Rust geometry kernels;
- vector-mask ingestion.

## Agent frontiers

- capability registry search;
- semantic compatibility scoring;
- automatic transition synthesis;
- visual theorem testing;
- perception-loop critique;
- patch-based failed-scene revision;
- lineage-aware novelty testing.
