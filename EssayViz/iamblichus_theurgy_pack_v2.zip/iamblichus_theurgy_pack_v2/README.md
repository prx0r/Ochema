# Iamblichus — Theurgy Pack V2

This is a more visually ambitious second pass designed to address the limitations of the first pack.

Included:
- iamblichus_theurgy_animation_v2.mp4
- contact_sheet_v2.jpg
- scene_manifest.json
- scene_catalog.json
- AGENT_KNOWLEDGE_DOSSIER.md
- README.md

Specs:
- Resolution: 1280x720
- FPS: 10
- Scene count: 20
- Duration per scene: 4.8s
- Total runtime: 1.6 min
