# AGENT KNOWLEDGE DOSSIER — Iamblichus / Theurgy V2

## What changed from V1
This second pass intentionally avoids the repetitive generic visual language of basic ladders and circles.
Each scene is now conceived as a small **late-antique work of art** with its own composition:
- temple thresholds
- stepped mountain hierarchies
- crowns of fire
- ritual altars
- spiral invocations
- purification basins
- mirror constellations
- body-temple diagrams
- ornate closing cosmograms

## Visual philosophy
Iamblichus should feel:
- **hierarchical** rather than flat
- **ritual** rather than merely analytical
- **late antique / Hellenic / sacred** rather than generic motion-graphics minimalism
- **anagogic**: the image should lift the mind upward
- **symbolic and dignified**: the divine is not a gimmick or a UI flowchart

## Core doctrinal themes covered
1. Beyond discursive philosophy
2. Hierarchy of divine kinds
3. Highest gods
4. Angels / daimons / heroes as mediating orders
5. Soul at the threshold of embodiment and ascent
6. Vertical causality
7. Epitēdeiotēs / receptivity
8. Symbola and synthēmata
9. Divine names
10. Philosophy vs theurgy
11. Purification
12. Invocation without coercion
13. Descent of presence
14. Immanence without reduction
15. Body as ritual interface
16. Cosmic correspondence
17. Prayer as ascent
18. Anagogic lifting through symbols
19. Illumination of soul
20. Total cosmogram

## Style notes for future scenes
- Use parchment, temple, altar, architectural, stellar, or consecrated motifs.
- Gold is appropriate as a secondary accent because it suits late antique sacred cosmology.
- Crimson marks decisive descent, living presence, or divine focus.
- Avoid generic corporate diagrams.
- Avoid making all middle beings identical nodes.
- Prefer emblematic differentiation: wings, shields, crowns, vessels, spirals, lamps, mirrors.

## Guardrails
- Do not depict theurgy as commanding or controlling gods.
- Do not reduce everything to psychology.
- Keep explicit ritual operations abstract, conceptual, and safe.
- Preserve the distinction between philosophy, theology, and theurgy.

## Reuse strategy
The agent can decode these scenes by **motif type**:
- threshold / arch / portal
- hierarchy / mountain / stepped temple
- emblem / sign / altar
- vessel / receptivity / purification
- descent / ray / presence
- body / interface / participation
- spiral / ascent / anagogy
- cosmogram / synthesis / seal

The same semantic scene logic can later be upgraded in a sleeker renderer (Skia / Canvas / GLSL / Blender) without changing the scene concept.
