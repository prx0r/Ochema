# Research-derived design notes
- Three.js WebGPURenderer can select WebGPU with WebGL 2 fallback and supports node-based materials; custom shader work should target TSL/node materials rather than assume old ShaderMaterial compatibility.
- D3 contour uses marching squares over rectangular scalar grids and returns polygonal contour geometry; this is the recommended future dependency for reference contour extraction.
- LYGIA's granular categories—math, space, color, animation, generative, SDF, filters, simulation, lighting and geometry—support a shader-helper layer, but EssayViz remains responsible for semantic selection and provenance.
- Hopf fibration scenes must distinguish S3 fibers from their stereographic R3 projection and preserve linking identity.
