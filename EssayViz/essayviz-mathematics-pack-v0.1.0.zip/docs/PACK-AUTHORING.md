# Pack authoring
A mathematics mechanism must export deterministic generators, a Skia renderer, explicit parameter and invariant documentation, validation tests, and one demo. The visual contract must state what color encodes. Audio may modulate camera, emphasis, trail persistence, iteration reveal or phase, but may not change a theorem or topology.
