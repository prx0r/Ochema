# Architecture
All packs implement the shared sequence:
```text
essay operation → mathematical contract → deterministic generator → sampled state → measurement → Skia drawing → review
```
The CPU algorithms are reference implementations. Large fractals, fields and particle systems should later target Three.js WebGPURenderer/TSL or regl, while Skia remains the precise typography and annotation layer.
