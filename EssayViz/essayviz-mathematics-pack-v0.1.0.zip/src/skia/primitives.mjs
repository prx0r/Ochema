import {PALETTES,spectralColor} from '../color/index.mjs';
export function createSkiaPrimitives(ctx,{palette=PALETTES.mathematicalWhite,width=1280,height=720}={}){
 const rgba=(hex,a=1)=>{const h=hex.replace('#','');return `rgba(${parseInt(h.slice(0,2),16)},${parseInt(h.slice(2,4),16)},${parseInt(h.slice(4,6),16)},${a})`;};
 return {
  clear(){ctx.fillStyle=palette.background;ctx.fillRect(0,0,width,height);},
  line(a,b,{color=palette.ink,alpha=.7,lineWidth=1,dash=[]}={}){ctx.save();ctx.strokeStyle=rgba(color,alpha);ctx.lineWidth=lineWidth;ctx.setLineDash?.(dash);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.restore();},
  path(points,{color=palette.ink,alpha=.75,lineWidth=1,closed=false,fill=null}={}){if(!points.length)return;ctx.save();ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);for(const p of points.slice(1))ctx.lineTo(p.x,p.y);if(closed)ctx.closePath();if(fill){ctx.fillStyle=rgba(fill,alpha*.25);ctx.fill();}ctx.strokeStyle=rgba(color,alpha);ctx.lineWidth=lineWidth;ctx.stroke();ctx.restore();},
  circle(x,y,r,{color=palette.accent,alpha=.7,fill=null,lineWidth=1}={}){ctx.save();ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);if(fill){ctx.fillStyle=rgba(fill,alpha);ctx.fill();}ctx.strokeStyle=rgba(color,alpha);ctx.lineWidth=lineWidth;ctx.stroke();ctx.restore();},
  text(value,x,y,{size=18,color=palette.ink,alpha=1,align='center',weight=400}={}){ctx.save();ctx.font=`${weight} ${size}px Source Serif 4, serif`;ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillStyle=rgba(color,alpha);ctx.fillText(String(value),x,y);ctx.restore();},
  spectral:t=>spectralColor(t,palette), palette,width,height
 };
}
