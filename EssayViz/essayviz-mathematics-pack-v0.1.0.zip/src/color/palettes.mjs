export const PALETTES=Object.freeze({
 mathematicalWhite:{background:'#fbfaf6',ink:'#15191e',muted:'#68717a',grid:'#dcd8ce',accent:'#3f6f94',secondary:'#a6434a',tertiary:'#ad7e32',positive:'#47775a',violet:'#65538c'},
 complexNight:{background:'#090b12',ink:'#f1eee5',muted:'#8d95a5',grid:'#242b3a',accent:'#56b4e9',secondary:'#e56b6f',tertiary:'#f2c14e',positive:'#66c2a5',violet:'#b392f0'},
 spectralPaper:{background:'#f7f4ec',ink:'#182027',muted:'#69757d',grid:'#ddd7ca',accent:'#306998',secondary:'#bb4d5b',tertiary:'#c28c2c',positive:'#3e8060',violet:'#775b9c'},
 topologyGlass:{background:'#f9fafb',ink:'#15191e',muted:'#64707c',grid:'#dce3e8',accent:'#4c78a8',secondary:'#e45756',tertiary:'#f2cf5b',positive:'#54a24b',violet:'#b279a2'}
});
export function hexToRgb(hex){const h=hex.replace('#','');return [parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];}
export function rgbToHex([r,g,b]){return '#'+[r,g,b].map(x=>Math.round(Math.max(0,Math.min(255,x))).toString(16).padStart(2,'0')).join('');}
export function mixHex(a,b,t){const A=hexToRgb(a),B=hexToRgb(b);return rgbToHex(A.map((x,i)=>x+(B[i]-x)*t));}
export function spectralColor(t,palette=PALETTES.complexNight){const stops=[palette.accent,palette.violet,palette.secondary,palette.tertiary,palette.positive];const x=Math.max(0,Math.min(.999999,t))*(stops.length-1),i=Math.floor(x);return mixHex(stops[i],stops[i+1],x-i);}
