export * from "./parametric.mjs";
