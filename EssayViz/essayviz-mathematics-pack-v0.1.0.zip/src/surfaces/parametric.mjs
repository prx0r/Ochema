import {TAU} from '../core/math.mjs';
export const SURFACES={
 mobius:(u,v,{radius=2,width=.65}={})=>({x:(radius+v*Math.cos(u/2))*Math.cos(u),y:(radius+v*Math.cos(u/2))*Math.sin(u),z:v*Math.sin(u/2)}),
 catenoid:(u,v,{a=.72}={})=>({x:a*Math.cosh(v/a)*Math.cos(u),y:a*Math.cosh(v/a)*Math.sin(u),z:v}),
 helicoid:(u,v,{pitch=.28}={})=>({x:v*Math.cos(u),y:v*Math.sin(u),z:pitch*u}),
 klein:(u,v,{scale=1}={})=>{const r=4*(1-Math.cos(u)/2);return u<Math.PI?{x:scale*(6*Math.cos(u)*(1+Math.sin(u))+r*Math.cos(u)*Math.cos(v)),y:scale*(16*Math.sin(u)+r*Math.sin(u)*Math.cos(v)),z:scale*r*Math.sin(v)}:{x:scale*(6*Math.cos(u)*(1+Math.sin(u))+r*Math.cos(v+Math.PI)),y:scale*(16*Math.sin(u)),z:scale*r*Math.sin(v)};}
};
export function sampleSurface({surface,uSegments=80,vSegments=30,uRange=[0,TAU],vRange=[-1,1],parameters={}}={}){const vertices=[],faces=[];for(let i=0;i<=uSegments;i++)for(let j=0;j<=vSegments;j++){const u=uRange[0]+(uRange[1]-uRange[0])*i/uSegments,v=vRange[0]+(vRange[1]-vRange[0])*j/vSegments;vertices.push(surface(u,v,parameters));}const idx=(i,j)=>i*(vSegments+1)+j;for(let i=0;i<uSegments;i++)for(let j=0;j<vSegments;j++)faces.push([idx(i,j),idx(i+1,j),idx(i+1,j+1),idx(i,j+1)]);return {vertices,faces};}
