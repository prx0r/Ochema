export const complex=(re=0,im=0)=>({re,im});
export const cadd=(a,b)=>complex(a.re+b.re,a.im+b.im);
export const csub=(a,b)=>complex(a.re-b.re,a.im-b.im);
export const cmul=(a,b)=>complex(a.re*b.re-a.im*b.im,a.re*b.im+a.im*b.re);
export const cdiv=(a,b)=>{const d=b.re*b.re+b.im*b.im||1e-30;return complex((a.re*b.re+a.im*b.im)/d,(a.im*b.re-a.re*b.im)/d);};
export const cabs2=z=>z.re*z.re+z.im*z.im;
export const cpowInt=(z,n)=>{let o=complex(1,0),b=z;while(n>0){if(n&1)o=cmul(o,b);b=cmul(b,b);n>>=1;}return o;};
