import {TAU} from '../core/math.mjs';
export function cyclicOrbit({n=8,radius=1,point={x:1,y:0}}={}){return Array.from({length:n},(_,k)=>{const a=k/n*TAU;return {x:radius*(point.x*Math.cos(a)-point.y*Math.sin(a)),y:radius*(point.x*Math.sin(a)+point.y*Math.cos(a)),element:`r^${k}`};});}
export function dihedralOrbit({n=8,point={x:.72,y:.18}}={}){const rot=cyclicOrbit({n,point}),refl=cyclicOrbit({n,point:{x:point.x,y:-point.y}}).map((p,k)=>({...p,element:`sr^${k}`}));return [...rot,...refl];}
export function kleinFourCayley(){return {nodes:['e','a','b','c'],edges:[['e','a','a'],['e','b','b'],['e','c','c'],['a','b','c'],['a','c','b'],['b','c','a']]};}
