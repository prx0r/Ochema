# Test Report

Executed:

```bash
npm test
npm run validate
npm run demo
```

Result:

```text
10 tests passed
CLI validation passed
9 SVG demonstrations generated
all sampled states finite
complex sampler deterministic
Mandelbrot interior/exterior classification passed
torus periodic topology counts passed
Hopf and torus-knot coordinates finite
RK4 Lorenz/Rössler/double-well trajectories finite
logistic orbit remains in [0,1]
Koch and Sierpiński recursion counts passed
parametric surface grid counts passed
color interpolation stable
```
