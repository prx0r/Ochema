---
name: dynamical-systems-director
description: Direct phase portraits, attractors, basins and bifurcations with explicit state equations and parameters.
version: 1.0
---
# Dynamical Systems Director
Declare the state vector, derivative, timestep, solver, burn-in and parameter range. Separate one trajectory from the attractor. A visually dense path is not evidence of chaos; use sensitivity, Lyapunov estimates or bifurcation structure when the claim requires chaos.
