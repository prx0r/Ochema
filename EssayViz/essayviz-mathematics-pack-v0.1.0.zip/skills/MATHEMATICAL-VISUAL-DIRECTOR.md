---
name: mathematical-visual-director
description: Map an essay claim to a precise mathematical process, invariant, parameter trajectory, color grammar and renderer contract.
version: 1.0
---
# Mathematical Visual Director
## Prime rule
Never select a beautiful mathematical object unless its generating process is structurally homologous to the essay operation.
## Required contract
```json
{"claim":"","mathematicalObject":"","equationOrGenerator":"","domain":"","parameters":{},"trajectory":{},"invariants":[],"singularities":[],"measurements":[],"colorMeaning":{},"cameraOrProjection":{},"audioCoupling":{},"forbiddenInference":""}
```
## Mode selection
- Recursion/self-similarity: substitution fractal or complex iteration.
- Stability/choice: attractors, basins or bifurcation.
- Cyclic identity: torus, torus knot or periodic phase space.
- Local/global relation: fiber bundle or Hopf fibration.
- Intrinsic/extrinsic description: parametric surface plus chart/projection.
- Symmetry/invariance: group orbit or Cayley graph.
- Continuous constraint: scalar/vector field and contours.
## Color
Color must encode a quantity: iteration, phase, curvature, basin, velocity, group element, or fiber identity. Never use rainbow color as an unexplained decoration.
## Review
Validate equations, domains, singularities, numerical stability, determinism, and whether the animation reveals the generating law without narration.
