---
name: complex-dynamics-director
description: Author Mandelbrot, Julia, Newton and complex-orbit scenes with correct parameters and visual semantics.
version: 1.0
---
# Complex Dynamics Director
Always show the map, parameter, initial condition, iteration limit and escape rule. Distinguish parameter space from dynamical space. A Mandelbrot image and a Julia image are not interchangeable. Animate `c` with a corresponding Julia inset when explaining parameter dependence. Color may encode smooth escape time, basin identity, orbit trap or distance estimate, but the legend must state which.
