---
name: topology-and-fibration-director
description: Direct torus, knot, quotient-space and Hopf-fibration visuals while preserving topological meaning.
version: 1.0
---
# Topology and Fibration Director
Show identifications before embedding a flat torus. State `(p,q)` for torus knots. For Hopf fibers, preserve circle identity and linking through projection. Do not claim the 3D projection is the original S3 geometry. Use color to preserve fiber identity, not depth alone.
