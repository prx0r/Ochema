# Visual Review

The generated contact sheet was inspected after rendering all nine reference demos.

## Passed

- Mandelbrot and Julia sets are clearly distinct as parameter and dynamical spaces.
- Color follows smooth escape time rather than arbitrary object identity.
- The torus knot remains visibly attached to a genus-one surface.
- Hopf fibers retain stable colors across stereographic projection.
- The Lorenz trajectory is legible without turning into a uniform glow cloud.
- The logistic bifurcation diagram exposes period-doubling and chaotic bands.
- Substitution order remains visible in Koch and Sierpiński constructions.
- Möbius, catenoid and helicoid forms are visually distinct.
- Dihedral orbit colors preserve group-element identity.

## Known limitations

- CPU fractal sampling is a reference renderer, not a deep-zoom engine.
- Hopf fibers near the stereographic projection pole can leave the visible frame.
- Surface SVGs use transparent face overlays and no hidden-line removal.
- Lorenz color encodes trajectory time, not local velocity or Lyapunov exponent.
- The contour pack includes field samplers but does not yet vendor marching squares.
- Skia renderers are written against the Canvas 2D subset exposed by `@napi-rs/canvas`; live repository integration still needs a renderer smoke test.
