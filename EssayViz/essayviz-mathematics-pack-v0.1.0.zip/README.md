# EssayViz Mathematics Packs
Deterministic JavaScript mathematics engines with Skia-ready mechanisms, color systems, agent skills, demos and tests.
## Packs
- complex dynamics
- toroidal topology and Hopf fibers
- dynamical systems
- fractal substitution
- differential geometry
- symmetry groups
- scalar/vector fields
## Run
```bash
npm test
npm run validate
npm run demo
```
## MOTHERFUCKER integration
Copy `src/skia/renderers.mjs`, `src/skia/primitives.mjs`, the mathematical engines and desired `packs/*` directories into the framework. Register `mechanismImplementations` through the capability-pack loader. No geometry should be manually redrawn in a film pack; pass parameters through scene JSON.
