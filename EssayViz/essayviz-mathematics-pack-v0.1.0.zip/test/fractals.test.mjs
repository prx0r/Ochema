import test from 'node:test';import assert from 'node:assert/strict';import {kochCurve,sierpinskiTriangles,lsystem} from '../src/index.mjs';
test('substitution counts match recursion',()=>{assert.equal(kochCurve({iterations:5}).length,4**5+1);assert.equal(sierpinskiTriangles({iterations:5}).length,3**5);assert.ok(lsystem({iterations:3}).length>0);});
