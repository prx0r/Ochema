import test from 'node:test';import assert from 'node:assert/strict';import {PALETTES,mixHex,spectralColor} from '../src/index.mjs';
test('color interpolation stable',()=>{assert.equal(mixHex('#000000','#ffffff',.5),'#808080');for(let i=0;i<=100;i++)assert.match(spectralColor(i/100,PALETTES.complexNight),/^#[0-9a-f]{6}$/i);});
