import test from 'node:test';import assert from 'node:assert/strict';import {createTorusMesh,torusKnot,hopfFiber} from '../src/index.mjs';
test('torus mesh periodic topology counts',()=>{const m=createTorusMesh({uSegments:30,vSegments:12});assert.equal(m.vertices.length,360);assert.equal(m.faces.length,360);});
test('torus knot and Hopf fibers finite',()=>{for(const p of [...torusKnot({samples:200}),...hopfFiber({samples:200})])assert.ok([p.x,p.y,p.z].every(Number.isFinite));});
