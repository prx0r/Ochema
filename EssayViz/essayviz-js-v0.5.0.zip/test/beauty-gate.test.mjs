import test from 'node:test';
import assert from 'node:assert/strict';
import { validateRealizationSpec, evaluateBeautyGate } from '../src/index.mjs';
test('generic field contract is rejected',()=>{
 const r=validateRealizationSpec({mode:'field',fieldType:'continuous vector or scalar field adapted to sequence',entities:[],controlParameters:[],parameters:{},mutation:{},invariant:'x',forbiddenInference:'y'});
 assert.equal(r.valid,false);
});
test('specific double-well field contract passes',()=>{
 const r=validateRealizationSpec({mode:'field',fieldType:'one-dimensional double-well potential',equation:'V(x,λ)=λ(x²-a²)²',entities:[{id:'particle',state:['x','v']}],controlParameters:[{id:'λ',meaning:'barrier height'}],parameters:{a:1},mutation:{type:'lower-barrier',changes:['λ']},invariant:'same particle and potential family',forbiddenInference:'simulation is empirical data'});
 assert.equal(r.valid,true,r.errors.join('\n'));
});
test('beauty gate cannot pass without rendered review',()=>{
 const storyboard={scenes:[{id:'s1'}]};
 const realizations={s1:{mode:'notation',propositions:['P','Q'],edges:[{from:'P',to:'Q',status:'licensed'}],mutation:{type:'license-edge'},invariant:'P and Q',forbiddenInference:'Q is certain'}};
 const r=evaluateBeautyGate({storyboard,realizations});assert.equal(r.pass,false);assert.equal(r.summary.unreviewed,1);
});
