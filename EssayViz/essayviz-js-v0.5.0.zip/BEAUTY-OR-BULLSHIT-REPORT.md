# EssayViz Beauty-or-Bullshit Test

## Verdict

EssayViz v0.4 is **not a visual-generation engine yet**. It is a useful genre router and planning scaffold, but its compiled visual contracts are too generic to determine specific images. The current package can say “use a field” or “use an exact object”; it usually cannot say which field equation, which object parts, which state transition, which camera, or which conservation law.

The strict renderer consumed only compiled data and did not add hidden artistic interpretation. Across six unseen essays:

- 46 scenes compiled;
- 46 scenes lacked a mode-specific realization contract;
- 0 scenes were render-ready under the new beauty gate;
- every high-risk mode fell back to generic geometry or a placeholder;
- all selected `topology` and `decisiveMutation` fields contained generic phrases.

This means the prior claim that EssayViz covered the full source-to-visual path was overstated. It covered source-to-**visual category**, not source-to-renderable visual program.

## Test corpus

1. Logical proof — a transcendental denial argument.
2. Poem — identity through a river bend while material carriers turn over.
3. Explanatory — how a mechanical watch escapement regulates energy.
4. Science — a double-well potential with barrier control and hysteresis.
5. Textual scholarship — source, gloss, translation, and commentary layers.
6. Investigation — three hypotheses around a twelve-minute recording gap.

## What the current compiler rendered

### Logical proof — 3/10

Strengths:

- selected notation most of the time;
- white field and sparse structure fit the genre;
- licensed versus rejected edges are possible.

Failures:

- proposition circles were often empty;
- the same two-node diagram repeated across different premises;
- premise accumulation was not represented;
- long generated belief strings collided with edges;
- no exact scope bracket or source-derived formalization existed.

### Poem — 2/10

Failures:

- five of seven scenes became the same flower-like generic symbol;
- the river, stones, nonreturning drops, persistent bend, and delayed sound were absent;
- typography moved word tokens without preserving lineation or enjambment;
- the output looked like a template assigned by genre.

### Explanatory watch essay — 1/10

Failures:

- “exact object” did not specify a mechanical watch;
- no mainspring, gears, escapement, balance wheel, or dial train existed;
- no stored-energy flow or metering operation existed;
- the renderer could only draw an object placeholder.

This is the clearest proof that object grounding is currently lexical metadata, not geometry.

### Science essay — 2/10

Failures:

- “continuous vector or scalar field” became one anonymous vector field repeated four times;
- no double-well potential was specified;
- no potential equation, barrier parameter, particle trajectory, probability distribution, or hysteresis path existed;
- field imagery was decorative and scientifically irrelevant.

### Textual scholarship — 2/10

Failures:

- source, gloss, translation, and commentary were not separate typed layers;
- the Sanskrit line was not retained as an invariant;
- “exact object” again had no object contract;
- the main epistemic distinction could not be read from the frame.

### Investigation — 3/10

Strengths:

- diagrams and parallel hypotheses were genre-appropriate in principle.

Failures:

- exact timestamps and evidence classes were not structurally encoded;
- no shared clock axis existed;
- no hypothesis reweighting operation existed;
- cinematic scenes lacked camera, environment, subjects, or materials.

## Minimum specific realization prototypes

A second pass authored one specific realization for each essay type and rendered actual staged frames.

### Proof

- propositions named explicitly;
- first implication licensed;
- second implication dashed and cut;
- valid and unsupported scopes remain simultaneously visible.

### Poem

- river bend is the invariant;
- drops are replaceable carriers;
- stones remain local constraints;
- the sound trace follows on a delayed path.

### Watch

- mainspring, gear train, escapement, balance, and hands are exact parts;
- stored energy and metered impulses use separate flow arrows;
- the visual directly supports “the escapement meters energy; it does not create it.”

### Science

- the double-well potential is drawn as a scalar landscape;
- particle position changes as the barrier parameter falls;
- probability lobes remain a separate layer;
- model, trajectory, and distribution are visibly distinct.

### Textual scholarship

- source, gloss, and translation occupy separate columns;
- commentary enters as a separate red layer;
- the source line remains invariant;
- interpretation cannot masquerade as lexical content.

### Investigation

- all raw events share a time axis;
- three hypothesis cards remain parallel;
- the decisive operation aligns clocks and independent power logs rather than adding narrative detail.

These prototypes are still design studies, not final films. They are, however, semantically specific and silently legible in a way the v0.4 contracts were not.

## Root cause

The current compiler stops one layer too early:

```text
source
→ genre
→ rhetorical move
→ visual mode
→ generic topology phrase
```

Production requires:

```text
source
→ rhetorical move
→ visual mode
→ mode-specific realization specification
→ executable geometry/material/motion program
→ rendered review
```

## New hard gate

EssayViz v0.5 adds mode-specific requirements.

### Notation

- at least two propositions;
- semantic edges;
- exact mutation;
- invariant;
- forbidden inference.

### Diagram

- typed nodes and edges;
- layout algorithm;
- mutation.

### Exact object

- object name;
- parts;
- geometry contract;
- state changes;
- mutation.

### Field

- field type;
- equation or sampler;
- entities;
- parameters;
- control parameters;
- mutation.

### Particles

- particle meaning;
- emitter;
- force field;
- constraints;
- mutation.

### Symbolic geometry

- construction steps;
- conserved features;
- mutation.

### Typography

- source tokens;
- transformation rules;
- mutation.

### Cinematic

- subjects;
- camera;
- environment;
- materials;
- blocking;
- mutation.

Generic phrases such as “adapted to,” “performed through,” and “state-changing operation” are now explicit failures.

## Beauty gate

A scene cannot pass merely because its realization spec validates. It also requires actual rendered review:

- frames inspected;
- silent legibility;
- transition causality;
- typography pass;
- continuity pass;
- forbidden-inference pass.

The CLI command is:

```bash
essayviz beauty-check storyboard.json \
  --realizations realizations.json \
  --review render-review.json
```

The existing v0.4 plans score 0/46 render-ready scenes. The six manually authored benchmark realizations pass 6/6 after frame inspection.

## Production consequence

The agent workflow must become:

1. source analyst extracts the rhetorical contract;
2. visual strategist chooses a mode;
3. **visual realizer writes a mode-specific spec**;
4. deterministic validator rejects placeholders;
5. backend compiles the spec;
6. actual frames are rendered;
7. perception critic records observations;
8. beauty gate either passes or blocks release.

No agent should be allowed to jump from “field” to “render.”

## Final judgement

- Genre routing: useful beta.
- Rhetorical parsing: useful fallback, still shallow.
- Candidate selection: directionally useful.
- Visual realization in v0.4: prototype/bullshit.
- New mode-specific schema: necessary production boundary.
- Gold diagnostic frames: proof that the framework can support specific work once the missing realization layer is authored.
- Autonomous beauty: not solved.
- Honest production path: now much clearer.
